var features_metafield = window.fb_features_data.shop_plan_features,
    plan_features = void 0 != features_metafield ? features_metafield.shop_plan_features : void 0,
    customise_msgs = window.fb_settings_data.shop_settings;

function isTags(e) {
    return "string" == typeof e && /<\/?(script|style|object|iframe|video|embed).*?>|<(video).*?<\/\2>+$/.test(e.toLowerCase())
}

function isStoreSpecificCondition(e) {
    return "string" == typeof e && /^(cunt|fuck|fat|ugly|nigger|black|bitch|sherelled|sm|miss mattis|mattis|miss sherelle mattis|caroline street|care home|saint healthcare|hewitt homes|pay|staff|bakeevencakery|does not|josh|charles|slag|tramp|dbs|wayne|fatso|shit|shit head|fanny|suck|lips|fugly|zero|food rating)/.test(e.toLowerCase())
}

function isStoreSpecificForStaghead(e) {
    return "string" == typeof e && /^(manager|director|coordinator|seo|consultant|specialist)/.test(e.toLowerCase())
}

function isSQL(e) {
    return "string" == typeof e && /^(ALTER|CREATE|DELETE|DROP|EXEC(UTE)?|INSERT( +INTO)?|MERGE|SELECT|UPDATE|UNION( +ALL)?)/i.test(e)
}

function isEmail(e) {
    return "string" == typeof e && /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(e)
}

function validateUrl(e) {
    return "string" == typeof e && /^(https?:\/\/|www\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/\S*)?$/.test(e)
}

function isStoreSpecificForVorwerk(e) {
    return /\b(http|www)\b/i.test(e) ? ["The words 'http' and 'www' are not allowed. Please remove them and try again.", !0] : ["", !1]
}

function getUTMParams() {
    var e = {};
    return new URLSearchParams(window.location.search).forEach((t, a) => {
        a.startsWith("utm_") && (e[a] = t)
    }), JSON.stringify(e)
}

function getReferrerURL() {
    return location.href
}

function formLayout(e, t, a) {
    handleFormLayout(e, t, a)
}
window.isTags = isTags, window.isStoreSpecificCondition = isStoreSpecificCondition, window.isStoreSpecificForStaghead = isStoreSpecificForStaghead, window.isSQL = isSQL, window.isEmail = isEmail, window.validateUrl = validateUrl, window.isStoreSpecificForVorwerk = isStoreSpecificForVorwerk, window.update = function(e, t) {
    let a = `.hulk_form_${t}`,
        l = document.querySelectorAll(`${a} .input${e}`);
    for (let r of l)
        if ("1" === r.getAttribute("other_value")) {
            let i = document.querySelector(`${a} #form_input_${e}`),
                o = i.options[i.options.length - 1].value;
            "Other" === r.value || o === r.value ? document.querySelector(`${a} .optional-field-span-${e}`).style.display = "block" : document.querySelector(`${a} .optional-field-span-${e}`).style.display = "none"
        }
}, window.multiUpdate = function(e, t) {
    let a = `.hulk_form_${t}`,
        l = document.querySelector(`${a} .input${e}`);
    if (l && "1" === l.getAttribute("other_value")) {
        let r, i = document.querySelector(`${a} .input${e}`).querySelector(".checkboxmulti_" + e + '[value="Other"]'),
            o = document.querySelector(`${a} .optional-multi-field-span-${e}`);
        i && i.checked ? o && (o.style.display = "block") : o && (o.style.display = "none")
    }
}, window.convertImageToBase64 = function(e) {
    return new Promise((t, a) => {
        let l = document.createElement("img");
        l.crossOrigin = "anonymous", l.onload = () => {
            let e = document.createElement("canvas"),
                r = e.getContext("2d");
            e.width = l.naturalWidth, e.height = l.naturalHeight, r.drawImage(l, 0, 0);
            try {
                let i = e.toDataURL("image/png");
                t(i)
            } catch (o) {
                a(Error("Failed to convert image to Base64"))
            }
        }, l.onerror = () => a(Error("Failed to load image")), l.src = e
    })
}, window.GeneratePdf = function(e, t) {
    var a = document.querySelector(".response_heading"),
        l = document.querySelectorAll(`${t} .question_content`);
    if (!a || 0 === l.length) {
        console.error("Elements not found");
        return
    }
    var r = document.createElement("div");
    r.appendChild(a.cloneNode(!0)), l.forEach(e => {
        r.appendChild(e.cloneNode(!0))
    }), r.style.textAlign = "center", Object.assign(r.style, {
        border: "1px solid #ccc",
        borderCollapse: "collapse",
        borderSpacing: "0",
        textAlign: "center",
        color: "black",
        fontSize: "15px",
        fontFamily: "Lato, sans-serif",
        lineHeight: "26px",
        letterSpacing: ".07rem",
        width: "550px",
        textTransform: "none"
    });
    let i = r.querySelectorAll("img"),
        o = Array.from(i).map(e => convertImageToBase64(e.src).then(t => {
            e.src = t
        }).catch(t => {
            console.error("Error converting image to base64:", t), e.style.display = "none"
        }));
    Promise.all(o).then(() => {
        html2pdf(r, {
            filename: e + "_response.pdf"
        })
    }).catch(e => {
        console.error("Error fetching images:", e)
    })
}, window.download = function(e, t) {
    var a = [];
    document.querySelectorAll(`${t} table tr`).forEach(e => {
        var t = [];
        e.querySelectorAll("td, th").forEach(e => {
            var a = "",
                l = e.querySelectorAll("a:has(img)"),
                r = e.querySelectorAll("a:not(:has(img))");
            l.forEach((e, t) => {
                a += (t > 0 ? "," : "") + e.href
            }), r.forEach((e, t) => {
                a += (t > 0 ? "," : "") + e.href
            }), a += (l.length > 0 || r.length > 0 ? "\n" : "") + e.innerText.trim(), t.push(a.trim())
        }), a.push(t.join(","))
    }), downloadCSVFile(a.join("\n"), e)
}, window.downloadCSVFile = function(e, t) {
    var a = new Blob([e], {
            type: "text/csv"
        }),
        l = document.createElement("a");
    l.download = t + "_response.csv", l.href = window.URL.createObjectURL(a), l.style.display = "none", document.body.appendChild(l), l.click(), document.body.removeChild(l)
}, window.keyboardAccess = function() {
    let e = document.querySelectorAll(".radio-inline, .checkbox-inline, .rating-inline"),
        t = document.querySelector(".emoji-feedback"),
        a = document.querySelectorAll(".product-grid, .picture_choice"),
        l = document.querySelectorAll(".checkbox .checkbox-inline");
    e.length > 0 && e.forEach(e => {
        e.addEventListener("keydown", t => {
            "Enter" === t.key && (e.focus(), e.click())
        })
    }), t && t.addEventListener("keydown", e => {
        if ("Enter" === e.key) {
            e.preventDefault();
            let a = t.querySelectorAll(".ef-radio");
            a.forEach(e => {
                e.checked = !1
            }), e.target.querySelector("input").checked = !0
        }
    });
    let r = e => {
        e.addEventListener("keydown", t => {
            if ("Enter" === t.key) {
                t.preventDefault();
                let a = e.querySelectorAll('input[type="radio"]'),
                    l = e.querySelectorAll('input[type="checkbox"]');
                if (a.length > 0 && "radio" === a[0].type) a.forEach(e => {
                    e.checked = !1
                }), t.target.querySelector('input[type="radio"]').checked = !0;
                else if (l.length > 0 && "checkbox" === l[0].type) {
                    let r = t.target.querySelector('input[type="checkbox"]');
                    r && (r.checked = !r.checked)
                }
            }
        })
    };
    a.forEach(r), l.length > 0 && l.forEach(e => {
        e.addEventListener("keydown", function t(a) {
            if ("Enter" === a.key) {
                a.preventDefault();
                let l = e.querySelector('input[type="checkbox"]');
                l && (l.checked = !l.checked)
            }
        })
    })
}, window.preventInvalidInput = function(e) {
    !["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key) && ["+", "-", "e", ".", ","].includes(e.key.toLowerCase()) && e.preventDefault()
}, window.injectDynamicScript = function(e) {
    var t = document.createElement("script");
    t.type = "text/javascript", t.textContent = `
      setTimeout(function() {
          console.log("This message will be logged after 2 seconds.");
          ${e}
      }, 2000);
  `, document.body.appendChild(t)
}, window.initFormBuilder = function() {
    document.addEventListener("click", function(e) {
        if (e.target.matches('.pxFormGenerator [class$="_rowbutton"]')) {
            e.preventDefault();
            var t = e.target.getAttribute("data-element"),
                a = e.target.getAttribute("data-form-element"),
                l = `.hulk_form_${a}`,
                r = e.target.getAttribute("data-max"),
                i = e.target.getAttribute("data-required"),
                o = e.target.getAttribute("data-required"),
                s = document.querySelector(".multi-column-input-" + t),
                n = s.querySelector("input[name='key']").getAttribute("placeholder"),
                c = s.querySelector("input[name='value']").getAttribute("placeholder");
            if (document.querySelectorAll(`${l} .multi-column-input-` + t).length < r) {
                var d = `
            <div class="multi-column-input multi-column-input-${t}">
                <div class="column1-desc">
                    <input class="form-control add_element_${t}${i}" name="key" aria-required="${o}" type="text" placeholder="${null!=n?n:""}">
                </div>
                <div class="column2-desc">
                    <input class="form-control add_element_${t}${i}" name="value" aria-required="${o}" type="text" placeholder="${null!=c?c:""}">
                </div>
                <button class="multi-colum-delete-button" data-element="${t}">-</button>
            </div>`;
                document.querySelector(`${l} .input_fields_${t}_wrap .multi-column-input-main`).insertAdjacentHTML("beforeend", d), document.querySelectorAll(`${l} div.input_fields_${t}_wrap p.error`).forEach(function(e) {
                    e.remove()
                })
            } else {
                var u = document.querySelector(`${l} div.input_fields_${t}_wrap`),
                    m = u.querySelector("p.error");
                m && m.remove(), u.insertAdjacentHTML("beforeend", '<p class="error" tabindex="0" aria-label="You have added the maximum number of text fields." style="color: red; border: unset !important; font-size:9px; margin: unset !important; width: 105%; padding-top: 5px !important;">You have added the maximum number of text fields.</p>')
            }
        }
        if (e.target && e.target.classList.contains("multi-colum-delete-button")) {
            e.preventDefault();
            var p = e.target.getAttribute("data-element"),
                f = document.querySelectorAll(".multi-column-input-" + p);
            let b = e.target.closest(`.multi-column-input-${p}`).closest(`.input_fields_${p}_wrap`).querySelector("p.error");
            b && b.remove(), f.length > 1 && e.target.closest(".multi-column-input").remove()
        }
        if (e.target.classList.contains("toggle-password")) {
            e.target.classList.toggle("fa-eye"), e.target.classList.toggle("fa-eye-slash");
            let h = e.target.parentElement.querySelector("input:first-of-type");
            h && (h.type = "password" === h.type ? "text" : "password")
        }
        if (e.target.classList.contains("toggle-password-confirm")) {
            e.target.classList.toggle("fa-eye"), e.target.classList.toggle("fa-eye-slash");
            let y = e.target.parentElement.querySelector('input[name$="_input"]');
            y && (y.type = "password" === y.type ? "text" : "password")
        }
        if (e.target && e.target.matches('.pxFormGenerator [class$="_button"]')) {
            e.preventDefault();
            let g = e.target,
                v = g.className.split("_"),
                x = v[1],
                S = g.getAttribute("data-max");
            var a = g.getAttribute("data-form-element"),
                l = `.hulk_form_${a}`;
            let $ = document.querySelector(`${l} .input_fields_${x}_wrap`),
                q = $.querySelectorAll(`${l} .add_element_${x}`).length;
            if (q < S) {
                let k = $.querySelector("div input[type=text]"),
                    L = k ? k.getAttribute("placeholder") : "",
                    w = k ? k.getAttribute("id") : "",
                    E = "";
                if (k) {
                    let A = k.className.split(" ").filter(e => "error" !== e);
                    E = A.join(" ") + " new-input"
                }
                let C = document.createElement("div");
                C.style.display = "flex", C.style.marginTop = "10px";
                let _ = document.createElement("input");
                _.className = `${E} new-input`, _.name = `add_element_${x}`, _.id = w, _.placeholder = L, _.setAttribute("aria-placeholder", L), _.type = "text";
                let T = document.createElement("button");
                T.style.cssText = "border: unset; background: none; margin-left: 10px;font-size: 37px; color: gray;margin-top: -6px;", T.className = `remove_button_${x}`, T.setAttribute("aria-label", "Remove button"), T.textContent = "-", C.appendChild(_), C.appendChild(T), $.appendChild(C);
                let M = $.querySelector(`${l} p.error`);
                M && M.remove()
            } else {
                let F = $.querySelector(`${l} p.error`);
                F && F.remove(), (F = document.createElement("p")).className = "error", F.tabIndex = 0, F.setAttribute("aria-label", "Max limit exceeded"), F.style.cssText = "color: red; border: unset !important; font-size:9px; margin: unset !important; width: 105%; padding-top: 5px !important;", F.textContent = getMessage(" ", "max_limit_exceed"), $.appendChild(F)
            }
        }
        if (e.target && e.target.matches('.pxFormGenerator [class^="remove_button_"]')) {
            let j = e.target.closest(`.input_fields_${e.target.className.split("_")[2]}_wrap`),
                N = j.querySelector("p.error");
            N && N.remove(), e.target.parentNode.remove()
        }
        if (e.target.matches('.pxFormGenerator .product_choice input[type="radio"]')) {
            for (var z = e.target, H = z.closest(".form-group"), B = H.className.split(" "), I = null, D = 0; D < B.length; D++)
                if (B[D].startsWith("formElement_")) {
                    I = B[D].split("_")[1];
                    break
                }
            if (I) {
                var P = H.querySelector(".formElement_" + I + ".product_choice .clear-selection-btn");
                if (!P) {
                    (P = document.createElement("div")).classList.add("clear-selection-container");
                    var G = document.createElement("button");
                    G.setAttribute("tabindex", "0"), G.setAttribute("aria-label", "Clear Selection"), G.textContent = getMessage(" ", "product_choice_clear_selection"), G.classList.add("clear-selection-btn", "clear-selection-link"), G.setAttribute("data-form-element-id", I), G.addEventListener("click", function() {
                        var e = this.getAttribute("data-form-element-id");
                        H.querySelectorAll('input[type="radio"][name="product-choice-img-' + e + '"]').forEach(function(e) {
                            e.checked = !1
                        }), this.parentElement.remove()
                    }), P.appendChild(G);
                    var R = H.querySelector(".formElement_" + I + ".product_choice label:first-of-type");
                    R.parentNode.insertBefore(P, R.nextSibling)
                }
            }
        }
        if (e.target.matches('.pxFormGenerator  .picture_choice input[type="radio"]')) {
            for (var z = e.target, H = z.closest(".form-group"), B = H.className.split(" "), I = null, D = 0; D < B.length; D++)
                if (B[D].startsWith("formElement_")) {
                    I = B[D].split("_")[1];
                    break
                }
            if (I) {
                var P = H.querySelector(".clear-selection-btn");
                if (!P) {
                    (P = document.createElement("div")).classList.add("clear-selection-container");
                    var G = document.createElement("button");
                    G.setAttribute("tabindex", "0"), G.setAttribute("aria-label", "Clear Selection"), G.textContent = getMessage("", "picture_choice_clear_selection"), G.classList.add("clear-selection-btn", "clear-selection-link"), G.setAttribute("data-form-element-id", I), G.addEventListener("click", function() {
                        var e = this.getAttribute("data-form-element-id");
                        H.querySelectorAll('input[type="radio"][name="picture-choice-img-' + e + '"]').forEach(function(e) {
                            e.checked = !1
                        }), this.parentElement.remove()
                    }), P.appendChild(G);
                    var R = H.querySelector(".picture_choice label:first-of-type");
                    R && R.parentNode.insertBefore(P, R.nextSibling)
                }
            }
        }
        if (e.target.closest(".pxFormGenerator .form_submit_div .btn")) {
            e.preventDefault(), e.target.closest(".form_submit_div .btn").disabled = !0;
            var U = e.target.closest(".pxFormGenerator");
            if (U) {
                console.log("Found form:", U);
                var V = U.getAttribute("id");
                validateFormbuilderform(window.fb_form_data["form_" + V], V)
            }
        }
        if (e.target.matches(".alert_message .alert span")) {
            let O = e.target.closest(".alert_message");
            O && (O.style.display = "none")
        }
    })
}, window.conditionalHide = function(e) {
    var t = document.querySelector("." + e);
    if (t.classList.contains("checkbox-multi")) {
        var a = t.querySelectorAll('input[type="checkbox"]');
        a.forEach(function(e) {
            e.checked = !1, e.dispatchEvent(new Event("change"))
        })
    } else if (t.classList.contains("checkbox")) {
        var l = t.querySelector(".checkbox-list"),
            a = t.querySelectorAll('input[type="checkbox"]'),
            r = l && "true" === l.getAttribute("aria-prechecked");
        a.forEach(function(e) {
            e.checked = r, e.dispatchEvent(new Event("change"))
        })
    } else if (t.classList.contains("radio")) t.querySelectorAll('input[type="radio"]').forEach(function(e) {
        e.checked = !1, e.dispatchEvent(new Event("change"))
    });
    else if (t.classList.contains("select")) {
        var i = t.querySelector("select");
        i && (i.value = "", i.dispatchEvent(new Event("change")))
    }
}, window.isDoubleQuotes = function(e) {
    if ("true" == validateDoubleQuotes) return /((").*?)+$/.test(e)
}, window.securityEmailValidation = function(e) {
    var t = "",
        a = !1;
    return isTags(e) && (t = "HTML Tags are not allowed", a = !0), [t, a]
}, window.populateCountryDropdowns = function() {
    if (plan_features.includes("elements-add-ons")) {
        var e = document.querySelectorAll(".country");
        ["Afghanistan", "Aland Islands", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua And Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia And Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, Democratic Republic", "Cook Islands", "Costa Rica", "Cote D'Ivoire", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard Island & Mcdonald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran, Islamic Republic Of", "Iraq", "Ireland", "Isle Of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea", "Kuwait", "Kyrgyzstan", "Lao People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States Of", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Palestinian Territory, Occupied", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Barthelemy", "Saint Helena", "Saint Kitts And Nevis", "Saint Lucia", "Saint Martin", "Saint Pierre And Miquelon", "Saint Vincent And Grenadines", "Samoa", "San Marino", "Sao Tome And Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia And Sandwich Isl.", "Spain", "Sri Lanka", "Sudan", "Suriname", "Svalbard And Jan Mayen", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad And Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks And Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Viet Nam", "Virgin Islands, British", "Virgin Islands, U.S.", "Wallis And Futuna", "Western Sahara", "Yemen", "Zambia", "Zimbabwe"].forEach(function(t) {
            e.forEach(function(e) {
                var a = document.createElement("option");
                a.value = t, a.textContent = t, e.appendChild(a)
            })
        })
    }
}, window.loadHtml2PdfScript = function() {
    var e = document.createElement("script");
    e.type = "text/javascript", e.src = form_url + "/corepage/js/html2pdf.bundle.min.js", e.onload = function() {
        console.log("html2pdf.bundle.min.js loaded successfully-----.")
    }, document.head.appendChild(e)
}, window.securityValidation = function(e) {
    var t = "",
        a = !1;
    return "1ef268-a0.myshopify.com" === shop_shopify_domain && isStoreSpecificCondition(e) && (t = "Avoid negative words: Don't use negative words in your contact message.", a = !0), "staghead.myshopify.com" === shop_shopify_domain && isStoreSpecificForStaghead(e) && (t = "This form is for custom designs requests. For general inquiries please contact our team at info@stagheaddesigns.com", a = !0), isTags(e) ? (t = "HTML Tags are not allowed", a = !0) : isSQL(e) ? (t = "SQL Queries are not allowed", a = !0) : isDoubleQuotes(e) && (t = "Double quotes are not allowed", a = !0), [t, a]
}, window.storeSpecificSecurityValidation = function(e) {
    var t = "",
        a = !1;
    if ("vorwerk-sg.myshopify.com" === shop_shopify_domain) {
        var l = isStoreSpecificForVorwerk(e);
        t = l[0], a = l[1]
    }
    return [t, a]
}, window.checkPasswordRules = function(e, t, a, l, r) {
    var i = "",
        o = "",
        s = "",
        n = "",
        c = "",
        d = !1,
        u = !1,
        m = !1,
        p = !1,
        f = !1,
        b = !1,
        h = r + " needs to: ";
    if (/[\!\@\\\#\$\%\^\&\,\.\:\;\<\=\'\"\/\>\?\[\]\`\{\}\~\*\(\)\_\+\|\!\-]/.test(e) ? (i = h + '<p style="color: green; margin-left: 30px;">✓ ' + getMessage(" ", "atleast_one_special_char") + "</p>", u = !1) : (i = h + '<p style="color: red; margin-left: 30px;" tabindex="0" aria-label="' + getMessage(" ", "atleast_one_special_char") + '">✕ ' + getMessage(" ", "atleast_one_special_char") + "</p>", u = !0), /[a-z]/.test(e) ? (o = i + '<p style="color: green; margin-top: 0px; margin-left: 30px;">✓ ' + getMessage(" ", "atleast_one_lowercase_char") + "</p>", m = !1) : (o = i + '<p style="color: red; margin-top: 0px; margin-left: 30px;" tabindex="0" aria-label="' + getMessage(" ", "atleast_one_lowercase_char") + '">✕ ' + getMessage("", "atleast_one_lowercase_char") + "</p>", m = !0), /[A-Z]/.test(e) ? (s = o + '<p style="color: green; margin-top: 0px; margin-left: 30px;">✓ ' + getMessage(" ", "atleast_one_uppercase_char") + "</p>", p = !1) : (s = o + '<p style="color: red; margin-top: 0px; margin-left: 30px;" tabindex="0" aria-label="' + getMessage(" ", "atleast_one_uppercase_char") + '">✕ ' + getMessage(" ", "atleast_one_uppercase_char") + "</p>", p = !0), /[0-9]/.test(e) ? (n = s + '<p style="color: green; margin-top: 0px; margin-left: 30px;">✓ ' + getMessage(" ", "atleast_one_number") + "</p>", f = !1) : (n = s + '<p style="color: red; margin-top: 0px; margin-left: 30px;" tabindex="0" aria-label="' + getMessage(" ", "atleast_one_number") + '">✕ ' + getMessage(" ", "atleast_one_number") + "</p>", f = !0), t >= parseInt(a)) {
        if (parseInt(a) === parseInt(l)) {
            var y = getMessage(" ", "must_have_8_chars").replace(/\b8\b/, a);
            c = n + "<p style='color: green; margin-top: 0px; margin-left: 30px;'>✓ " + y + "</p>", b = !1
        } else {
            var y = getMessage(" ", "be_between_8_and_12_chars").replace(/\b8\b/, a).replace(/\b12\b/, l);
            c = n + "<p style='color: green; margin-top: 0px; margin-left: 30px;'>✓ " + y + "</p>", b = !1
        }
    } else if (parseInt(a) === parseInt(l)) {
        var y = getMessage(" ", "must_have_8_chars").replace(/\b8\b/, a);
        c = n + "<p tabindex='0' aria-label='" + y + "' style='color: red; margin-top: 0px; margin-left: 30px;'>✕ " + y + "</p>", b = !0
    } else {
        var y = getMessage(" ", "be_between_8_and_12_chars").replace(/\b8\b/, a).replace(/\b12\b/, l);
        c = n + "<p tabindex='0' aria-label='" + y + "' style='color: red; margin-top: 0px; margin-left: 30px;'>✕ " + y + "</p>", b = !0
    }
    return [c, d = !!u || !!m || !!p || !!f || !!b]
}, window.generateFormTitle = function(e) {
    var t = "";
    return t += '<div class="col-md-12 clearfix">', void 0 != e.form_banner && (t += '<div class="form_banner_div" tabindex="0" aria-label="Form banner image"><img src="' + e.form_banner + '" alt="Form banner image" style="height:' + (void 0 !== e.banner_img_height ? e.banner_img_height + "px" : "150px") + "; width:" + (void 0 !== e.banner_img_width ? e.banner_img_width + "px" : "250px") + ';border: none;" height="' + (void 0 !== e.banner_img_height ? e.banner_img_height + "px" : "150px") + '" width="' + (void 0 !== e.banner_img_width ? e.banner_img_width + "px" : "250px") + '"></div>'), void 0 != e.form_title && (t += '<div class="form_title_div" tabindex="0" aria-label="' + e.form_title.replace(/<\/?[^>]+(>|$)/g, "") + '" aria-describedby="Form title">' + e.form_title + "</div>"), void 0 != e.form_description && (t += '<div class="form_description_div" tabindex="0" aria-label="' + e.form_description.replace(/<\/?[^>]+(>|$)/g, "") + '" aria-describedby="Form Description">' + e.form_description + "</div>"), t += "</div>"
}, window.generateFormCSS = function(e, t) {
    var a = "transparent",
        l = "auto",
        r = "margin-top: 0px; margin-bottom: 10px;";
    "image" == e.back_type && e.image_url ? a = "url(" + e.image_url + ") no-repeat 50% 50% / cover" : "color" == e.back_type ? a = e.back_color : "gradient" == e.back_type && (a = "linear-gradient(to bottom, " + e.div_back_gradient_1 + " 0%, " + e.div_back_gradient_2 + " 100%)"), "fullBtn" == e.button_align && (l = "100%"), e.label_style && "blockLabels" != e.label_style && (r = "margin-top: 0px; margin-bottom: 5px !important;");
    var i = "",
        o = "";
    "System Fonts" == e.label_fonts_type && e.label_system_font_family ? i = "font-family: " + e.label_system_font_family + "!important;" : "Custom Fonts" == e.label_fonts_type && e.label_custom_font_name && e.label_custom_font_url ? i = "font-family: " + e.label_custom_font_name + "!important;" : e.label_font_family && (i = "font-family: " + e.label_font_family + "!important;"), "System Fonts" == e.input_fonts_type && e.input_system_font_family ? o = "font-family: " + e.input_system_font_family + "!important;" : "Custom Fonts" == e.input_fonts_type && e.input_custom_font_name && e.input_custom_font_url ? o = "font-family: " + e.input_custom_font_name + "!important;" : e.input_font_family && (o = "font-family: " + e.input_font_family + "!important;"), e.btn_border_clr || (e.btn_border_clr = e.button_back_clr), e.btn_border_size || (e.btn_border_size = 0);
    var s = "transparent" == e.input_back_color ? "#fff" : e.input_back_color,
        n = e.input_font_clr,
        c = parseInt(e.input_font_size, 10) + 2 || 16,
        d = `.hulk_form_${t}`,
        u = `${d} .form_generater_form_div { 
        background: ${a};
        max-width: ${e.form_width};
        border: solid;
        border-width: ${e.form_border_size}px;
        border-color: ${e.form_border_clr};
        border-radius: ${e.form_border_radius}px;
        padding: ${e.form_padding}px;
        ${i}
    }`;
    u += `${d} .form_generater_form_div * {
      ${i}
    }`, u += `
    ${d} input, ${d} textarea, ${d} select ,${d} .form-control[disabled],${d} .form-control[readonly]{
        background: ${e.input_back_color};
        border-radius: ${e.input_border_radius}px;
        border: 1px solid ${e.input_border_color};
    }`, u += `
    ${d} input:focus, ${d} textarea:focus, ${d} select:focus {
        background: ${e.input_back_color_hover};
        border: 1px solid ${e.input_border_color_hover};
    }`, u += `@layer utilities { ${d} input[type="text"]::placeholder,
    ${d} input[type="email"]::placeholder,
    ${d} input[type="password"]::placeholder,
    ${d} input[type="number"]::placeholder,
    ${d} textarea::placeholder,${d} select {
        color: ${e.input_placeholder_clr} !important;
        font-size: ${e.input_font_size}px;
        ${o}
    }}`, u += `@layer utilities { ${d} input,${d}  textarea,${d}  select:focus,${d}  .checkbox-inline label,${d}  .checkbox-inline input[type="checkbox"] + label,${d} .checkbox-inline input[type="checkbox"] + label a,${d}  .radio-inline label,${d}  .radio-inline input[type="radio"] + label{
      color: ${e.input_font_clr} !important;  
      font-size: ${e.input_font_size}px;
      ${o}
    }}`, u += `${d} textarea.form-control{
      resize: none;
    }`, u += `
    ${d} div.form_submit_div button,${d} div.form_submit_div button:hover {
        color: ${e.button_clr} !important;
        background: ${e.button_back_clr} !important;
        border-radius: ${e.button_border_radius}px;
        width: ${l};
        font-size: ${e.button_font_size}px;
        border: ${e.btn_border_size}px solid ${e.btn_border_clr};
        ${o}
    }`, u += `${d}
    .block_label, ${d} .header_column1, ${d} .header_column2 {
      color: ${e.label_font_clr};
      font-size: ${e.label_font_size}px !important;
      ${i}
    }`, u += `${d} input:-moz-placeholder {
      color: ${e.input_font_clr};
    }`, u += `${d} input::-webkit-input-placeholder{
      color: ${e.input_font_clr};
    }`, u += `${d} .form_container .radio,${d} .form_container .checkbox-multi,${d} .form_container .checkbox {
      ${r}
    }`, u += `${d} input[type="checkbox"] + label span, ${d} input[type="radio"] + label span { 
      background: ${e.input_back_color}; 
      border: 1px solid ${e.input_border_color}; 
      border-radius: ${e.input_border_radius}px;
      width: ${c}px;
      height: ${c}px;
    }`, u += `${d} input[type="radio"]:checked + label span, ${d} input[type="checkbox"]:checked + label span {
      background: ${n};
      display: inline-flex;
      align-items: center;
      justify-content: center;
      position: relative;
    }`, u += `${d} input[type="radio"]:checked + label span:after,${d} input[type="checkbox"]:checked + label span:after{
      color: ${s}; 
      font-size: ${e.input_font_size}px;
      margin-left: 1px;
      top: 50%;
      left: 50%;
      transform: translate(-50%,-50%);
    }`, u += `${d} .form_container input[type="radio"] + label span {
      border-radius: 50%;
    }`, u += `${d} .infoMessage, .fileres {
      color: ${e.label_font_clr};
      font-size: ${e.input_font_size}px;
      ${i}
    }`, u += `${d} ::-webkit-input-placeholder{ 
      color: ${e.input_font_clr}; 
      ${o};
    }`, u += `${d} ::-moz-placeholder{
       color: ${e.input_font_clr}; 
       ${o};
    }`, u += `${d} ::-moz-placeholder{
       color: ${e.input_font_clr}; 
       ${o};
    }`, u += `${d} ::-ms-input-placeholder{
       color: ${e.input_font_clr}; 
       ${o};
    }`, u += `${d} .fileres{
      text-transform: capitalize;
    }`, e.form_width && e.form_width.includes("%") && (u += `
        @media only screen and (max-width: 769px) {
            ${d} .form_generater_form_div { max-width: 100%; }
        }`);
    var m = u;
    return e.advance_css && plan_features.includes("advanced-css") && (m += e.advance_css), m
}, window.alertFormMessgaes = function(e) {
    var t = "";
    if (t += '<div class="col-md-12 clearfix"><div class="alert_message" style="display:none;">', e.after_submit_msg && "" != e.after_submit_msg.to_s) t += '<div class="alert alert-success" role="alert" tabindex="0" aria-label="' + e.after_submit_msg.replace(/<\/?[^>]+(>|$)/g, "") + '" aria-describedby="Form Suceess message"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><p tabindex="0" aria-label="' + e.after_submit_msg.replace(/<\/?[^>]+(>|$)/g, "") + '" class="alert-success">' + e.after_submit_msg + "</div>";
    else {
        var a = getMessage(e, "thank_you");
        t += '<div id="thank-you-alert" class="alert alert-success" role="alert" tabindex="0" aria-label="' + a + '" aria-describedby="Form Success message" ><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><p tabindex="0" aria-label="' + a.replace(/<\/?[^>]+(>|$)/g, "") + '" class="alert-success">' + a + "</div>", t += "<script>$(document).ready(function() {var fadeOutTime = " + (e.form_timer_sec || 5) + ' * 1000;$("#thank-you-alert").fadeOut(fadeOutTime);});</script>'
    }
    return t + "</div></div>"
}, window.getCustomiseMessage = function(e, t) {
    if (plan_features.includes("customize-form-message") && e.custommessage && e.custommessage[t]) return e.custommessage[t];
    if (void 0 != customise_msgs) {
        if (plan_features.includes("customize-form-message") && Array.isArray(customise_msgs.shop_customise_msgs) && customise_msgs.shop_customise_msgs.length > 0) {
            let a = customise_msgs.shop_customise_msgs[0];
            if (a && a[t]) return a[t]
        }
        if (customise_msgs.default_customise_msgs && customise_msgs.default_customise_msgs[t]) return customise_msgs.default_customise_msgs[t]
    }
    return "Message not found"
}, window.handleFormSubmissionSchedule = function(e) {
    let t = (() => {
            try {
                let e = window.shop_timezone,
                    t = new Date,
                    a = new Intl.DateTimeFormat("en-US", {
                        timeZone: e,
                        year: "numeric",
                        month: "2-digit",
                        day: "2-digit",
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                        hour12: !1
                    }),
                    l = a.formatToParts(t).reduce((e, t) => (e[t.type] = t.value, e), {});
                return new Date(`${l.year}-${l.month}-${l.day}T${l.hour}:${l.minute}:${l.second}`)
            } catch (r) {
                return new Date
            }
        })(),
        a = !1,
        l = "";
    if (plan_features.includes("form-schedule")) {
        let r = null,
            i = null;
        if (e.schedule_start_date && "" !== e.schedule_start_date.trim()) try {
            let o = new Date(e.schedule_start_date).toLocaleString("en-US", {
                    timeZone: window.shop_timezone
                }),
                s = new Date(o);
            r = new Date(s.setHours(0, 0, 0, 0))
        } catch (n) {
            r = null
        }
        if (e.schedule_end_date && "" !== e.schedule_end_date.trim()) try {
            let c = new Date(e.schedule_end_date).toLocaleString("en-US", {
                    timeZone: window.shop_timezone
                }),
                d = new Date(c);
            i = new Date(d.setHours(23, 59, 59, 999))
        } catch (u) {
            i = null
        }
        if (e.schedule_start_time && "" !== e.schedule_start_time.trim() && r) try {
            let [m, p, f] = e.schedule_start_time.split(":").map(Number);
            r = new Date(r).setHours(m, p, f || 0)
        } catch (b) {}
        if (e.schedule_end_time && "" !== e.schedule_end_time.trim() && i) try {
            let [h, y, g] = e.schedule_end_time.split(":").map(Number);
            i = new Date(i).setHours(h, y, g || 0)
        } catch (v) {}
        r && r >= t && (a = !0, l = e.schedule_start_date_message ? .trim() || "Submissions before the start date are not accepted!"), i && i <= t && (a = !0, l = e.schedule_end_date_message ? .trim() || "Submissions after the due date are not accepted!")
    }
    return plan_features.includes("access-only-for-logged-in-users") && e.logged_in_users && "yes" == e.logged_in_users && "" == hulk_customer_email.trim() && (a = !0, l = e.form_access_message ? .trim() || "<p>Please login to access the form<br>Do not have an account? Create account</p>"), {
        submissionClose: a,
        submissionMessage: l
    }
}, window.handleAnalyticsIntegrationsScript = function(e) {
    window.validateDoubleQuotes = !1;
    var t = ["affiliate", "shopify_plus", "professional", "unlimited"];
    if (plan_features.includes("shopify-flow-trigger") && (window.checkShopifyFlowTrigger = function() {
            "yes" === e.flow_trigger_integration && shop_shopify_plan && t.includes(shop_shopify_plan.toString()) && (validateDoubleQuotes = !0)
        }), e && "responses" === e.after_submit && loadHtml2PdfScript(), plan_features.includes("google-analytics-4-by-measurement-id") && e.google_analytic_4_id && "" !== e.google_analytic_4_id) {
        var a = document.createElement("script");
        a.async = !0, a.src = "https://www.googletagmanager.com/gtag/js?id=" + e.google_analytic_4_id, document.head.appendChild(a);
        var l = document.createElement("script");
        l.type = "text/javascript", l.innerHTML = `
          var parenturl = (window.location !== window.parent.location) ? document.referrer : document.location;
          window.dataLayer = window.dataLayer || [];
          function gtag() {
              dataLayer.push(arguments);
          }
          gtag('js', new Date());
          gtag('config', '${e.google_analytic_4_id}', {
              page_path: parenturl,
              cookie_flags: "SameSite=None;Secure"
          });
      `, document.head.appendChild(l)
    }
    if (plan_features.includes("google-ads-for-tracking-conversion") && e.google_tag_conversion_id && "" !== e.google_tag_conversion_id && e.google_tag_conversion_label && "" !== e.google_tag_conversion_label) {
        var r = document.createElement("script");
        r.async = !0, r.src = "https://www.googletagmanager.com/gtag/js?id=AW-" + e.google_tag_conversion_id, document.head.appendChild(r);
        var i = document.createElement("script");
        i.type = "text/javascript", i.innerHTML = `
          window.dataLayer = window.dataLayer || [];
          function gtag() {
              dataLayer.push(arguments);
          }
          gtag('js', new Date());
          gtag('config', 'AW-' + '${e.google_tag_conversion_id}');
      `, document.head.appendChild(i)
    }
    if (plan_features.includes("facebook-pixel-id") && e.facebook_pixel_id && "" !== e.facebook_pixel_id) {
        var o = document.createElement("script");
        o.type = "text/javascript", o.innerHTML = `
          !function(f,b,e,v,n,t,s) {
              if(f.fbq) return;
              n=f.fbq=function() {
                  n.callMethod ?
                  n.callMethod.apply(n,arguments) : n.queue.push(arguments);
              };
              if(!f._fbq) f._fbq=n;
              n.push=n;n.loaded=!0;n.version='2.0';
              n.queue=[];
              t=b.createElement(e);t.async=!0;
              t.src=v;
              s=b.getElementsByTagName(e)[0];
              s.parentNode.insertBefore(t,s);
          }(window, document,'script', 'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '${e.facebook_pixel_id}');
          fbq('track', 'PageView');
      `, document.head.appendChild(o);
        var s = document.createElement("noscript");
        s.innerHTML = `<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=${e.facebook_pixel_id}&ev=PageView&noscript=1" alt="Facebook Pixel" />`, document.head.appendChild(s)
    }
    if (plan_features.includes("bing-uet-pixel-id") && e.bing_pixel_id && "" !== e.bing_pixel_id) {
        var n = document.createElement("script");
        n.type = "text/javascript", n.innerHTML = `
          (function(w,d,t,r,u) {
              var f,n,i;
              w[u]=w[u]||[],f=function() {
                  var o={ti:"${e.bing_pixel_id}"}; 
                  o.q=w[u];
                  w[u]=new UET(o);
                  w[u].push("pageLoad");
              },
              n=d.createElement(t),
              n.src=r,
              n.async=1,
              n.onload=n.onreadystatechange=function() {
                  var s=this.readyState;
                  s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null);
              },
              i=d.getElementsByTagName(t)[0],
              i.parentNode.insertBefore(n,i);
          })(window,document,"script","//bat.bing.com/bat.js","uetq");
      `, document.head.appendChild(n);
        var c = document.createElement("noscript");
        c.innerHTML = `<img src="//bat.bing.com/action/0?ti=${e.bing_pixel_id}&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" />`, document.head.appendChild(c)
    }
}, window.addtionalFormJS = function(e, t) {
    var a = `.hulk_form_${t}`;
    if (void 0 !== e.button_align) {
        var l = document.querySelector(`${a} .form_generater_form_div div.form_submit_div`);
        l ? "leftBtn" == e.button_align ? (l.classList.add("text-left"), l.classList.remove("text-center")) : "centerBtn" == e.button_align ? l.classList.add("text-center") : "rightBtn" == e.button_align && (l.classList.add("text-right"), l.classList.remove("text-center")) : console.warn("submitDiv not found in the DOM.")
    }
    if (void 0 !== e.form_banner_alignment) {
        var r = document.querySelector(`${a} .form_banner_div`);
        if (r) {
            var i = r.querySelector("img");
            i && ("left" == e.form_banner_alignment ? (i.style.float = "none", r.style.textAlign = "left") : "center" == e.form_banner_alignment ? (r.style.textAlign = "center", i.style.float = "none") : (i.style.float = "none", r.style.textAlign = "right"))
        }
    }
    formElementCount = 0, e.formElements.forEach(function(l, r) {
        if ("inlineLabels" == e.label_style) document.querySelectorAll(`${a} .formElement_${formElementCount}`).forEach(function(e) {
            if (l.email_validate_field_label, e.classList.contains("dateTime") || e.classList.contains("textfield") || e.classList.contains("url") || e.classList.contains("textarea") || e.classList.contains("number") || e.classList.contains("newDate") || e.classList.contains("Time") || e.classList.contains("multi_text")) try {
                let a = e.querySelector("label");
                if (a) {
                    a.style.display = "none";
                    let r = e.querySelector("input, textarea, select");
                    r && r.setAttribute("placeholder", a.textContent)
                }
            } catch (i) {
                console.error("Error processing label/input:", i)
            } else e.classList.contains("address") ? addressLabelChange("inlineLabels", formElementCount, t) : e.classList.contains("multi_column_text") && multiColumnLabelChange("inlineLabels", formElementCount, t);
            if (e.classList.contains("select")) {
                let o = e.querySelectorAll("label");
                try {
                    if (o.length > 0) {
                        o[0].style.display = "none";
                        let s = e.querySelector("select > option:first-child");
                        s && (s.textContent = o[0].textContent);
                        let n = e.querySelector("input");
                        o.length > 1 && n && (o[o.length - 1].style.display = "none", n.setAttribute("placeholder", o[o.length - 1].textContent))
                    }
                } catch (c) {
                    console.error("Error processing label/input:", c)
                }
            }
            if (e.classList.contains("checkbox-multi")) {
                let d = e.querySelector(".other-fields label:last-of-type");
                if (d) {
                    d.style.display = "none";
                    let u = e.querySelectorAll(".other-fields input, .other-fields textarea, .other-fields select"),
                        m = u.length ? u[u.length - 1] : null;
                    if (m) {
                        let p = d.textContent ? d.textContent.trim() : "";
                        m.setAttribute("placeholder", p), m.setAttribute("aria-placeholder", p)
                    }
                }
            }
            if (e.classList.contains("password")) {
                let f = e.querySelector("label:first-of-type"),
                    b = e.querySelector("input, textarea, select"),
                    h = e.querySelectorAll("label"),
                    y = h.length > 0 ? h[h.length - 1] : null,
                    g = e.querySelectorAll("input, textarea, select"),
                    v = g.length > 0 ? g[g.length - 1] : null;
                if (f) {
                    f.style.display = "none";
                    let x = f.textContent;
                    b && b.setAttribute("placeholder", x)
                }
                if (y) {
                    let S = y.textContent;
                    y.style.display = "none", v && (v.setAttribute("placeholder", S), v.setAttribute("aria-placeholder", S))
                }
            }
            if (e.classList.contains("email")) {
                let $ = e.querySelectorAll("label");
                if (1 === $.length) {
                    let q = $[0],
                        k = e.querySelector("input, textarea, select");
                    if (q && k) {
                        let L = q.textContent;
                        q.removeAttribute("for"), q.style.display = "none", k.removeAttribute("id"), k.setAttribute("placeholder", L), k.setAttribute("aria-placeholder", L)
                    }
                    e.classList.remove("has-float-label")
                } else if ($.length > 1) {
                    let w = $[0],
                        E = $[$.length - 1],
                        A = e.querySelectorAll("input, textarea, select"),
                        C = A.length > 0 ? A[0] : null,
                        _ = A.length > 1 ? A[A.length - 1] : null;
                    if (w && C) {
                        let T = w.textContent;
                        w.removeAttribute("for"), w.style.display = "none", C.removeAttribute("id"), C.setAttribute("placeholder", T), C.setAttribute("aria-placeholder", T)
                    }
                    if (E && _) {
                        let M = E.textContent.trim();
                        "" === M && (M = w.textContent || ""), E.removeAttribute("for"), E.style.display = "none", E.textContent = M, _.removeAttribute("id"), _.style.marginTop = "10px", _.setAttribute("placeholder", M), _.setAttribute("aria-placeholder", M)
                    }
                    e.querySelectorAll("div").forEach(e => e.classList.remove("has-float-label"))
                }
            }
            if (e.classList.contains("validation_field")) {
                let F = e.querySelector("label:first-of-type"),
                    j = e.querySelector("input, textarea, select"),
                    N = e.querySelectorAll("label"),
                    z = N.length > 0 ? N[N.length - 1] : null,
                    H = e.querySelectorAll("input, textarea, select"),
                    B = H.length > 0 ? H[H.length - 1] : null;
                if (F && j) {
                    let I = F.textContent;
                    F.style.display = "none", j.setAttribute("placeholder", I), B.setAttribute("aria-placeholder", I), B.style.marginTop = "10px"
                }
                if (z) {
                    let D = z.textContent.trim();
                    "" === D ? (z.style.display = "none", B && B.setAttribute("placeholder", F ? F.textContent : "")) : (z.style.display = "none", B && (B.setAttribute("placeholder", D), B.setAttribute("aria-placeholder", D)))
                }
            }
        });
        else if ("blockLabels" == e.label_style) {
            let i = void 0 !== l.placeholder ? l.placeholder : "",
                o = void 0 !== l.field2_validation_label ? l.field2_validation_label : "",
                s = void 0 !== l.field2_validation_placeholder ? l.field2_validation_placeholder : "",
                n = void 0 !== l.another_field ? l.another_field : "";
            document.querySelectorAll(`${a} .formElement_${formElementCount}`).forEach(function(a) {
                if (a.classList.contains("textfield") || a.classList.contains("textarea") || a.classList.contains("number") || a.classList.contains("email")) {
                    let r = a.querySelectorAll("label"),
                        c = a.querySelector("input, textarea");
                    r.forEach(e => {
                        e.style.display = "block"
                    }), c && (c.placeholder = i)
                }
                if (a.classList.contains("address") && addressLabelChange("blockLabels", formElementCount, t), a.classList.contains("multi_column_text") && multiColumnLabelChange("blockLabels", formElementCount, t), a.classList.contains("select")) {
                    i = "" === i ? getMessage(e, "please_select") : i;
                    let d = a.querySelector("label"),
                        u = a.querySelector("select");
                    if (d && (d.style.display = "block"), u) {
                        let m = u.querySelector("option:first-child");
                        m && (m.textContent = i), d.after(u)
                    }
                }
                if (a.classList.contains("email")) {
                    let p = "";
                    if (void 0 !== l && void 0 !== l.email_validate_field_placeholder) {
                        p = l.email_validate_field_placeholder;
                        let f = a.querySelectorAll("input");
                        f.length > 1 && (f[f.length - 1].placeholder = p)
                    }
                    a.querySelector("label").style.display = "block"
                }
                if (a.classList.contains("validation_field") && "yes" === n) {
                    let b = a.querySelectorAll("label"),
                        h = a.querySelectorAll("input");
                    if (b.length > 0) {
                        let y = b[b.length - 1];
                        y.setAttribute("for", ""), y.style.marginTop = "5px", y.style.display = "block", y.textContent = o
                    }
                    if (h.length > 0) {
                        let g = h[h.length - 1];
                        g.setAttribute("id", ""), g.style.marginTop = "0px", g.setAttribute("placeholder", s), b.length > 0 && b[b.length - 1].after(g)
                    }
                    let v = a.querySelector("div");
                    v && v.classList.remove("has-float-label")
                }
            })
        } else document.querySelectorAll(`${a} .formElement_${formElementCount}`).forEach(function(a) {
            let r = l.placeholder || "";
            if (a.classList.contains("dateTime") || a.classList.contains("textfield") || a.classList.contains("url") || a.classList.contains("textarea") || a.classList.contains("number") || a.classList.contains("newDate") || a.classList.contains("Time")) {
                (a.classList.contains("dateTime") || a.classList.contains("newDate") || a.classList.contains("Time")) && (a.querySelectorAll("div").forEach(e => {
                    e.style.marginLeft = "0px", e.style.marginRight = "0px"
                }), a.querySelectorAll("label").forEach(e => {
                    e.classList.remove("col-sm-12"), e.classList.add("col-sm-0")
                }));
                let i = a.querySelector("label"),
                    o = a.querySelector("input, textarea, select");
                i && o && (o.id = i.textContent.trim(), i.setAttribute("for", i.textContent.trim()), i.style.display = "block", i.before(o), a.classList.add("has-float-label"))
            } else a.classList.contains("address") ? addressLabelChange("floatingLabels", formElementCount, t) : a.classList.contains("multi_column_text") && multiColumnLabelChange("floatingLabels", formElementCount, t);
            if (a.classList.contains("select")) {
                let s = "" === r ? getMessage(e, "please_select") : r,
                    n = a.querySelector("label:first-of-type");
                n && (n.style.display = "block", n.style.left = "5px");
                let c = a.querySelector("select > option:first-child");
                c && (c.textContent = s);
                let d = a.querySelector("select");
                d && n && d.before(n);
                a.querySelectorAll(".for-floating-label").forEach(e => {
                    e.classList.add("has-float-label")
                })
            }
            if (a.classList.contains("checkbox-multi")) {
                let u = a.querySelector(".other-fields label:last-of-type"),
                    m = a.querySelector(".other-fields input:last-of-type");
                u && m && (u.style.display = "block", u.textContent = u.textContent.trim(), u.before(m), m.placeholder = u.textContent, m.id = u.textContent, u.setAttribute("for", u.textContent), a.querySelector(".for-floating-label").classList.add("has-float-label"))
            }
            if (a.classList.contains("password")) {
                var p = a.querySelector("label"),
                    f = a.querySelector("input");
                if (p && f) {
                    var b = p.textContent.trim();
                    p.setAttribute("for", b), f.id = b, f.placeholder = b, p.style.display = "block", p.textContent = b, p.parentNode.insertBefore(f, p), a.classList.add("has-float-label")
                }
                var h = a.querySelectorAll("label"),
                    y = a.querySelectorAll("input");
                if (h.length > 1 && y.length > 1) {
                    var g = h[h.length - 1],
                        v = y[y.length - 1],
                        x = g.textContent.trim();
                    g.setAttribute("for", x), v.id = x, v.placeholder = x, g.style.display = "block", g.textContent = x, a.querySelectorAll('label[name$="_label"]').forEach(function(e) {
                        e.style.left = "6px"
                    }), g.parentNode.insertBefore(v, g)
                }
                var S = a.querySelectorAll("div");
                S.forEach(function(e) {
                    e.classList.add("has-float-label")
                })
            }
            if (a.classList.contains("email")) {
                var h = a.querySelectorAll("label");
                if (1 === h.length) {
                    var $ = a.querySelector("input"),
                        q = h[0];
                    $.id = q.textContent.trim(), q.setAttribute("for", q.textContent.trim()), q.style.display = "block", q.textContent = q.textContent.trim(), $.placeholder = q.textContent.trim(), q.style.left = "20px", q.style.marginTop = "0px", $.style.marginTop = "0px", q.parentNode.insertBefore($, q), a.classList.add("has-float-label")
                } else {
                    var f = a.querySelector("input"),
                        p = h[0];
                    f.id = p.textContent.trim(), p.setAttribute("for", p.textContent.trim()), p.style.display = "block", p.textContent = p.textContent.trim(), f.placeholder = p.textContent.trim(), p.style.left = "20px", p.style.marginTop = "10px", f.style.marginTop = "10px", p.parentNode.insertBefore(f, p), a.classList.add("has-float-label");
                    var k = h[h.length - 1].textContent.trim() || p.textContent.trim(),
                        g = h[h.length - 1],
                        v = a.querySelectorAll("input")[a.querySelectorAll("input").length - 1];
                    g.setAttribute("for", k), v.id = k, v.placeholder = k, g.style.display = "block", g.textContent = k, g.style.left = "6px", g.style.marginTop = "0px", v.style.marginTop = "10px", g.parentNode.insertBefore(v, g);
                    var S = a.querySelectorAll("div");
                    S.length > 0 && S[S.length - 1].classList.add("has-float-label")
                }
            }
            if (a.classList.contains("validation_field")) {
                var p = a.querySelector("label"),
                    f = a.querySelector("input");
                if (p && f) {
                    var b = p.textContent.trim();
                    p.setAttribute("for", b), f.id = b, f.placeholder = b, p.style.display = "block", p.textContent = b, p.parentNode.insertBefore(f, p), a.classList.add("has-float-label")
                }
                var h = a.querySelectorAll("label"),
                    y = a.querySelectorAll("input");
                if (h.length > 1 && y.length > 1) {
                    var g = h[h.length - 1],
                        v = y[y.length - 1],
                        L = "" === g.textContent.trim() ? b : g.textContent.trim();
                    g.setAttribute("for", L), v.id = L, v.placeholder = L, g.style.display = "block", g.textContent = L, g.style.left = "6px", g.style.marginTop = "0px", v.style.marginTop = "10px", g.parentNode.insertBefore(v, g)
                }
                var S = a.querySelectorAll("div");
                S.forEach(function(e) {
                    e.classList.add("has-float-label")
                })
            }
            if (a.classList.contains("multi_text")) {
                let w = a.querySelector("label"),
                    E = a.querySelector("input");
                if (w && E) {
                    let A = w.textContent.trim();
                    E.id = A, w.setAttribute("for", A), w.style.display = "block", w.textContent = A, E.placeholder = A, E.after(w), a.classList.add("has-float-label")
                }
            }
        });
        formElementCount++
    })
}, window.addressLabelChange = function(e, t, a) {
    addressFormLabelChange(e, t, a)
}, window.addressFormLabelChange = function(e, t, a) {
    var l = `.hulk_form_${a}`;
    document.querySelector(`${l} .formElement_${t}`).querySelectorAll("input,select").forEach(function(t) {
        var a = t.closest(".form-group"),
            l = a.querySelector("label"),
            r = l ? l.textContent : "";
        if ("inlineLabels" === e) {
            if (l.style.display = "none", "Country" === r) {
                var i = t.querySelector("option:first-child");
                i && (i.textContent = r)
            } else t.setAttribute("placeholder", r)
        } else if ("blockLabels" === e) {
            if (l.style.display = "block", "Country" === r) {
                var i = t.querySelector("option:first-child");
                i && (i.textContent = "- Country -")
            } else t.setAttribute("placeholder", "")
        } else if (l.style.display = "block", "Country" === r) {
            l.textContent = r;
            var i = t.querySelector("option:first-child");
            i && (i.textContent = r), a.insertBefore(t, l), a.classList.add("has-float-label")
        } else t.setAttribute("id", r), l.setAttribute("for", r), t.setAttribute("placeholder", r), a.insertBefore(t, l), a.classList.add("has-float-label")
    })
}, window.multiColumnFormLabelChange = function(e, t, a) {
    var l = `.hulk_form_${a}`,
        r = document.querySelector(`${l} .formElement_${t}`),
        i = r.querySelector(".column1-desc"),
        o = r.querySelector(".column2-desc");
    i && i.classList.remove("has-float-label"), o && o.classList.remove("has-float-label");
    var s = r.querySelector(".column1-desc .header_column1"),
        n = r.querySelector(".column2-desc .header_column2");
    if (s && s.remove(), n && n.remove(), r.classList.remove("has-float-label"), "inlineLabels" === e) try {
        var c = r.querySelectorAll("input");
        c.forEach(function(e) {
            var t = e.closest(".form-group").querySelector(".row"),
                a = t ? t.querySelector(".header_column1") : null,
                l = t ? t.querySelector(".header_column2") : null;
            a && (a.style.display = "none"), l && (l.style.display = "none");
            var r = a ? a.textContent : "",
                i = l ? l.textContent : "";
            "key" === e.name ? e.setAttribute("placeholder", r) : e.setAttribute("placeholder", i)
        })
    } catch (d) {
        console.error("Error processing label/input:", d)
    } else if ("blockLabels" === e) {
        var c = r.querySelectorAll("input");
        c.forEach(function(e) {
            var t = e.closest(".form-group").querySelector(".row"),
                a = t ? t.querySelector(".header_column1") : null,
                l = t ? t.querySelector(".header_column2") : null;
            a && (a.style.display = "block"), l && (l.style.display = "block"), e.setAttribute("placeholder", "")
        })
    } else {
        let u = document.querySelector(".formElement_" + t);
        if (u) {
            u.classList.add("has-float-label");
            let m = u.querySelectorAll("input, select, textarea");
            m.forEach(function(e) {
                let t = e.closest(".form-group");
                if (t) {
                    let a = t.querySelectorAll("label");
                    if (a.length > 0) {
                        a.forEach(e => {
                            e.style.display = "block"
                        });
                        let l = a[0];
                        l.style.fontSize = "14px", l.style.left = "15px"
                    }
                    let r = t.querySelector(".row .header_column1"),
                        i = t.querySelector(".row .header_column2"),
                        o = r ? r.textContent.trim() : "",
                        s = i ? i.textContent.trim() : "";
                    if ("key" === e.name) {
                        e.setAttribute("placeholder", o);
                        let n = document.createElement("label");
                        n.className = "col-sm-6 header_column1 block_label", n.setAttribute("for", o), n.textContent = o;
                        let c = e.closest("div.column1-desc");
                        if (c) {
                            let d = c.querySelector("input") || e;
                            d.insertAdjacentElement("afterend", n), c.classList.add("has-float-label")
                        }
                    } else {
                        e.setAttribute("placeholder", s);
                        let u = document.createElement("label");
                        u.className = "col-sm-6 header_column2 block_label", u.setAttribute("for", s), u.textContent = s;
                        let m = e.closest("div.column2-desc");
                        if (m) {
                            let p = m.querySelector("input") || e;
                            p.insertAdjacentElement("afterend", u), m.classList.add("has-float-label")
                        }
                    }
                }
            });
            let p = u.querySelector(".row .header_column1"),
                f = u.querySelector(".row .header_column2");
            p && (p.style.display = "none"), f && (f.style.display = "none")
        }
    }
}, window.multiColumnLabelChange = function(e, t, a) {
    multiColumnFormLabelChange(e, t, a)
}, window.fontAwesomeScript = function() {
    var e = document.createElement("link");
    e.rel = "stylesheet", e.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css", document.head.appendChild(e);
    var t = document.createElement("script");
    t.type = "text/javascript", t.src = form_url + "/corepage/js/sweetalert.min.js", document.head.appendChild(t)
}, window.generateTitle = function(e) {
    return generateFormTitle(e)
}, window.addtionalJS = function(e, t) {
    addtionalFormJS(e, t)
}, window.handleFormLayout = function(e, t, a) {
    var l = `.hulk_form_${t}`;
    if (str = (str = (str = "<style>" + generateCSS(e, t) + "</style>") + '<style id="' + t + '_picture_choice_css"></style>') + '<style id="' + t + '_product_choice_css"></style>', "System Fonts" === e.label_fonts_type || ("Custom Fonts" === e.label_fonts_type ? void 0 !== e.label_custom_font_name && void 0 !== e.label_custom_font_url && (str += `
                  <style>
                      @font-face {
                          font-family: '${e.label_custom_font_name}';
                          src: url('${e.label_custom_font_url}');
                      }
                  </style>
              `) : void 0 !== e.label_font_family && (str += `<link href="https://fonts.googleapis.com/css?family=${encodeURIComponent(e.label_font_family)}" rel="stylesheet" type="text/css">`)), "System Fonts" === e.input_fonts_type);
    else if ("Custom Fonts" === e.input_fonts_type) {
        if (void 0 !== e.input_custom_font_name && void 0 !== e.input_custom_font_url) {
            var r = document.createElement("style");
            r.textContent = `
                  @font-face {
                      font-family: '${e.input_custom_font_name}';
                      src: url('${e.input_custom_font_url}');
                  }
              `, document.head.appendChild(r)
        }
    } else if (void 0 !== e.input_font_family) {
        var i = document.createElement("link");
        i.href = "https://fonts.googleapis.com/css?family=" + encodeURIComponent(e.input_font_family), i.rel = "stylesheet", i.type = "text/css", document.head.appendChild(i)
    }
    var o = "",
        s = "",
        n = "";
    let c = handleSubmissionSchedule(e);
    if (c && !0 == c.submissionClose && c.submissionMessage) o += '<div id="wizard-validation-form" class="hulk_form_' + t + '"><div class="after_form_submit"><div class="form_generater_form_div text-center form_schedule_submission_text">' + c.submissionMessage + "</div></div>";
    else {
        o += '<div id="wizard-validation-form" class="hulk_form_' + t + '">', o += '<div class="formContainer"><form action="#" method="post" id="formGeneratorForm"><div class="form_generater_form_div"><div class="tab"><div class="row">', (e.form_title || e.form_description || e.form_banner) && (o += generateTitle(e)), o += alertMEssgaes(e), o += '<div class="col-md-12 form_element clearfix">', o += '<div class="row form_container">';
        var d = 0,
            u = "";
        label_style = e.label_style, e.formElements.forEach(function(a, r) {
            var i = d,
                c = a.type,
                m = "";
            a.addmore && a.addmore, payment_class = ["elementCost"].count > 0 ? "paymentCount" : "", halfwidth = a.halfwidth && "yes" == a.halfwidth ? "checked" : "", infoMessageHTML = a.infoMessage && plan_features.includes("elements-add-ons") ? "<p tabindex='0' aria-label='" + a.infoMessage.replace(/<\/?[^>]+(>|$)/g, "") + "' class='infoMessage'>" + a.infoMessage + "</p>" : "", elementHolder = a.placeholder && plan_features.includes("elements-add-ons") ? a.placeholder : "", aria_require = " required" == (required = a.required && "yes" == a.required ? " required" : "") ? "true" : "false", values = a.values ? a.values : "", align = a.align ? a.align : "horizontal", customClass = a.customClass ? " " + a.customClass : "", customID = a.customID ? a.customID : "form_input_" + i, labelType = a.label ? a.label : "", label = " required" == required ? '<label class="fitText block_label" tabindex="0"  for="' + customID + '"  aria-label="' + labelType + '" >' + labelType + "*</label>" : '<label class="fitText block_label" for="' + customID + '" tabindex="0"  aria-label="' + labelType + '">' + labelType + "</label>", E = '<input class="form-control' + customClass + required + '" aria-required="' + aria_require + '" name="' + labelType + '" id="' + customID + '" type="text" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '">', width_class = "checked" == halfwidth ? "col-sm-6" : "col-sm-12", a.centerfield && "yes" == a.centerfield && (width_class += " centerfield");
            let p = [],
                f = "";
            if (a.Conditions && a.Conditions.SelectedElemenet && a.Conditions.SelectedValue && "" !== a.Conditions.SelectedValue) {
                let b = "";
                if ("" !== a.Conditions.SelectedValue.trim()) {
                    f = `conditionInclude_${d}`;
                    let h = a.Conditions.SelectedElemenetCount || 0,
                        y = e.formElements ? .[h] ? .type || "",
                        g = "";
                    "checkbox" === y && "On" === a.Conditions.SelectedValue ? (e.formElements ? .[h] ? .checked === "yes" ? g += `document.querySelector('${l} .formElement_${i}').removeAttribute('id');` : g += `document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');`, g += `
                            document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount} input[type=checkbox]')
                                .addEventListener('change', function() {
                                    if (this.checked) {
                                        document.querySelector('${l} .formElement_${i}').removeAttribute('id');
                                    } else {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    }
                                    conditionalHide('formElement_${i}');
                                });
                        `) : "checkbox" === y && "Off" === a.Conditions.SelectedValue && (e.formElements ? .[h] ? .checked === "yes" ? g += `document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');` : g += `document.querySelector('${l} .formElement_${i}').removeAttribute('id');`, g += `
                            document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount} input[type=checkbox]')
                                .addEventListener('change', function() {
                                    if (this.checked) {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    } else {
                                        document.querySelector('${l} .formElement_${i}').removeAttribute('id');
                                    }
                                    conditionalHide('formElement_${i}');
                                });
                        `);
                    let v = "";
                    "radio" === y && (v += `
                            document.querySelectorAll('${l} .formElement_${a.Conditions.SelectedElemenetCount} input[type=radio]')
                                .forEach(radio => radio.addEventListener('change', function() {
                                    const selectedValue = document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount} input[type=radio]:checked')?.value || '';
                                    if (document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount}').hidden) {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    } else if (selectedValue === '${a.Conditions.SelectedValue}') {
                                        document.querySelector('${l} .formElement_${i}').removeAttribute('id');
                                    } else {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    }
                                    conditionalHide('formElement_${i}');
                                }));
                        `);
                    let x = "";
                    "select" === y && (x += `
                            document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount} select')
                                .addEventListener('change', function() {
                                    if (document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount}').hidden) {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    } else if (this.value === '${a.Conditions.SelectedValue}') {
                                        document.querySelector('${l} .formElement_${i}').removeAttribute('id');
                                    } else {
                                        document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                                    }
                                    conditionalHide('formElement_${i}');
                                });
                        `);
                    let S = "";
                    "multipleCheckbox" === y && (S += `
                        document.querySelectorAll('${l} .formElement_${a.Conditions.SelectedElemenetCount} input[type="checkbox"][value="${a.Conditions.SelectedValue}"]')
                          .forEach(function(checkbox) {
                            checkbox.addEventListener('change', function() {
                              if (document.querySelector('${l} .formElement_${a.Conditions.SelectedElemenetCount}').hidden) {
                                document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                              } else if (this.checked) {
                                document.querySelector('${l} .formElement_${i}').removeAttribute('id');
                              } else {
                                document.querySelector('${l} .formElement_${i}').setAttribute('id', '${f}');
                              }
                              conditionalHide('formElement_${i}');
                            });
                          });
                      `), u += b = v + g + x + S
                }
                p.includes(a.Conditions.SelectedElemenetCount) || p.push(a.Conditions.SelectedElemenetCount)
            }
            if ("text" == c) m = "textfield";
            else if ("multi_text" == c) E = '<div class="input_fields_' + i + '_wrap"> <div style="display: flex;"> <input class="form-control add_element_' + i + required + customClass + '" id="' + customID + '" name="' + labelType + '" type="text" placeholder="' + elementHolder + '"> <button style="border: unset; background: none; margin-left: 10px;font-size: 25px; color: gray;width:16px;height: 16px;margin-top: -3px;" class="add_' + i + '_button" data-form-element="' + t + '" data-max="' + (all_text_multi = a.textnoMultiple ? a.textnoMultiple : 5) + '">+</button></div></div>', m = "multi_text";
            else if ("multi_column_text" == c) all_text_multi = a.textnoMultiple ? a.textnoMultiple : 5, E = '<div class="input_fields_' + i + '_wrap">' + (header = "<div class='row' style='display: flex;'><div class='col-sm-6 header_column1' style='width: 48%;'>" + (column1_text = a.column1 ? a.column1 : "") + "</div><div class='col-sm-6 header_column2' style='width: 48%;'>" + (column2_text = a.column2 ? a.column2 : "") + "</div></div>") + ' <div class="multi-column-input-main ' + customClass + '" id="' + customID + '"><div class="multi-column-input multi-column-input-' + i + '"><div class="column1-desc"><input class="form-control add_element_' + i + required + '"  name="key" aria-required="' + aria_require + '"  type="text" id="' + column1_text + '"></div><div class="column2-desc"><input class="form-control add_element_' + i + required + '" name="value" aria-required="' + aria_require + '"  type="text" id="' + column2_text + '"></div><button  class="multi-column_button add_' + i + '_rowbutton" data-form-element="' + t + '" data-element="' + i + '" data-max="' + all_text_multi + '"  data-required="' + required + '" aria-label="Add ' + labelType + '">+</button></div></div></div>', m = "multi_column_text";
            else if ("checkbox" == c) name = "Checkbox", checked = a.checked && "yes" == a.checked ? "checked" : "", result_in_yes_no = a.result_in_yes_no && "yes" == a.result_in_yes_no ? " result_in_yes_no" : "", req_star = " required" == required ? "*" : "", aria_checked = a.checked && "yes" == a.checked ? "true" : "false", label = "", E = '<div class="checkbox checkbox-list input' + i + '" aria-prechecked="' + aria_checked + '"><label class="checkbox-inline" for="' + customID + '" tabindex="0" aria-label="' + labelType + '"><input type="checkbox" name="' + labelType + '" class="' + customClass + required + " " + result_in_yes_no + '" aria-required="' + aria_require + '" id="Checkbox' + i + "-" + t + '" ' + checked + ' aria-checked="' + aria_checked + '" role="checkbox"><label for="Checkbox' + i + "-" + t + '" aria-label="' + labelType + '"><span class="' + customClass + '" id="' + customID + '"></span>' + labelType + req_star + "</label></label></div>", m = "checkbox";
            else if ("password" == c) {
                var $ = a.passwordLimit ? a.passwordLimit : 8,
                    q = a.passwordMaxLimit ? a.passwordMaxLimit : 12,
                    k = a.confirm_value_placeholder ? a.confirm_value_placeholder : "",
                    L = "<label class='fitText block_label confirm-password-label-" + i + "' tabindex='0' aria-label='" + a.confirm_value_label + "' style='display: " + ("yes" == a.confirm_value ? "block" : "none") + ";' name='confirm_" + i + "_label'>" + a.confirm_value_label + "*</label>",
                    w = "<input class='form-control confirm-password-hidden-" + i + " " + customClass + "' aria-valuemin='" + $ + "' aria-valuemax='" + q + "' minlength='" + $ + "' maxlength='" + q + "' style='display: " + ("yes" == a.confirm_value ? "block" : "none") + ";' name='confirm_" + i + "_input' id='" + customID + "' type='password' aria-placeholder='" + k + "' placeholder='" + k + "'><i class='toggle-password-confirm fa fa-fw fa-eye-slash' style='float: right; cursor: pointer; margin-right: 10px; margin-top:-25px;'></i>",
                    E = "<input class='form-control " + customClass + " " + required + "' name='" + labelType + "' id='password" + customID + "' aria-valuemin='" + $ + "' aria-valuemax='" + q + "' minlength='" + $ + "' maxlength='" + q + "' type='password' aria-required='" + aria_require + "' aria-placeholder='" + elementHolder + "' placeholder='" + elementHolder + "'><i class='toggle-password fa fa-fw fa-eye-slash' style='float: right; cursor: pointer; margin-right: 10px; margin-top:-25px;'></i>";
                "yes" == a.confirm_value ? E += "<div style='margin-top: 5px;' class='confirm-fields for-floating-label confirm-password-span-" + i + "'>" + L + w + "</div>" : E = "<input class='form-control " + customClass + " " + required + "' name='" + labelType + "' id='" + customID + "' aria-required='" + aria_require + "' aria-valuemin='" + $ + "' aria-valuemax='" + q + "' minlength='" + $ + "' maxlength='" + q + "' type='password' aria-placeholder='" + elementHolder + "' placeholder='" + elementHolder + "'><i class='toggle-password fa fa-fw fa-eye-slash' style='float: right; cursor: pointer; margin-right: 10px; margin-top:-25px;'></i>", m = "password"
            } else if ("textarea" == c) limitCharacters = a.limitCharacters ? a.limitCharacters : "", inputHeightStyle = a.inputHeight ? 'style="height: ' + a.inputHeight + 'px"' : "", E = "" != limitCharacters ? '<textarea class="form-control' + required + customClass + '" id="' + customID + '" ' + inputHeightStyle + ' name="' + labelType + '" data-max="250" maxlength="' + limitCharacters + '" aria-valuemax="' + limitCharacters + '" data-limiting="false" style="height: 50px" aria-multiline="true" aria-required="' + aria_require + '" aria-placeholder="' + elementHolder + '"  placeholder="' + elementHolder + '"></textarea>' : '<textarea class="form-control' + required + customClass + '" id="' + customID + '" ' + inputHeightStyle + ' name="' + labelType + '" data-max="250" aria-valuemax="250" data-limiting="false" style="height: 50px" aria-required="' + aria_require + '" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '"></textarea>', m = "textarea";
            else if ("select" == c) {
                select_msg = getMessage(e, "please_select"), elementHolder = "" !== elementHolder ? elementHolder : select_msg;
                let A = values.split("\n");
                E = "yes" === a.other_value ? '<select name="' + labelType + '" aria-label="' + labelType + '" class="form-control ' + required + " " + customClass + " input" + i + '" aria-required="' + aria_require + '" id="' + customID + '" other_value="1"><option value="" aria-required="' + aria_require + '" aria-placeholder="' + elementHolder + '"> ' + elementHolder + " </option>" : '<select name="' + labelType + '" aria-label="' + labelType + '" class="form-control ' + required + " " + customClass + " input" + i + '" aria-required="' + aria_require + '" id="' + customID + '" other_value="0"><option value="" aria-placeholder="' + elementHolder + '"> ' + elementHolder + " </option>", "" !== values && A.forEach(function(e) {
                    let t = e.split("||");
                    t.length > 1 ? E += '<option value="' + t[1] + '"> ' + t[0] + " </option>" : E += '<option value="' + e + '"> ' + e + " </option>"
                });
                let C = "<label class='fitText block_label other-value-label-" + i + "' for='" + customID + "' style='display: " + ("yes" === a.other_value ? "block" : "none") + ";' name='other_" + i + "_label' aria-hidden='true' aria-required='true' aria-label='" + a.other_value_label + "'>" + a.other_value_label + "*</label>",
                    _ = "<input class='form-control other_class " + customClass + " other-value-hidden-" + i + "' id='" + customID + "' style='display: " + ("yes" === a.other_value ? "block" : "none") + ";' aria-required='true' name='other_value' type='text' aria-hidden='true'>";
                "yes" === a.other_value ? E += "</select></div><div class='col-sm-12 form-group other-fields for-floating-label optional-field-span-" + i + "' style='display: none;padding: 0'>" + C + _ + "</div></div></div>" : E += "</select></div></div></div>", "yes" === a.other_value && document.addEventListener("change", function(e) {
                    e.target.matches(`.hulk_form_${t} .formElement_${i} select`) && update(i, t)
                }), m = "select"
            } else if ("radio" == c) select_values = values.split("\n"), E = '<div class="radio-list input' + i + " " + align + '">', rad_ct = 0, "" !== values && select_values.forEach((e, a) => {
                E += `<label class="radio-inline ${align}" tabindex="0" aria-label="${e}"><input type="radio" id="input${i}${a}${t}" class="${customClass}" value="${e}" name="${labelType}"><label for="input${i}${a}${t}"><span class="${customClass}" id="${customID}"></span>${e}</label></label>`
            }), E += "</div>", m = "radio";
            else if ("multipleCheckbox" === c) {
                select_values = values.split("\n"), E = "yes" === a.other_for_multi_value ? `<div other_value="1" class="checkbox-multiple checkbox-list input${i} ${align}">` : `<div other_value="0" class="checkbox-multiple checkbox-list input${i} ${align}">`;
                let T = 0;
                "" !== values && select_values.forEach(e => {
                    E += `
                            <label class="checkbox-inline ${align}" tabindex="0" aria-label="${e}">
                                <input type="checkbox" id="input${i}${T}${t}" value="${e}" class="checkboxmulti_${i}" name="${labelType}" role="checkbox">
                                <label for="input${i}${T}${t}">
                                    <span class="${customClass}" id="${customID}"></span>${e}
                                </label>
                            </label>`, T++
                }), "yes" === a.other_for_multi_value && document.addEventListener("change", function(e) {
                    e.target.matches(`.hulk_form_${t} .formElement_${i} input[type='checkbox']`) && multiUpdate(i, t)
                });
                let M = `
                    <label class="fitText block_label other-multi-value-label-${i}" 
                           style="display: ${"yes"===a.other_for_multi_value?"block":"none"};" 
                           for="${customID}" 
                           name="other_${i}_label">
                        ${a.other_multi_checkbox_label}*
                    </label>`,
                    F = `
                    <input class="form-control other_class ${customClass} other-multi-value-hidden-${i}" 
                           id="${customID}" 
                           style="display: ${"yes"===a.other_for_multi_value?"block":"none"};" 
                           name="other_value" 
                           type="text">`;
                "yes" === a.other_for_multi_value ? E += `
                        <div class="m-t-10 other-fields for-floating-label optional-multi-field-span-${i}" style="display: none;">
                            ${M} 
                            ${F}
                        </div>
                    </div>` : E += "</div>", m = "checkbox-multi"
            } else if ("url" === c) E = '<input class="form-control' + required + " url" + customClass + '" id="' + customID + '" name="' + labelType + '" aria-label="' + labelType + '" type="text" tabindex="0" aria-required="' + aria_require + '" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '">', m = "url";
            else if ("number" === c) maxNumber = a.maxNumber ? 'max="' + a.maxNumber + '"' : "", minNumber = a.minNumber ? 'min="' + a.minNumber + '"' : "", ariaMaxValue = a.maxNumber ? a.maxNumber : "", E = '<input class="form-control' + required + customClass + '" id="' + customID + '" ' + minNumber + " " + maxNumber + ' name="' + labelType + '" type="number" aria-placeholder="' + elementHolder + '" aria-valuemin="' + (ariaMinValue = a.minNumber ? a.minNumber : "") + '" aria-valuemax="' + ariaMaxValue + '" aria-required="' + aria_require + '" placeholder="' + elementHolder + '" onkeydown="preventInvalidInput(event)">', m = "number";
            else if ("validation_field" === c) field2_validation_label = a.field2_validation_label ? a.field2_validation_label : "", field2_validation_placeholder = a.field2_validation_placeholder ? a.field2_validation_placeholder : elementHolder, E = "yes" == a.another_field ? E + "<div><label name=validation_" + i + '_label2  class="fitText block_label validation-label2-' + i + '" style="margin-top: 18px;" tabindex="0" aria-label="' + field2_validation_label + '">' + field2_validation_label + '</label><input class="form-control ' + required + " " + customClass + " element_" + i + '_second" id="' + customID + '" name="' + labelType + '" type="text" aria-placeholder="' + field2_validation_placeholder + '" placeholder="' + field2_validation_placeholder + '"></div>' : E + "<div><label name=validation_" + i + '_label2  class="fitText block_label validation-label2-' + i + '" style="display: none;"></label><input class="form-control ' + required + " " + customClass + " element_" + i + '_second" id="' + customID + '" name="' + labelType + '" type="text" aria-required="' + aria_require + '" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '" style="margin-top: 10px;"></div>', m = "validation_field";
            else if ("hidden" === c) E = '<input class="form-control ' + required + ' hidden" aria-hidden="true" name="' + labelType + '" type="hidden" value="' + (fieldvalue = a.fieldvalue || "") + '">', m = "hidden";
            else if ("address" === c) E = '<div class="row"><div class="col-sm-12 form-group"><label class="fitText block_label" data-placeholder="" tabindex="0" aria-label="' + getMessage(e, "address1") + '">' + getMessage(e, "address1") + '</label> <input class="form-control' + required + '" aria-required="' + aria_require + '" name="Address line 1" aria-placeholder="Add ' + getMessage(e, "address1") + '" placeholder="" type="text" ></div><div class="col-sm-12 form-group"><label class="fitText block_label" data-placeholder="" tabindex="0" aria-label="' + getMessage(e, "address2") + '">' + getMessage(e, "address2") + '</label><input class="form-control" name="Address line 2" aria-placeholder="Add ' + getMessage(e, "address2") + '" placeholder="" type="text"></div><div class="col-sm-6 form-group"><label class="fitText block_label" data-placeholder="" tabindex="0" aria-label="' + getMessage(e, "city") + '">' + getMessage(e, "city") + '</label><input class="form-control' + required + '" aria-required="' + aria_require + '" name="City" aria-placeholder="Add ' + getMessage(e, "city") + '" placeholder="" type="text"></div><div class="col-sm-6 form-group"><label class="fitText block_label" data-placeholder=""  tabindex="0" aria-label="' + getMessage(e, "province") + '">' + getMessage(e, "province") + '</label><input class="form-control' + required + '" aria-required="' + aria_require + '" name="Province" aria-placeholder="Add ' + getMessage(e, "province") + '" placeholder="" type="text"></div><div class="col-sm-6 form-group"><label class="fitText block_label" data-placeholder="" tabindex="0" tabindex="0" aria-label="' + getMessage(e, "zipcode") + '">' + getMessage(e, "zipcode") + '</label><input class="form-control' + required + '" aria-required="' + aria_require + '" name="Zip code" aria-placeholder="Add ' + getMessage(e, "zipcode") + '" placeholder="" type="text"></div><div class="col-sm-6 form-group"><label class="fitText block_label" data-placeholder="" tabindex="0" aria-label="' + getMessage(e, "country") + '">' + getMessage(e, "country") + '</label><select class="form-control' + required + ' country" aria-required="' + aria_require + '" name="Country" aria-label="Select ' + getMessage(e, "country") + '"><option value=""> - ' + getMessage(e, "country") + " - </option></select></div></div>", m = "address";
            else if ("email" == c) customClass = a.email_confirm && "yes" === a.email_confirm ? customClass + " email_confirm" : customClass, email_validation_label = a.email_validate_field_label ? a.email_validate_field_label : "", email_validation_placeholder = a.email_validate_field_placeholder ? a.email_validate_field_placeholder : elementHolder, label_2 = '<label name="validation_' + i + '_email_label2" class="fitText block_label validation-email-label-' + i + '" style="margin-top: 5px;" tabindex="0" aria-label="' + email_validation_label + '">' + email_validation_label + "</label>", input_2 = '<input class="form-control ' + required + " " + customClass + " validation-email-label-" + i + '" aria-required="' + aria_require + '" id="' + customID + '" name="validation_value" type="text" aria-placeholder="' + email_validation_placeholder + '" placeholder="' + email_validation_placeholder + '">', E = "yes" === a.email_validate_field ? '<input class="form-control ' + required + " " + customClass + '" aria-required="' + aria_require + '" id="' + customID + '" name="' + labelType + '" type="email" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '"><div>' + label_2 + input_2 + "</div>" : '<input class="form-control ' + required + " " + customClass + '" aria-required="' + aria_require + '" id="' + customID + '" name="' + labelType + '" type="email" aria-placeholder="' + elementHolder + '" placeholder="' + elementHolder + '">', m = "email";
            else if ("space" == c) label = "", E = "<div class='spacer" + customClass + "' id='" + customID + "'></div>", m = "space";
            else if ("label" == c) label = '<label class="fitText block_label only_label' + customClass + '" id="' + customID + '" for="' + customID + '" aria-label="' + labelType + '" tabindex="0">' + labelType + "</label>", E = "", m = "label";
            else if ("lineBreak" == c) label = "", E = "<div class='lineBreak" + customClass + " id='" + customID + "'><hr/></div>", m = "lineBreak";
            else if ("raw_html" == c) E = void 0 !== a.rowHtmlCode ? a.rowHtmlCode : "", m = "raw_html";
            else if ("ratings" == c) {
                var j, N, z = a.starCount ? a.starCount : 5,
                    H = !!a.halfwidth && "yes" == a.halfwidth;
                z > 7 && !0 == H ? (j = 5, N = 5) : (j = 10, N = 0);
                for (var B = "", I = z; I >= 1; I--) B += '<input id="star-' + I + "-" + i + "-" + t + '" type="radio" name="rating' + i + '" value="' + I + '" /><label class="rating-inline" tabindex="0" aria-label="Select ' + I + '" for="star-' + I + "-" + i + "-" + t + '" title="' + I + ' stars" style="padding:' + j + 'px;"><i class="active fa fa-star" aria-hidden="true"></i></label>';
                E = '<div class="row" tabindex="0" aria-label="Select ' + labelType + '"><div class="star-rating star-rating-' + i + " " + customClass + '" id="' + customID + '">' + B + "</div></div>", m = "ratings", setTimeout(function() {
                    var e = document.querySelector(`${l} .star-rating-` + i);
                    e ? (e.innerHTML = B, e.style.marginTop = N + "px") : console.error(`Element with class ${l} .star-rating-` + i + " not found!")
                }, 100)
            } else if ("terms_conditions" == c) checked = a.checked && "yes" === a.checked ? "checked" : "", ariaChecked = a.checked && "yes" === a.checked ? "true" : "false", reqStar = " required" === required ? "*" : "", label = "", linkLabel = shop_is_after_submit_enabled && a.redirect ? '<a class="checkbox_a_link" aria-hidden="true" tabindex="-1" focusable="false" target="_blank" href="' + a.redirect + '">' + labelType + reqStar + "</a>" : labelType + reqStar, E = '<div class="checkbox checkbox-list input' + i + '"><label class="checkbox-inline" for="' + customID + '" aria-label="' + labelType + '" tabindex="0"><input type="checkbox" name="' + labelType + '" class="' + customClass + required + '" id="Checkbox' + i + "-" + t + '" ' + checked + ' aria-checked="' + ariaChecked + '" aria-required="' + aria_require + '" role="checkbox"><label for="Checkbox' + i + "-" + t + '"><span class="' + customClass + '" id="' + customID + '"></span>' + linkLabel + "</label></label></div>", m = "terms_conditions";
            else if ("headings" == c) E = void 0 !== a.headings ? a.headings : "", m = "headings";
            else if ("paragraph" == c) E = void 0 !== a.paragraph ? a.paragraph : "", m = "paragraph";
            else if ("image_display" == c) {
                let D = a.image_display_url || "",
                    P = void 0 !== a.imageheight ? a.imageheight : 150,
                    G = void 0 !== a.imagewidth ? a.imagewidth : 300,
                    R = a.image_alignmet || "left",
                    U = "";
                U = "left" === R ? 'style="float: none; text-align: left;"' : "center" === R ? 'style="float: none; text-align: center;"' : 'style="float: right; text-align: right;"';
                let V = `${l} .formElement_${i}.image_display img { 
                  width: ${G}px !important; 
                  height: ${P}px !important;
                }`;
                n += V;
                let O;
                E = `
                  <div class="input${i}${customClass} row" id="${customID}">
                      
                  <div class="col-md-12" id="image-display-${i}" ${U}>
                      <img src="${D}" width="${G}px" height="${P}px">
                  </div>
              
                  </div>
              `, label = a.label ? `<label class="fitText block_label" for="${customID}">${labelType}</label>` : "", m = "image_display"
            } else if ("picture_choice" == c) {
                if (void 0 !== a.pictures) {
                    var W = "radio";
                    a.multiple_select, "yes" == a.multiple_select && (W = "checkbox"), pictures = a.pictures;
                    var Z = [];
                    let K = 0;
                    "yes" == a.add_images_description && (Z = a.images_description.split("\n").map(e => e.trim()).filter(e => "" !== e));
                    var Q = "";
                    for (let J in pictures)
                        if (Object.hasOwn(pictures, J)) {
                            let Y = pictures[J],
                                X = J.split("/").pop(),
                                ee = X.split(".").slice(0, -1).join("."),
                                et = "yes" === a.add_images_description && K < Z.length ? Z[K] : "";
                            "yes" === a.add_images_description && K++;
                            let ea = et ? "min-height: 65px;" : "";
                            Q += `
                          <div class="col-md-6" id="picture-choice-${Y}" tabindex="0" aria-label="${ee}" style="width: 50%; float: left;">
                              <label style="width: 100%">
                                  <input type="${W}" name="picture-choice-img-${i}" value="picture-choice-img-${i}">
                                  <img src="${J}" class="picture_choice_img" style="width: 100%; margin-top: 10px;">
                              </label>
                              <div class="image-description wrap-text" style="text-align: center; ${ea} margin-top: 5px;">${et}</div>
                          </div>
                      `
                        }
                    E = '<div class="input' + i + customClass + ' row" tabindex="0" aria-label="Select ' + labelType + '" id="' + customID + '">' + Q + "</div>", m = "picture_choice"
                }
                if (void 0 !== e.formElements[i].img_outline_clr) {
                    let el = `${l} .formElement_${i}.picture_choice [type=radio]:checked + img { 
                  outline: 2px solid ${e.formElements[i].img_outline_clr}; 
                }`,
                        er = `${l} .formElement_${i}.picture_choice [type=checkbox]:checked + img { 
                  outline: 2px solid ${e.formElements[i].img_outline_clr}; 
                }`;
                    n += el, n += er
                }
            } else if ("product_choice" == c) {
                if (void 0 !== a.products) {
                    var ei, eo = "radio";
                    a.multiple_product_select, "yes" == a.multiple_product_select && (eo = "checkbox"), products = a.products;
                    var es = "col-sm-4";
                    es = 2 == a.number_of_products ? "col-sm-6" : 3 == a.number_of_products ? "col-sm-4" : "col-sm-3", void 0 !== a.productimageheight ? ei = a.productimageheight : 3 == a.number_of_products ? ei = 150 : 4 == a.number_of_products ? ei = 100 : 2 == a.number_of_products && (ei = 200);
                    var Q = '<div class="product-grid product-grid-' + i + '">';
                    products.forEach(function(e, t) {
                        Q += '<div tabindex="0" aria-label="' + e.title + '" class="' + es + '" id="product-choice-img-' + e.id + '"><label><input type="' + eo + '" name="product-choice-img-' + i + '" value="product-choice-img-' + i + '"><img src="' + e.image + '" alt="' + e.title + '" style="height:' + ei + 'px; width: 300px;"><div class="product-title">' + e.title + "</div></label></div>"
                    }), Q += "</div>", E = '<div class="input' + i + customClass + ' row" tabindex="0" aria-label="Select ' + labelType + '" id="' + customID + '">' + Q + "</div>", m = "product_choice"
                }
                if (void 0 !== e.formElements[i].product_outline_clr) {
                    let en = `${l} .formElement_${i}.product_choice [type=radio]:checked + img {outline: 2px solid ${e.formElements[i].product_outline_clr};}`,
                        ec = `${l} .formElement_${i}.product_choice [type=checkbox]:checked + img {outline: 2px solid ${e.formElements[i].product_outline_clr};}`;
                    s += en, s += ec
                }
            } else "emoji" == c && (width = "100%", "yes" == a.halfwidth && (width = "100%"), 3 == a.number_of_emojis ? E = '<div class="emoji-feedback emoji-feedback-' + i + " " + customClass + '" tabindex="0" aria-label="Select one ' + labelType + '" id="' + customID + '" style="width: ' + width + '"><div class="ef-item" tabindex="0" aria-label="Select Weary Face"><label class="emoji-inline" for="ef-0-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-0-' + i + "-" + t + '" value="sad"><span>\uD83D\uDE29</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Neutral Face"><label class="emoji-inline" for="ef-1-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-1-' + i + "-" + t + '" value="neutral"><span>\uD83D\uDE10</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Grinning Face with Smiling Eyes"><label class="emoji-inline" for="ef-2-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-2-' + i + "-" + t + '" value="awesome"><span>\uD83D\uDE04</span></label></div></div>' : 5 == a.number_of_emojis ? E = '<div class="emoji-feedback emoji-feedback-' + i + " " + customClass + '" aria-label="Select one ' + labelType + '" id="' + customID + '" style="width: ' + width + '"><div class="ef-item" tabindex="0" aria-label="Select Weary Face"><label class="emoji-inline" for="ef-0-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-0-' + i + "-" + t + '" value="sad"><span>\uD83D\uDE29</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Slightly Frowning Face"><label class="emoji-inline" for="ef-1-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-1-' + i + "-" + t + '" value="bad"><span>\uD83D\uDE41</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Neutral Face"><label class="emoji-inline" for="ef-2-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-2-' + i + "-" + t + '" value="neutral"><span>\uD83D\uDE10</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Slightly Smiling Face"><label class="emoji-inline" for="ef-3-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-3-' + i + "-" + t + '" value="good"><span>\uD83D\uDE42</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Grinning Face with Smiling Eyes"><label class="emoji-inline" for="ef-4-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-4-' + i + "-" + t + '" value="awesome"><span>\uD83D\uDE04</span></label></div></div>' : 2 == a.number_of_emojis && (E = '<div class="emoji-feedback emoji-feedback-' + i + " " + customClass + '" tabindex="0" aria-label="Select one ' + labelType + '" id="' + customID + '" style="width: ' + width + '"><div class="ef-item" tabindex="0" aria-label="Select Weary Face"><label class="emoji-inline" for="ef-0-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-0-' + i + "-" + t + '" value="sad"><span>\uD83D\uDE29</span></label></div><div class="ef-item" tabindex="0" aria-label="Select Grinning Face with Smiling Eyes"><label class="emoji-inline" for="ef-1-' + i + "-" + t + '"><input class="ef-radio" type="radio" name="feedback_' + i + '" id="ef-1-' + i + "-" + t + '" value="awesome"><span>\uD83D\uDE04</span></label></div></div>'), m = "emoji");
            "select" == c ? o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '" ><div class="row" style="width: 100%;margin: 0;"><div class="col-sm-12 form-group for-floating-label" style="padding: 0">' + label + E + infoMessageHTML : "raw_html" == c ? plan_features.includes("html-code") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + E + infoMessageHTML + "</div>") : "headings" == c ? plan_features.includes("heading") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + E + infoMessageHTML + "</div>") : "paragraph" == c ? plan_features.includes("paragraph") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + E + infoMessageHTML + "</div>") : "address" == c ? plan_features.includes("address") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "hidden" == c ? plan_features.includes("hidden-field") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "password" == c ? plan_features.includes("password") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "validation_field" == c ? plan_features.includes("validation-field") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "multi_text" == c ? plan_features.includes("multi-line-text") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "multi_column_text" == c ? plan_features.includes("multi-column-text") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "product_choice" == c ? plan_features.includes("product-choice") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "ratings" == c ? plan_features.includes("ratings") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "emoji" == c ? plan_features.includes("emoji-feedback") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "terms_conditions" == c ? plan_features.includes("privacy-notices") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "picture_choice" == c ? plan_features.includes("iamge-choice") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : "image_display" == c ? plan_features.includes("image-display") && (o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>") : o += '<div class="formElement_' + i + " form-group fadeMe text clearfix " + width_class + " " + m + " " + payment_class + ' " data-count="' + i + '" id="' + f + '">' + label + E + infoMessageHTML + "</div>", d += 1
        }), o += '</div><div class="clearfix"></div>', o += '<div class="form_submit_div text-center"><button type="submit" class="btn">' + e.form_submit + '<span class="price"></span></button></div>', o += "</div>", o += "</div></div></div></form></div>", o += '<div class="after_form_submit" style="display:none;"><div class="form_generater_form_div text-center"  tabindex="0"></div></div>', !plan_features.includes("removing-powered-by-hulkapps") && !shop_remove_watermark && shop_created_at && shop_created_at >= new Date("2021-03-15T10:59:33Z") && (o += '<p class="hulk-powered-wrapper text-right">Shopify Forms <a href="https://www.hulkapps.com/?utm_campaign=poweredby&utm_medium=hulkapps&utm_source=fb_app" alt="Shopify Forms Powered by HulkApps" target="_blank">Powered by HulkApps</a></p>'), o += "</div>"
    }
    str += o, document.getElementById(curFrame.id).innerHTML = str;
    let m = document.getElementById(`${t}_product_choice_css`);
    m && (m.innerHTML += s);
    let p = document.getElementById(`${t}_picture_choice_css`);
    p && (p.innerHTML += n), injectDynamicScript(u)
}, window.generateCSS = function(e, t) {
    return generateFormCSS(e, t)
}, window.alertMEssgaes = function(e) {
    return alertFormMessgaes(e)
}, window.getMessage = function(e, t) {
    return getCustomiseMessage(e, t)
}, window.handleSubmissionSchedule = function(e) {
    return handleFormSubmissionSchedule(e)
}, window.afterSubmitActionAndAnalytics = function(e, t, a) {
    var l = `.hulk_form_${t}`;
    if (plan_features.includes("google-analytics-4-by-measurement-id") || plan_features.includes("google-ads-for-tracking-conversion")) var r = e.form_data.event_category,
        i = e.form_data.event_action,
        o = e.form_data.event_label;
    if (plan_features.includes("google-analytics-4-by-measurement-id")) var s = e.form_data.event_name;
    if (plan_features.includes("google-analytics-4-by-measurement-id") && e.form_data.google_analytic_4_id && "" !== e.form_data.google_analytic_4_id) {
        var n = window.location !== window.parent.location ? document.referrer : document.location;
        gtag("event", s || "Hulk form builder form submission", {
            eventCategory: r || e.form_data.form_name + " form submission",
            eventAction: i || e.form_data.form_name + " successful form submission",
            eventLabel: o || n
        })
    }
    if (plan_features.includes("google-ads-for-tracking-conversion") && e.form_data.google_tag_conversion_id && "" !== e.form_data.google_tag_conversion_id && e.form_data.google_tag_conversion_label && "" !== e.form_data.google_tag_conversion_label) {
        var n = window.location !== window.parent.location ? document.referrer : document.location;
        gtag("event", "conversion", {
            send_to: "AW-" + e.form_data.google_tag_conversion_id + "/" + e.form_data.google_tag_conversion_label,
            eventCategory: r || e.form_data.form_name + " form submission",
            eventAction: i || e.form_data.form_name + " successful form submission",
            eventLabel: o || n,
            event_callback: function() {
                console.log("Conversion tracked successfully. Parent URL:", n)
            }
        })
    }
    plan_features.includes("facebook-pixel-id") && e.form_data.facebook_pixel_id && "" !== e.form_data.facebook_pixel_id && ("benchmade-modern.myshopify.com" === shop_shopify_domain ? fbq("trackCustom", "TradeApplication", {
        content_category: e.form_data.form_name + " form submission",
        content_name: "Successful form submission"
    }) : (fbq("track", "Lead", {
        content_category: e.form_data.form_name + " form submission",
        content_name: "Successful form submission"
    }), console.log("Standard Lead event triggered for Facebook integration.")));
    let c = 5e3;
    if (e.form_data.form_timer_sec && parseInt(e.form_data.form_timer_sec) > 0 && (c = 1e3 * parseInt(e.form_data.form_timer_sec)), "clearAndPrevent" === e.form_data.after_submit) {
        let d = document.querySelector(`${l} .alert_message`);
        (thankYouMessage = getMessage(e.form_data, "thank_you")) && (d.innerHTML = "", d.innerHTML = `
          <div class="alert alert-success" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
              <p tabindex="0" aria-label="${thankYouMessage}" class="alert-success">${thankYouMessage}</p>
          </div>`, d.style.display = "block");
        let u = document.querySelector(`.hulk_form_${t}`);
        u && window.scrollTo({
            top: u.offsetTop,
            behavior: "smooth"
        }), setTimeout(() => {
            let e = document.querySelector(`${l} .alert_message .alert`);
            e && (e.remove(), d.style.display = "none")
        }, c), document.querySelector(`${l} #formGeneratorForm`).reset(), document.querySelector(`${l} .form_submit_div .btn`).disabled = !0
    } else if ("clearAndAllow" === e.form_data.after_submit) {
        let m = document.querySelector(`${l} #formGeneratorForm`);
        if (m && (m.reset(), window.scrollTo({
                top: m.offsetTop,
                behavior: "smooth"
            })), e.form_data.after_submit_msg && "" != e.form_data.after_submit_msg.to_s) {
            let p = document.querySelector(`${l} .alert_message`);
            p.innerHTML = `
          <div class="alert alert-success" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
              <p tabindex="0" aria-label="${e.form_data.after_submit_msg.replace(/<\/?[^>]+(>|$)/g,"")}" class="alert-success">${e.form_data.after_submit_msg}</p>
          </div>`, p.style.display = "block", document.querySelector(`${l} .form_submit_div .btn`).disabled = !1
        }
        let f = document.querySelector(`.hulk_form_${t}`);
        f && window.scrollTo({
            top: f.offsetTop,
            behavior: "smooth"
        }), setTimeout(() => {
            let e = document.querySelector(`${l} .alert_message .alert`);
            e && (e.remove(), alertMessage.style.display = "none")
        }, c)
    } else if ("hideAndmessage" === e.form_data.after_submit) {
        let b = document.querySelector(`${l} .formContainer`);
        b && (b.style.display = "none", b.innerHTML = "");
        let h = document.querySelector(`${l} .after_form_submit .form_generater_form_div`);
        h && (h.innerHTML = e.form_data.after_submit_msg, h.setAttribute("tabindex", "0"), h.setAttribute("aria-label", new DOMParser().parseFromString(e.form_data.after_submit_msg, "text/html").body.textContent), h.style.display = "block");
        let y = document.querySelector(`${l} .after_form_submit`);
        if (y) {
            y.style.display = "block";
            let g = JSON.parse(a.user_response),
                v = JSON.stringify(g),
                x = document.createElement("input");
            x.type = "hidden", x.className = "from_res", x.value = v, y.appendChild(x)
        }
        let S = document.querySelector(`.hulk_form_${t}`);
        S && window.scrollTo({
            top: S.offsetTop,
            behavior: "smooth"
        })
    } else if ("redirect" === e.form_data.after_submit) {
        if (void 0 !== e.form_data.after_submit_url) {
            var $ = e.form_data.after_submit_url;
            if (void 0 !== e.form_data.openinnewtab && "yes" === e.form_data.openinnewtab) {
                if ("" === $) location.reload();
                else {
                    var q = window.open("", "_blank");
                    q ? q.location.href = $ : window.top.location.href = $, document.querySelector(".formContainer").style.display = "none", document.querySelector(".formContainer").innerHTML = "";
                    let k = document.querySelector(`${l} .after_form_submit .form_generater_form_div`);
                    k && (k.innerHTML = e.form_data.after_submit_msg, k.setAttribute("tabindex", "0"), k.setAttribute("aria-label", new DOMParser().parseFromString(e.form_data.after_submit_msg, "text/html").body.textContent));
                    let L = document.querySelector(`${l} .after_form_submit`);
                    L && (L.style.display = "block")
                }
            } else "" === $ ? location.reload() : window.top.location.href = $
        } else location.reload()
    } else if ("responses" === e.form_data.after_submit) {
        var w = JSON.parse(a.user_response),
            E = `
        <style type="text/css">
            ${l} .after_form_submit .form_generater_form_div table { border: 1px solid #ccc; }
            ${l} .after_form_submit .form_generater_form_div tr { border-bottom: 1px solid #ccc; }
            ${l} .after_form_submit .form_generater_form_div tr:nth-child(2n) { background: #ededed; }
            ${l} .after_form_submit .form_generater_form_div td { padding: 6px 5px; }
        </style>
      `;
        "al-manaiya-oasis-festival.myshopify.com" !== shop_shopify_domain && (form_name = e.form_data.form_name, E += `
            <div class="response_div" style="float: right !important;">
                <button type="button" style="padding: 4px 15px; border: none; margin-right: 10px;" aria-label="Download PDF" onclick="GeneratePdf('${form_name}', '${l}')">
                    <span>Download PDF</span>
                </button>
                <button type="button" style="padding: 4px 15px; border: none;" aria-label="Download CSV" onclick="download('${form_name}', '${l}')">
                    <span>Download CSV</span>
                </button>
            </div>
        `), E += `
        <h3 class="response_heading" style="margin-top: 45px;"> ${getMessage(e,"your_response")} </h3>
        <div class="content_div">
            <table class="question_content" cellpadding="15" border="1" cellspacing="0" width="100%" border-collapse="collapse" style="margin-top: 10px;">
      `, Object.entries(w).forEach(([t, a]) => {
            if (E += `<tr><td><b>${t}</b></td><td style="word-wrap: break-word; max-width: 300px;">`, "string" != typeof a) {
                if ("image" === a.type || "picture_choice" === a.type) "multiple" === a.upload_type ? a.images.forEach(e => {
                    E += `<a href="${e.url}" target="_blank">
                              <img src="${e.url}" alt="${t}" width="150px" height="150px" style="margin-top: 15px;">
                          </a>`, e.description && "" !== e.description.trim() && (E += `<div style="margin-top: 5px;">${e.description}</div>`)
                }) : void 0 !== a.url && (E += `<a href="${a.url}" target="_blank">
                              <img src="${a.url}" alt="${t}" width="150px" height="150px" style="margin-top: 15px;">
                          </a>`, a.description && "" !== a.description.trim() && (E += `<div style="margin-top: 5px;">${a.description}</div>`));
                else if ("file" === a.type) "multiple" === a.upload_type ? a.files.forEach(t => {
                    E += `<br/><a href="${t.url}" target="_blank" style="margin-bottom: 10px;">${getMessage(e,"download_file")}</a>`
                }) : E += `<a href="${a.url}" target="_blank">${getMessage(e,"download_file")}</a>`;
                else if ("password" === a.type) "" !== a.password_input && (E += "*".repeat(a.password_input.length));
                else if (void 0 !== a.url) E += `<a href="${a.url}" target="_blank">${getMessage(e,"download_file")}</a>`;
                else if ("url" === a.type) {
                    var l;
                    E += `<p style="color: unset;">${(l=a.value).replace(RegExp("(.{35})","g"),"$1<br/>")}</p>`
                } else Object.values(a).forEach(e => {
                    Object.entries(e).forEach(([e, t]) => {
                        "" !== t.trim() && (E += `${e}: ${t}</br>`)
                    })
                })
            } else E += a.toString();
            E += "</td></tr>"
        }), E += "</table></div>";
        let A = document.querySelector(`${l} .formContainer`);
        A && (A.style.display = "none", A.innerHTML = "");
        let C = document.querySelector(`${l} .after_form_submit .form_generater_form_div`);
        C && (C.innerHTML = E);
        let _ = document.querySelector(`${l} .after_form_submit`);
        _ && (_.style.display = "block")
    }
}, window.afterSubmitErrorsAndScroller = function(e, t, a) {
    var l = `.hulk_form_${a}`;
    (e.message, "uniq_email_validation" === e.message) ? (emailMsg = getMessage(t, "email_submitted"), document.querySelector(`${l} .alert_message`).innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p tabindex="0" aria-label="${emailMsg}" class="alert-danger">${emailMsg}</p>
            </div>`, document.querySelector(`${l} .alert_message`).style.display = "block") : (e.message, "user_res_parse_error" === e.message) ? (userResMsg = getMessage(t, "user_res_parse_error"), document.querySelector(`${l} .alert_message`).innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p tabindex="0" aria-label="${userResMsg}" class="alert-danger">${userResMsg}</p>
            </div>`, document.querySelector(`${l} .alert_message`).style.display = "block") : (document.querySelector(`${l} .alert_message`).innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p tabindex="0" aria-label="${e.message}" class="alert-danger">${e.message}</p>
            </div>`, document.querySelector(`${l} .alert_message`).style.display = "block");
    let r = document.getElementById(`${l} wizard-validation-form`);
    r && window.scrollTo({
        top: r.offsetTop,
        behavior: "smooth"
    }), document.querySelector(`${l} .form_submit_div .btn`).disabled = !1
}, window.validateFormbuilderform = function(e, t) {
    var a = 1,
        l = [],
        r = "",
        i = "",
        o = e.form_data,
        s = "",
        n = "",
        c = `.hulk_form_${t}`;
    if (document.querySelectorAll(`${c} .required`).forEach(function(e) {
            e.classList.remove("error")
        }), document.querySelectorAll(`${c} .tab:nth-child(1) .form_container div[class^='formElement']`).forEach(function(t) {
            if (!t.id) {
                var n = t.dataset.count,
                    c = getMessage(o, "is_required");
                if (e.form_data.formElements[n] && "yes" === e.form_data.formElements[n].required) {
                    if (t.classList.contains("radio")) {
                        let d = t.querySelector("input:checked");
                        if (!d) {
                            a = 0;
                            let u = t.querySelector("input").getAttribute("name");
                            l.push(u + " " + c);
                            let m = t.querySelector(".block_label").textContent;
                            document.querySelectorAll(`input[name='${m}']`)
                        }
                    } else if (t.classList.contains("checkbox")) {
                        let p = t.querySelector("input");
                        p && !p.checked && (a = 0, l.push(p.getAttribute("name") + " " + c), p.classList.add("error"))
                    } else if (t.classList.contains("checkbox-multi")) {
                        let f = t.getAttribute("data-count"),
                            b = t.querySelectorAll(`.checkboxmulti_${f}[type="checkbox"]:checked`);
                        if (0 === b.length) {
                            a = 0;
                            let h = t.querySelector("input");
                            h && l.push(h.getAttribute("name") + " " + c)
                        }
                    } else if (t.classList.contains("select")) {
                        let y = t.querySelector("select");
                        y && "" === y.value && (a = 0, l.push(y.name + " " + c), y.classList.add("error"))
                    } else if (t.classList.contains("address")) {
                        let g = e.form_data.formElements[t.dataset.count].label;
                        t.querySelectorAll("input.required").forEach(function(e) {
                            "" == e.value.trim() && (a = 0, subName = e.closest(".form-group").querySelector(".block_label").textContent, l.push(g + " - " + subName + " " + c), e.classList.add("error"))
                        })
                    } else if (t.classList.contains("multi_column_text")) {
                        let v = e.form_data.formElements[t.dataset.count].label,
                            x = t.querySelector(".multi-column-input");
                        if (x) {
                            let S = x.querySelectorAll("input.required");
                            setTimeout(() => {
                                S[0] && "" === S[0].value.trim() && S[0].classList.add("error"), S[1] && "" === S[1].value.trim() && S[1].classList.add("error")
                            }, 100), (S[0] && "" === S[0].value.trim() || S[1] && "" === S[1].value.trim()) && (a = 0, l.push(v + " " + c))
                        }
                    } else if (t.classList.contains("ratings")) t.querySelector(".star-rating").classList.remove("error"), null === t.querySelector('input[type="radio"]:checked') && (a = 0, l.push("Rating " + c), t.querySelector(".star-rating").classList.add("error"));
                    else if (t.classList.contains("emoji")) t.querySelector(".emoji-feedback").classList.remove("error"), null === t.querySelector('input[type="radio"]:checked') && (a = 0, l.push("Feedback " + c), t.querySelector(".emoji-feedback").classList.add("error"));
                    else if (t.classList.contains("picture_choice")) {
                        let $ = t.querySelector('input[type="radio"]:checked'),
                            q = t.querySelector('input[type="checkbox"]:checked'),
                            k = t.querySelector("label");
                        k.classList.remove("error"), $ || q || (a = 0, l.push("Image Choice " + c), k && k.classList.add("error"))
                    } else if (t.classList.contains("product_choice")) {
                        let L = t.querySelector("label");
                        L && L.classList.remove("error");
                        let w = t.querySelector('input[type="radio"]:checked'),
                            E = t.querySelector('input[type="checkbox"]:checked');
                        w || E || (a = 0, l.push("Product Choice " + c), L && L.classList.add("error"))
                    } else if (t.classList.contains("terms_conditions")) {
                        if (!t.querySelector("input").checked) {
                            a = 0;
                            let A = "",
                                C = t.classList;
                            C.forEach(function(t) {
                                if (t.startsWith("formElement_")) {
                                    let a = t.split("_")[1];
                                    A = e.form_data.formElements[a].tc || "Terms and Conditions " + c
                                }
                            }), l.push(A)
                        }
                    } else if (t.classList.contains("password")) {
                        let _ = t.querySelector("input").value,
                            T = t.querySelector('input[name$="_input"]');
                        T && T.value, t.querySelectorAll("input").forEach(e => e.classList.remove("error")), "" == _ && (a = 0, l.push(t.querySelector("input").name + " " + c), t.querySelectorAll("input").forEach(e => e.classList.add("error")))
                    } else if (t.classList.contains("validation_field")) {
                        let M = t.querySelectorAll("input"),
                            F = M[0] ? .value || "";
                        "" === F && (a = 0, l.push(M[0].name + " " + c), M.forEach(e => {
                            "" === e.value && e.classList.add("error")
                        }))
                    } else if (t.classList.contains("multi_text")) {
                        let j = t.querySelectorAll("input"),
                            N = j[0];
                        if (N && "" === N.value.trim()) {
                            a = 0, l.push(N.name + " " + c), N.classList.add("error");
                            let z = t.querySelectorAll("button");
                            z.forEach(e => e.classList.remove("error")), j.forEach((e, t) => {
                                t > 0 && e.classList.remove("error")
                            })
                        }
                    } else if (t.classList.contains("textarea")) {
                        let H = t.querySelector("textarea");
                        H && "" === H.value.trim() && (a = 0, l.push(H.name + " " + c), H.classList.add("error"))
                    } else if (!t.classList.contains("headings")) {
                        let B = t.querySelector("input");
                        B && "" === B.value.trim() && (a = 0, l.push(B.name + " " + c), B.classList.add("error"))
                    }
                }
                if (t.classList.contains("email")) {
                    let I = t.querySelector("input"),
                        D = I ? I.name : "",
                        P = I ? I.value : "",
                        G = t.querySelector('input[class*="validation-email-label"]'),
                        R = "";
                    if (G) {
                        if (R = G.value, "" === P && "" === R && G.classList.add("error"), "" !== P && "" === R) {
                            let U = `${D} ${getMessage(o,"is_required")}`;
                            a = 0, l.push(U), G.classList.add("error")
                        }
                        if ("" !== P && P !== R && "" !== R) {
                            let V = `${D} ${getMessage(o,"valid_same_values")}`;
                            a = 0, l.push(V), t.querySelector("input").classList.add("error")
                        }
                    }
                    if ("" !== P) {
                        let O = t.querySelector("input").value,
                            [W, Z] = securityEmailValidation(P);
                        if (Z) a = 0, t.querySelector("input").classList.add("error");
                        else if (isEmail(P)) {
                            if (plan_features.includes("block-domain")) {
                                let K = [];
                                "undefined" != typeof blocked_domains && blocked_domains.length > 0 && blocked_domains.forEach(e => {
                                    K = K.concat(e.split(","))
                                }), e.form_data.blocked_emails && e.form_data.blocked_emails.length > 0 && (K = K.concat(e.form_data.blocked_emails.split(","))), (K = [...new Set(K.map(e => e.trim()))]).forEach(function(e) {
                                    var t = e.trim(),
                                        r = t.includes("@") ? t : t.substring(t.lastIndexOf("@") + 1),
                                        i = O.endsWith("@" + r),
                                        s = O.endsWith("." + r);
                                    if (!0 === i || !0 === s) {
                                        a = 0;
                                        var n = getMessage(o, "blocked_domain") + " " + r;
                                        l.push(n)
                                    } else if (O === t) {
                                        a = 0;
                                        var n = getMessage(o, "blocked_domain") + " " + r;
                                        l.push(n)
                                    }
                                }), s = "" !== s ? s + "," + O : O, document.querySelector("input.email_confirm") && (r = "" !== r ? r + "," + O : O)
                            }
                        } else a = 0, l.push(getMessage(o, "valid_email")), i = getMessage(o, "valid_email"), t.querySelector("input").classList.add("error")
                    }
                }
                if (t.querySelector("input") ? .classList.contains("url") && "" !== t.querySelector("input").value) {
                    let Q = t.querySelector("input"),
                        [J, Y] = securityValidation(Q.value);
                    Y ? (a = 0, Q.classList.add("error")) : validateUrl(Q.value) || (a = 0, l.push(getMessage(o, "valid_url")), i = getMessage(o, "valid_url"), Q.classList.add("error"))
                }
                if (t.classList.contains("number")) {
                    let X = t.querySelector("input"),
                        ee = X ? X.value : "";
                    if ("" !== ee) {
                        if (isNaN(parseInt(ee))) {
                            a = 0;
                            let et = X.name || "";
                            l.push(getMessage(o, "only_number_alloud") + et), i = getMessage(o, "only_number_alloud") + et, X.classList.add("error")
                        } else {
                            let ea = t.getAttribute("data-count");
                            if (e.form_data.formElements[ea] && void 0 !== e.form_data.formElements[ea].maxNumber) {
                                let el = parseInt(e.form_data.formElements[ea].maxNumber);
                                if (parseInt(ee) > el) {
                                    a = 0;
                                    let er = X.name || "";
                                    i = er + " " + getMessage(o, "number_less") + " " + el, l.push(er + " " + getMessage(o, "number_less") + " " + el), X.classList.add("error")
                                }
                            }
                            if (e.form_data.formElements[ea] && void 0 !== e.form_data.formElements[ea].minNumber) {
                                let ei = parseInt(e.form_data.formElements[ea].minNumber);
                                if (parseInt(ee) < ei) {
                                    a = 0;
                                    let eo = X.name || "";
                                    i = eo + " " + getMessage(o, "number_more") + " " + ei, l.push(eo + " " + getMessage(o, "number_more") + " " + ei), X.classList.add("error")
                                }
                            }
                        }
                    }
                }
                if (t.classList.contains("text") || t.classList.contains("textarea")) {
                    var es = t.querySelector("input, textarea");
                    if (es) {
                        var en = t.querySelector("input"),
                            ec = t.querySelector("textarea"),
                            ed = es.value.trim();
                        if ("" !== ed) {
                            var [eu, em] = storeSpecificSecurityValidation(ed);
                            em && (a = 0, l.push(eu), t.classList.contains("text") && en && en.classList.add("error"), t.classList.contains("textarea") && ec && ec.classList.add("error"))
                        }
                    }
                }
                if (t.classList.contains("password")) {
                    var ep = t.querySelector("input").value,
                        ef = ep ? ep.length : 0,
                        e8 = t.querySelector("input").name,
                        eb = t.querySelector('input[name$="_input"]'),
                        eh = eb ? eb.value : "",
                        ey = t.querySelector("input").getAttribute("minlength"),
                        eg = t.querySelector("input").getAttribute("maxlength");
                    if (ep && "" !== ep) {
                        var [ev, ex] = securityValidation(ep);
                        if (ex) {
                            a = 0, l.push(ev), t.querySelector("input").classList.add("error");
                            var es = t.querySelector('input[name$="_input"]');
                            null !== es && es.classList.add("error")
                        }
                        var [eS, e9] = checkPasswordRules(ep, ef, ey, eg, e8);
                        if (e9) {
                            a = 0, l.push(eS), t.querySelector("input").classList.add("error");
                            var es = t.querySelector('input[name$="_input"]');
                            es && es.classList.add("error")
                        } else !eh && t.querySelector('input[name$="_input"]') && (a = 0, l.push("Confirmation password is required"), eb.classList.add("error"))
                    }
                    ep !== eh && eh && (a = 0, l.push("Password and Confirm Password must be the same."), t.querySelectorAll('input, input[name$="_input"]').forEach(e => {
                        e.classList.add("error")
                    }))
                } else if (t.classList.contains("email")) {
                    let e$ = t.querySelector("input").value.trim();
                    if ("" !== e$) {
                        let [eq, ek] = securityEmailValidation(e$);
                        ek && (a = 0, l.push(eq), t.querySelector("input").classList.add("error"))
                    }
                } else if (t.classList.contains("multi_text")) t.querySelectorAll("div[class^='input_fields_'] div input[type='text']").forEach(function(e, t) {
                    var r = e.value;
                    if ("" !== r) {
                        var [i, o] = securityValidation(r);
                        o && (a = 0, l.push(i), e.classList.add("error"))
                    }
                });
                else if (t.classList.contains("select")) {
                    var eL = t.querySelector("select"),
                        ew = eL.value;
                    if ("1" === eL.getAttribute("other_value") && ("Other" === ew || eL.querySelector("option:last-child").value === ew)) {
                        var ep = t.querySelector(".other-fields:last-child input:last-child").value;
                        if ("" === ep) a = 0, l.push(getMessage(o, "please_enter_required_data")), t.querySelector(".other-fields:last-child input:last-child").classList.add("error");
                        else {
                            var [ev, ex] = securityValidation(ep);
                            ex && (a = 0, l.push(ev), t.querySelector(".other-fields:last-child input:last-child").classList.add("error"))
                        }
                    }
                } else if (t.classList.contains("checkbox-multi")) {
                    var eE = t.querySelector("div");
                    eE && "1" === eE.getAttribute("other_value") && t.querySelectorAll("input[type='checkbox']:checked").forEach(function(e) {
                        if ("Other" === e.value) {
                            var r;
                            if ("Other" === e.value) {
                                var i = t.querySelector(".other_class") ? t.querySelector(".other_class").value : "";
                                if (i) {
                                    var [s, n] = securityValidation(i);
                                    if (n) {
                                        a = 0, l.push(s);
                                        var c = t.querySelector(".other_class");
                                        c && c.classList.add("error")
                                    }
                                } else {
                                    a = 0, l.push(getMessage(o, "please_enter_required_data"));
                                    var c = t.querySelector(".other_class");
                                    c && (c.classList.add("error"), t.querySelector(".checkbox-list"))
                                }
                            }
                        }
                    })
                } else if (t.classList.contains("validation_field")) {
                    let eA = t.querySelector("input").getAttribute("name"),
                        eC = t.querySelector("input").value.trim(),
                        e_ = t.querySelector('input[class$="_second"]'),
                        eT = e_ ? e_.value.trim() : "";
                    if (eC && "" !== eC) {
                        let [eM, e0] = securityValidation(eC);
                        if (e0) a = 0, l.push(eM), t.querySelector("input").classList.add("error");
                        else if ("" === eT) {
                            t.querySelector("input").classList.remove("error");
                            let eF = `${eA} ${getMessage(o,"is_required")}`;
                            a = 0, l.push(eF), e_ && e_.classList.add("error")
                        }
                    }
                    if ("" !== eT && (e_.classList.remove("error"), "" === eC)) {
                        let ej = `${eA} ${getMessage(o,"is_required")}`;
                        a = 0, l.push(ej), t.querySelector("input").classList.add("error")
                    }
                    if ("" !== eC && "" !== eT && eC !== eT && "" !== eT && void 0 !== eC && void 0 !== eT) {
                        let e3 = `${eA} ${getMessage(o,"valid_same_values")}`;
                        a = 0, l.push(e3), t.querySelectorAll("input").forEach(e => e.classList.add("error"))
                    }
                } else if (t.classList.contains("hidden"));
                else if (t.classList.contains("address")) {
                    e.form_data.formElements[t.dataset.count].label;
                    let eN = t.querySelectorAll("input");
                    eN.forEach(e => {
                        let t = e.value.trim();
                        if ("" !== t) {
                            let [r, i] = securityValidation(t);
                            i && (a = 0, l.push(r), e.classList.add("error"))
                        }
                    })
                } else {
                    var es = t.querySelector("input");
                    if (es && es.value) {
                        var ed = es.value.trim();
                        if ("" !== ed) {
                            var ez = securityValidation(ed),
                                eu = ez[0],
                                em = ez[1];
                            em ? (a = 0, l.push(eu), es.classList.add("error")) : ed.length > 65535 && (a = 0, l.push("Character limit is maximum 65,535"), es.classList.add("error"))
                        }
                    }
                }
                l = Array.from(new Set(l))
            }
        }), 1 !== a) {
        document.querySelector(`${c}  .form_submit_div .btn`).disabled = !1;
        let d = document.querySelector(`${c} .alert_message`);
        if (l.length > 0) d.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                ${l.map((e,t)=>{let a=e.replace(/<[^>]*>/g,""),r=l.slice(0,t+1).map(e=>e.replace(/<[^>]*>/g,"")).join(" ");return`
                        <p tabindex="0" aria-label="${a.includes("Include")?a:r}" class="alert-danger">
                            ${e}
                        </p>`}).join("")}
            </div>
        `, d.style.display = "block";
        else if ("" !== i) d.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p tabindex="0" aria-label="${i}" class="alert-danger">
                    ${i}
                </p>
            </div>
        `, d.style.display = "block";
        else {
            let u = getMessage(o, "valid_data");
            d.innerHTML = `
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p tabindex="0" aria-label="${u}" class="alert-danger">
                    ${u}
                </p>
            </div>
        `, d.style.display = "block"
        }
        let m = document.querySelector(`${c} .alert_message p.alert-danger`);
        m && m.focus();
        let p = document.getElementById(`${c} wizard-validation-form`);
        p && window.scrollTo({
            top: p.offsetTop,
            behavior: "smooth"
        })
    }
    if (1 == a) {
        processingMsg = getMessage(o, "processing");
        try {
            swal({
                content: {
                    element: "div",
                    attributes: {
                        className: "loader-container",
                        innerHTML: "<div class='loader' style='width:100px;height:100px;'></div><h4>" + processingMsg + "</h4>"
                    }
                },
                button: !1
            })
        } catch (f) {
            console.error("Error displaying SweetAlert loader:", f)
        }
        var b = {};
        document.querySelectorAll(`${c} .form_container div[class^='formElement']`).forEach(function(t) {
            if (!t.id && !t.classList.contains("label") && !t.classList.contains("lineBreak") && !t.classList.contains("space")) {
                var a, l = t.dataset.count,
                    r = e.form_data.formElements[l];
                if (t.classList.contains("radio")) a = t.querySelector("input:checked") ? .value || "";
                else if (t.classList.contains("checkbox")) {
                    var i = t.querySelector("input");
                    i && (a = i.classList.contains("result_in_yes_no") ? i.checked ? "Yes" : "No" : i.checked ? "On" : "Off")
                } else if (t.classList.contains("checkbox-multi")) {
                    var o = [];
                    "1" === t.querySelector("div") ? .getAttribute("other_value") ? t.querySelectorAll("input[type='checkbox']:checked").forEach(function(e) {
                        if ("Other" === e.value) {
                            var a = t.querySelector(".other_class") ? .value || "";
                            "" !== a.trim() && o.push(`${e.value} (${a})`)
                        } else o.push(e.value)
                    }) : document.querySelectorAll(`input[name='${r.label}']:checked`).forEach(function(e) {
                        o.push(e.value)
                    }), a = o.join(", ")
                } else if (t.classList.contains("password")) {
                    var s = t.querySelector("input");
                    a = {
                        password_input: s ? s.value : "",
                        type: "password"
                    }
                } else if (t.classList.contains("validation_field")) a = t.querySelector("input") ? .value || "";
                else if (t.classList.contains("select")) {
                    var n = t.querySelector("select");
                    if ("1" === n ? .getAttribute("other_value")) {
                        if ("Other" === n.value || n.querySelector("option:last-child") ? .value === n.value) {
                            var c = t.querySelector('label[name$="_label"]') ? .textContent.replace("*", "") || "",
                                d = t.querySelector("input") ? .value || "";
                            a = c && d ? `${n.value} (${c} : ${d})` : n.value
                        } else a = n.value
                    } else a = n.value
                } else if (t.classList.contains("multi_text")) {
                    var u = r.position;
                    a = Array.from(t.querySelectorAll(`div.input_fields_${u}_wrap div input[type=text]`)).map(e => e.value).join("\n")
                } else if (t.classList.contains("multi_column_text")) {
                    var u = r.position,
                        m = Array.from(t.querySelectorAll(`div.input_fields_${u}_wrap div.multi-column-input-main div.multi-column-input`)).map(function(e) {
                            var t;
                            return {
                                [e.querySelector("input[name='key']") ? .value || ""]: e.querySelector("input[name='value']") ? .value || ""
                            }
                        });
                    b[r.label] = m
                } else if (t.classList.contains("dateTime")) a = t.querySelector(":input") ? .value || "";
                else if (t.classList.contains("address")) {
                    var p = Array.from(t.querySelectorAll("input,select")).map(function(e) {
                        var t = {};
                        return t[e.name] = e.value, e.value && (hasInputValue = !0), t
                    });
                    b[r.label] = p
                } else if (t.classList.contains("ratings")) a = t.querySelector('input[type="radio"]:checked') ? .value || "0";
                else if (t.classList.contains("terms_conditions")) a = t.querySelector("input") ? .checked ? "Accepted" : "Declined";
                else if (t.classList.contains("emoji")) a = t.querySelector("input:checked + span") ? .textContent || "";
                else if (t.classList.contains("picture_choice")) {
                    let f = {
                        type: "picture_choice"
                    };
                    if ("radio" === t.querySelector("input").getAttribute("type")) {
                        let h = t.querySelector("input:checked");
                        if (h) {
                            let y = h.parentElement.querySelector("img"),
                                g = y.closest(".col-md-6").querySelector(".image-description");
                            f.url = y.getAttribute("src"), f.description = g.textContent.trim(), f.upload_type = "single", y.getAttribute("src") && (hasInputValue = !0)
                        }
                    } else {
                        f.images = [];
                        var v = t.querySelectorAll("input:checked");
                        v.forEach(e => {
                            var t = e.parentElement.querySelector("img"),
                                a = t.closest(".col-md-6").querySelector(".image-description"),
                                l = t.getAttribute("src"),
                                r = new URL(l).pathname;
                            f.images.push({
                                url: r,
                                description: a.textContent.trim()
                            }), t.getAttribute("src") && (hasInputValue = !0)
                        }), f.upload_type = "multiple"
                    }
                    a = f
                } else if (t.classList.contains("url")) a = {
                    type: "url",
                    value: t.querySelector("input") ? .value || ""
                };
                else if (t.classList.contains("image_display"));
                else if (t.classList.contains("product_choice")) {
                    if (t.querySelector("input") ? .type === "radio") {
                        var x = t.querySelector("input:checked");
                        x && (a = x.parentElement.querySelector("div.product-title").textContent)
                    } else {
                        void 0 === a && (a = "");
                        var v = t.querySelectorAll("input:checked");
                        v.forEach(function(e) {
                            var t = e.parentElement.querySelector("div.product-title").textContent;
                            a += (a ? "\n" : "") + t
                        })
                    }
                } else a = t.querySelector("input,textarea") ? .value || "";
                if (void 0 !== a) {
                    if (!a || t.classList.contains("password") || t.classList.contains("picture_choice") || (hasInputValue = !0), b[r.label]) {
                        if (Array.isArray(b[r.label])) b[r.label].push(a);
                        else {
                            var S = b[r.label];
                            b[r.label] = [S, a]
                        }
                    } else b[r.label] = a
                }
                a = void 0
            }
        });
        let h = {
            form_uuid: e.uuid,
            formResponse: JSON.stringify(b),
            confirmationMail: !0,
            email_check: s,
            utm_params: void 0 != plan_features && plan_features.includes("utm-tracking") ? getUTMParams() : null,
            referrer_url: void 0 != plan_features && plan_features.includes("on-form-submission-record-the-referrer-url") ? getReferrerURL() : null
        };
        fetch(form_url + "/ajaxcall/formresponse", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Shop-UUID": window.shop_uuid
            },
            body: JSON.stringify(h)
        }).then(e => {
            if (!e.ok) throw Error("Network response was not ok " + e.statusText);
            return e.json()
        }).then(t => {
            console.log("Success:", t), swal.close(), void 0 != t.charge_failed ? afterSubmitErrorsAndScroller(t, o, e.uuid) : afterSubmitActionAndAnalytics(e, e.uuid, t)
        }).catch(e => {}), n = "", s = ""
    }
};