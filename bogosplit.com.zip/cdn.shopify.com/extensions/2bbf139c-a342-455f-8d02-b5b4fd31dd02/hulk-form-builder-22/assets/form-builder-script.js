hulk_customer_email = "", window.formbuilder_customer && window.formbuilder_customer.email && (hulk_customer_email = window.formbuilder_customer.email),
    function() {
        var e = document.getElementsByClassName("pxFormGenerator");
        if (form_url = "https://formbuilder.hulkapps.com", e.length > 0)
            for (var t = 0; t < e.length; t++) {
                var a = !0,
                    r = !1;
                if ((curFrame = e[t]).id) {
                    var o = window.fb_form_data["form_" + curFrame.id];
                    window.fb_settings_data.shop_settings, window.fb_settings_data && window.fb_settings_data.shop_settings && window.fb_settings_data.shop_settings.shop_blocked_domains;
                    var i = window.fb_features_data.shop_plan_features,
                        s = void 0 != i ? i.shop_plan_features : void 0;
                    if (void 0 != o) {
                        window.shop_uuid = o ? .shop_uuid || null;
                        var d = window.fb_shop_data["shop_" + shop_uuid];
                        window.shop_timezone = d ? .shop_timezone || null, d ? .form_total_response, window.shop_is_after_submit_enabled = d ? .shop_is_after_submit_enabled || null, window.shop_shopify_plan = d ? .shop_shopify_plan || null, window.shop_shopify_domain = d ? .shop_shopify_domain || null, window.shop_remove_watermark = d ? .shop_remove_watermark || null, window.shop_created_at = d ? .shop_created_at ? new Date(d.shop_created_at) : null;
                        var m = d ? .shop_deleted,
                            f = d ? .shop_disabled,
                            n = d ? .is_skip_metafield
                    }
                    if (void 0 != o && void 0 != d && !1 == n && !1 == m && !1 == f) {
                        r = o.is_spam_form;
                        let l = o.form_data.formElements.some(e => "image" === e.type || "file" === e.type || "signature" === e.type || "page_break" === e.type || "time" === e.type || "date" === e.type || "newdate" === e.type || "phone" === e.type);
                        a = void 0 !== o.form_data.advance_js && "" !== o.form_data.advance_js || void 0 !== o.form_data.after_submit_script && "" !== o.form_data.after_submit_script || "yes" == o.form_data.captcha_enable || "yes" == o.form_data.captcha_honeypot || "yes" == o.form_data.captcha_version_3_enable || "yes" == o.form_data.payment_gateway_integration || !0 == l || void 0 != o.form_data.no_allow_submission && !!(o.form_data.no_allow_submission >= 0) || void 0 == s, console.log("is_load_form_iframe :", a)
                    }
                    if (!1 == r) {
                        if (a) {
                            var p = document.getElementById("frame_" + curFrame.id);
                            if (-1 === document.getElementById(curFrame.id).innerHTML.indexOf("iframe")) {
                                var u = /(?!&)utm_[^=]*=[^&]*(?=)/g,
                                    h = location.search.substr(1).match(u),
                                    c = "";
                                void 0 != h && (c = h.join("&"));
                                var $ = location.href,
                                    g = "";
                                c ? (c = c.includes("utm_source") ? c : "utm_source=hulkapps-form-builder-app&" + c, g = hulk_customer_email ? '<iframe src="' + form_url + "/corepage/customform?id=" + curFrame.id + "&referrer_url=" + $ + "&" + c + "&customer_email=" + hulk_customer_email + '"  id="frame_' + curFrame.id + '" frameborder="0" width="100%">' : '<iframe src="' + form_url + "/corepage/customform?id=" + curFrame.id + "&referrer_url=" + $ + "&" + c + '"  id="frame_' + curFrame.id + '" frameborder="0" width="100%">') : g = hulk_customer_email ? '<iframe src="' + form_url + "/corepage/customform?id=" + curFrame.id + "&referrer_url=" + $ + "&customer_email=" + hulk_customer_email + '"  id="frame_' + curFrame.id + '" frameborder="0" width="100%">' : '<iframe src="' + form_url + "/corepage/customform?id=" + curFrame.id + "&referrer_url=" + $ + '" id="frame_' + curFrame.id + '" frameborder="0" width="100%">', document.getElementById(curFrame.id).innerHTML = g
                            }
                            b(curFrame.id)
                        } else fontAwesomeScript(), formLayout(o.form_data, o.uuid, p), addtionalJS(o.form_data, o.uuid), populateCountryDropdowns(), handleAnalyticsIntegrationsScript(o.form_data)
                    }
                }
            }

        function b(e) {
            var t = document.getElementsByClassName("pxFormGenerator");
            if (t.length > 0)
                for (var a = 0; a < t.length; a++) {
                    document.getElementById(e).style.width;
                    var r = e,
                        o = "frame_" + e,
                        i = function(e) {
                            if (e.origin === form_url) {
                                var t = document.getElementById(o);
                                if (t && e.data.formid == r && (window.FbThemeAppExtSettingsHash && t.contentWindow.postMessage(JSON.stringify(window.FbThemeAppExtSettingsHash), "*"), t.style.height = e.data.height + "px", !0 == e.data.scroll_to)) {
                                    let a = document.querySelector("#frame_" + r),
                                        i = a.getBoundingClientRect(),
                                        s = a.offsetTop > 0 ? a.offsetTop - 50 : .8 * (i.top + window.scrollY),
                                        d = performance.now(),
                                        m = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

                                    function f(e) {
                                        let t = e - d,
                                            a = Math.min(t / 1e3, 1),
                                            r = n(a),
                                            o = m + (s - m) * r;
                                        window.scrollTo(0, o), t < 1e3 && requestAnimationFrame(f)
                                    }

                                    function n(e) {
                                        return e < .5 ? 4 * e * e * e : (e - 1) * (2 * e - 2) * (2 * e - 2) + 1
                                    }
                                    requestAnimationFrame(f)
                                }
                            }
                        };
                    window.addEventListener ? window.addEventListener("message", i, !1) : window.attachEvent && window.attachEvent("onmessage", i)
                }
        }
    }(), "undefined" != typeof document && (initFormBuilder(), keyboardAccess());