let _pf_resizeSlideObserverV2 = (e, l) => {
        if (e) {
            let t = new ResizeObserver(l);
            e.querySelectorAll(".glide-container").forEach(e => t.observe(e))
        }
    },
    _pf_refreshGlider = t => {
        if (t) {
            let e = setInterval(() => {
                isNaN(t ? .slide) ? t ? .refresh() : clearInterval(e)
            }, 100)
        }
    },
    _pf_addPreloadStyle = (e, r, i) => {
        if (e && !e ? .querySelector(".glider-track")) {
            let l = _pf_getDevice();
            var o = e.querySelector(".glider"),
                s = o.getAttribute("style");
            let t = "";
            for (let e = 0; e < i[l]; e++) t += "1fr ";
            o.setAttribute("style", s + "; display: grid; grid-template-columns: " + t), r.forEach((e, t) => {
                t < i[l] || e.setAttribute("style", "display: none")
            }), e.setAttribute("style", "visibility: visible; opacity: 1;")
        }
    },
    _pf_removePreloadStyle = (e, r, i) => {
        if (e && e ? .querySelector(".glider-track")) {
            let l = _pf_getDevice();
            var e = e.querySelector(".glider"),
                o = e.getAttribute("style");
            let t = "";
            for (let e = 0; e < i[l]; e++) t += "1fr ";
            e.setAttribute("style", o.replace("display: grid; grid-template-columns: " + t, "")), r.forEach((e, t) => {
                t < i[l] || (t = e.getAttribute("style"), e.setAttribute("style", t.replace("display: none", "")))
            })
        }
    },
    _pf_handleImageOnClick = e => {
        for (let l of e.querySelectorAll("img")) l.addEventListener("mousedown", () => {
            let e = () => {
                    l.style.pointerEvents = "none"
                },
                t = () => {
                    l.style.pointerEvents = "auto", document.removeEventListener("mousemove", e), document.removeEventListener("mouseup", t)
                };
            document.addEventListener("mousemove", e), document.addEventListener("mouseup", t)
        })
    };
async function _pf_handleSliderHeight(e) {
    var t = Array.from(e.querySelectorAll('.glider-slide.visible [data-pf-type="Slide2"]')),
        l = (await t.map((e, t) => e.removeAttribute("style")), t.map(e => e ? .getBoundingClientRect().height || 0)),
        l = Math.max(...l),
        e = e.querySelector(".glider-track"),
        r = e ? e ? .getBoundingClientRect().height : 0,
        i = e ? .getBoundingClientRect().width;
    r && e.setAttribute("style", `width: ${i}px; height: ${r}px`), l !== r && l && e && e.setAttribute("style", `width: ${i}px; height: ${l}px`), await t.map((e, t) => e.setAttribute("style", "height: 100%"))
}

function _pf_getSliderData(e) {
    e = e ? .getAttribute("data-slider");
    return { ...JSON.parse(e ? .replace(/'/g, '"'))
    }
}
async function _pf_handleSlideshowVersion1and2(g) {
    var e, _ = _pf_getDevice();
    if (g || (e = document.querySelectorAll("[data-slider][data-pf-type]"), g = Array.from(e)), g.length)
        for (let f = 0; f < g.length; f++) {
            let t = g[f];
            _pf_handleImageOnClick(t);
            var h = Array.from(t.querySelectorAll(".glide-wrapper"));
            let e = t.getAttribute("data-pf-type");
            var v = _pf_getSliderData(t);
            let {
                slidesToShow: l,
                slidesToScroll: r,
                loop: i,
                autoPlay: o,
                autoPlayDelay: s,
                maxHeight: a,
                id: d,
                pauseOnHover: n
            } = v, c = (_pf_addPreloadStyle(t, h, l), { ...v,
                slidesToScroll: r.mobile,
                slidesToShow: l.mobile,
                rewind: i,
                draggable: !0,
                scrollLock: !0,
                dragVelocity: 1.1,
                scrollLockDelay: 150,
                arrows: {
                    prev: t.querySelector(".glider-prev"),
                    next: t.querySelector(".glider-next")
                },
                dots: t.querySelector(".glider-dots"),
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: l.tablet,
                        slidesToScroll: r.tablet,
                        draggable: !0
                    }
                }, {
                    breakpoint: 1025,
                    settings: {
                        slidesToShow: l.laptop,
                        slidesToScroll: r.laptop
                    }
                }, {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: l.all,
                        slidesToScroll: r.all
                    }
                }]
            }), u = (["mobile", "tablet"].includes(_) && (c = { ...c,
                draggable: !1
            }), window.__pagefly_slideshows__[d] = new window.Glider(t.querySelector(".glider"), c)), p = (_pf_removePreloadStyle(t, h, l), 0), y = setInterval(() => {
                p++, u.refresh(), t.style.visibility = "visible", t.style.opacity = 1, a || "Slider2" !== e || _pf_handleSliderHeight(t), 2 < p && clearInterval(y)
            }, 500);
            a || "Slider2" !== e || (_pf_handleSliderHeight(t), t.querySelector(".glider").addEventListener("glider-slide-visible", e => {
                _pf_handleSliderHeight(t)
            }), _pf_resizeSlideObserverV2(t, _pf_debounce(() => _pf_handleSliderHeight(t), 100)), window.addEventListener("resize", _pf_debounce(() => _pf_handleSliderHeight(t), 500))), o && 0 < s && _pf_handleAutoPlay1({
                dom: t,
                g: u,
                autoPlayDelay: s,
                pauseOnHover: n
            })
        }
}

function _pf_handleAutoPlay1({
    dom: e,
    g: l,
    autoPlayDelay: t,
    pauseOnHover: r
}) {
    let i = new _pf_AutoplayTimer(function() {
        l.scrollItem("next")
    }, t || 3e3);
    r && (e.querySelectorAll(".glider-nav") ? .forEach(e => {
        e ? .addEventListener("click", () => {
            i.destroy()
        })
    }), e.querySelectorAll(".glider-dot") ? .forEach(e => {
        e ? .addEventListener("click", () => {
            i.destroy()
        })
    })), (() => {
        let t = !1;
        new IntersectionObserver(function(e) {
            e.forEach(e => {
                e.isIntersecting ? (t = !0, i.start(), _pf_refreshGlider(l)) : t && (t = !1, i.destroy(), setTimeout(() => {
                    l.scrollItem(0)
                }, 1e3))
            })
        }, {
            rootMargin: "0px",
            threshold: .25
        }).observe(e)
    })(), r && (e.addEventListener("mouseover", e => {
        i.pause()
    }), e.addEventListener("mouseout", e => {
        i.resume()
    }), e.addEventListener("touchstart", e => {
        i.pause()
    }), e.addEventListener("touchend", e => {
        i.resume()
    }))
}

function _pf_AutoplayTimer(e, t) {
    let l = t,
        r = 0;
    this.pause = function() {
        clearInterval(r)
    }, this.resume = function() {
        this.start()
    }, this.start = function() {
        r = null, r = setInterval(() => {
            0 === (l -= 1e3) && (e(), l = t)
        }, 1e3)
    }, this.destroy = function() {
        clearInterval(r), l = t
    }
}
window.__pagefly_slideshows__ = {}, _pf_handleSlideshowVersion1and2().catch(console.error);