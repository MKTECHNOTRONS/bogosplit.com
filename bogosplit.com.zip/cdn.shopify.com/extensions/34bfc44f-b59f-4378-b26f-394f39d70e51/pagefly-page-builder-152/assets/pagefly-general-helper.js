function _defineProperty(e, t, r) {
    return (t = _toPropertyKey(t)) in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e
}

function _toPropertyKey(e) {
    e = _toPrimitive(e, "string");
    return "symbol" == typeof e ? e : e + ""
}

function _toPrimitive(e, t) {
    if ("object" != typeof e || !e) return e;
    var r = e[Symbol.toPrimitive];
    if (void 0 === r) return ("string" === t ? String : Number)(e);
    r = r.call(e, t || "default");
    if ("object" != typeof r) return r;
    throw new TypeError("@@toPrimitive must return a primitive value.")
}
class _pf_PFBaseCustomElement extends HTMLElement {
    constructor() {
        super(), this.initialize()
    }
    connectedCallback() {
        this.render()
    }
    disconnectedCallback() {
        this._cleanUp()
    }
    static get observedAttributes() {
        return []
    }
    initialize() {
        this.$ = this.querySelector.bind(this), this.$$ = this.querySelectorAll.bind(this), this._eventsMap = new Map
    }
    render() {}
    addSafeEventListener(e, t, r) {
        r = r.bind(this);
        e.addEventListener(t, r), this._eventsMap.has(e) || this._eventsMap.set(e, []), this._eventsMap.get(e).push({
            event: t,
            handler: r
        })
    }
    removeSafeEventListener(t, r) {
        var e = this._eventsMap.get(t);
        e && (e.forEach(({
            handler: e
        }) => t.removeEventListener(r, e)), this._eventsMap.delete(t))
    }
    _removeAllSafeEvents() {
        this._eventsMap.forEach((e, r) => {
            e.forEach(({
                event: e,
                handler: t
            }) => r.removeEventListener(e, t))
        }), this._eventsMap.clear()
    }
    _cleanUp() {
        this._removeAllSafeEvents()
    }
    attributeChangedCallback(e, t, r) {
        t !== r && this.render()
    }
    adoptedCallback() {}
}
class _pf_BaseElementLazyLoader {
    constructor(e) {
        _defineProperty(this, "setProp", (e, t = "src", r = "data-src") => {
            r = e.getAttribute(r);
            return !!r && (e[t] = r, !0)
        }), _defineProperty(this, "removeProp", (e, t = "data-src") => {
            e.hasAttribute(t) && e.removeAttribute(t)
        }), this.options = e
    }
    handleIntersectionObserver(e, r, o, t = null) {
        var n = () => (t || r)();
        try {
            if (window.IntersectionObserver) {
                let t = new IntersectionObserver((e, t) => {
                    e.forEach(e => {
                        e.isIntersecting && (r(e.target, t), o) && t.unobserve(e.target)
                    })
                }, this.options);
                e.forEach(e => t.observe(e))
            } else n()
        } catch (e) {
            n()
        }
    }
    observerElement(e, t, r = !0) {
        this.handleIntersectionObserver([t], e, r)
    }
    observerElements(e, t, r = !0, o) {
        this.handleIntersectionObserver(t, e, r, o)
    }
}
class _pf_PFCustomElementLazyLoader {
    constructor() {
        this.defer = e => (window.requestIdleCallback || requestAnimationFrame).call(window, e), this.loadedScripts = new Set, this.init()
    }
    init() {
        this.defer(() => {
            this.observerCustomElement()
        }), this.registerCustomElementAddEvent()
    }
    observerCustomElement(e = document) {
        let t = [];
        e instanceof Element ? (t = e.hasAttribute("data-pf-belong-to-custom-element") ? [e, ...Array.from(e.querySelectorAll('[data-pf-belong-to-custom-element="true"]'))] : Array.from(e.querySelectorAll('[data-pf-belong-to-custom-element="true"]')), this.loadCustomElements(t)) : (t = Array.from(e.querySelectorAll('[data-pf-belong-to-custom-element="true"]')), this.intersectionObserver = new IntersectionObserver(e => {
            e = e.map(e => {
                if (e.isIntersecting && !customElements.get(e.target.localName)) return e.target
            }).filter(Boolean);
            this.loadCustomElements(e)
        }), t.forEach(e => {
            this.intersectionObserver.observe(e)
        }))
    }
    loadCustomElements(e) {
        let r = new Set;
        e.forEach(e => {
            e.getAttribute("data-pf-custom-element-file").split(",").forEach(e => {
                var t = window.PAGEFLY.custom_elements_mapper ? .[e];
                t && !this.loadedScripts.has(e) && (r.add(t), this.loadedScripts.add(e))
            })
        }), _pf_loadMultipleScripts(Array.from(r), {
            async: !1,
            defer: !0
        }, document.body)
    }
    registerCustomElementAddEvent() {
        document.addEventListener("pagefly-custom-element-added", e => {
            let t = e.detail.target;
            this.defer(() => this.observerCustomElement(t))
        })
    }
}
class _pf_PageFlyHelperStore {
    constructor() {
        _defineProperty(this, "cart", {}), _defineProperty(this, "_listeners", []), _defineProperty(this, "lastATCResult", {}), _defineProperty(this, "autoCartUpdate", !0)
    }
    subscribe(e) {
        this._listeners.push(e)
    }
    unsubscribe(t) {
        this._listeners = this._listeners.filter(e => e !== t)
    }
    update(t) {
        this._listeners.forEach(e => e(t))
    }
    set(e, t) {
        this[e] = t, this.update()
    }
}
class _pf_PFPagePrefetcher {
    constructor() {
        this.lastTouchTimestamp = 0, this.mouseoverTimeout = null, this.cachedURLToPrefetch = new Map, this.prefetcher = document.createElement("link"), this.prefetcher.id = "pf-prefetcher", this.isDataSaverEnabled = navigator.connection && navigator.connection.saveData, this.isPrefetchAvailable = this.prefetcher && this.prefetcher.relList.supports && this.prefetcher.relList.supports("prefetch"), this.startTime = 0, this.init()
    }
    init() {
        this.prefetcher.rel = "prefetch", this.prefetcher.as = "document", document.head.appendChild(this.prefetcher), this.bindEventHandler()
    }
    bindEventHandler() {
        document.addEventListener("touchstart", this.handleTouchstartEvent.bind(this), {
            capture: !0,
            passive: !0
        }), document.addEventListener("mouseover", this.handleMouseoverEvent.bind(this), {
            capture: !0,
            passive: !0
        }), this.prefetcher.onload = e => {
            e = e.currentTarget;
            this.cachedURLToPrefetch.set(e.href, !0)
        }, this.prefetcher.onerror = e => {
            this.cachedURLToPrefetch.set(e.currentTarget.href, !0)
        }
    }
    handleTouchstartEvent(e) {
        this.lastTouchTimestamp = performance.now();
        var e = e.target.closest("a, [data-href]"),
            t = this.isPrefetchable(e);
        t && e && (e.addEventListener("touchcancel", this.handleTouchcancelAndTouchEndEvent.bind(this), {
            passive: !0
        }), e.addEventListener("touchend", this.handleTouchcancelAndTouchEndEvent.bind(this), {
            passive: !0
        }), this.prefetch(t))
    }
    handleTouchcancelAndTouchEndEvent(e) {
        this.stopPrefetching()
    }
    handleMouseoverEvent(t) {
        if (!(performance.now() - this.lastTouchTimestamp < 1100)) {
            t = t.target.closest("a, [data-href]");
            let e = this.isPrefetchable(t);
            e && t && (t.addEventListener("mouseout", this.handleMouseoutEvent.bind(this), {
                passive: !0
            }), this.mouseoverTimeout = window.setTimeout(() => {
                this.prefetch(e), this.mouseoverTimeout && clearTimeout(this.mouseoverTimeout)
            }, 65))
        }
    }
    handleMouseoutEvent(e) {
        var t = e.relatedTarget;
        t && e.target.closest("a, [data-href]") === t.closest("a, [data-href]") || this.stopPrefetching()
    }
    getAbsoluteUrl(t) {
        try {
            return new URL(t)
        } catch (e) {
            return new URL(t, window.location.origin)
        }
    }
    isPrefetchable(e) {
        return !(!e ? .hasAttribute("data-pf-type") && !e ? .closest("[data-pf-type]")) && !!(e = e ? .href || e ? .getAttribute("data-href") || "") && (e = this.getAbsoluteUrl(e), !this.cachedURLToPrefetch.get(e.href)) && e.origin === location.origin && ["http:", "https:"].includes(e.protocol) && !("http:" === e.protocol && "https:" === location.protocol) && !(e.hash && e.pathname + e.search === location.pathname + location.search) && e.href
    }
    prefetch(e) {
        this.prefetcher.setAttribute("href", e), this.isPrefetchAvailable || this.prefetchViaXHR(e)
    }
    stopPrefetching() {
        this.prefetcher.removeAttribute("href")
    }
    prefetchViaXHR(o) {
        return new Promise((e, t) => {
            let r = new XMLHttpRequest;
            r.open("GET", o, !0), this.cachedURLToPrefetch.set(o, !0), r.onload = () => {
                (200 <= r.status && r.status < 300 ? e : t)()
            }, r.onerror = () => t(), r.send()
        })
    }
}
class _pf_SocialMediaFrameLoader extends _pf_BaseElementLazyLoader {
    constructor({
        optionObserver: e = _pf_defaultOptionObserver,
        ...t
    }) {
        super(e), _defineProperty(this, "type", "iframe"), _defineProperty(this, "loadMedia", e => {
            "video" === this.type ? (this.setProp(e, "poster", "data-poster") && this.removeProp(e, "data-poster"), e.querySelectorAll("source[data-src]").forEach(e => {
                this.setProp(e) && this.removeProp(e)
            }), e.load()) : this.setProp(e) && this.removeProp(e)
        }), Object.assign(this, t), this.init()
    }
    init() {
        var e = this.containerElement || [].slice.call(document.querySelectorAll(this.containerSelector));
        _pf_executeChunk(e, e => {
            e = [].slice.call(e.querySelectorAll(this.elementSelector));
            e.length && e.forEach(e => this.observerElement(this.loadMedia, e))
        })
    }
}
let _pf_handleLazyLoadLegacyBackgroundVideo = e => document.querySelectorAll('video.pf-media-bg-video:not([data-pf-type="BackgroundVideo"])') ? e.add(window ? .PAGEFLY ? .elements_asset_mapper["HTML.Video2"]) : e,
    _pf___pagefly_product_store_data__ = window.__pagefly_product_store__ = new _pf_PageFlyHelperStore,
    _pf___pagefly_helper_store_data__ = window.__pagefly_helper_store__ = new _pf_PageFlyHelperStore,
    _pf_specificHelperCDN = ["https://cdn.pagefly.io/static/core/helper.js"],
    _pf_detectPageFlyHelperVersion = () => {
        var e = [{
            version: "legacy",
            selector: '[data-pf-editor-version="legacy"], [data-pf-type="Section"]'
        }, {
            version: "gen-2",
            selector: '[data-pf-editor-version="gen-2"], [data-pf-type="FlexSection"]'
        }].filter(({
            selector: e
        }) => document.querySelector(e)) ? .map(({
            version: e
        }) => e);
        window.PAGEFLY = {
            editorVersions: e
        }
    },
    _pf_runHelper = () => {
        var e;
        !Array.from(document.querySelectorAll("script")).map(e => {
            e = e.getAttribute("src");
            return _pf_specificHelperCDN.includes(e) ? "2.0.0" : _pf_getPFHelperVersion(e || "")
        }).filter(e => e).find(e => _pf_comparePFHelperVersion(e, _pf_STARTED_VERSION_USING_THEME_APP_EXTENSION) < 0) && (console.log("Run PageFly Theme Extension..."), _pf_detectPageFlyHelperVersion(), e = document.getElementById("pagefly-helper-data")) && (e = JSON.parse(e.textContent), Object.assign(window.PAGEFLY, e), _pf_elementsHelperTrigger(), _pf_handleAnimation().catch(console.error), _pf_handleLazyLoadBackgroundImage().catch(console.error), _pf_handlePrefetchAssets().catch(console.error))
    },
    _pf_runHelperOnThemeEditor = () => {
        try {
            window.Shopify ? .designMode && document.addEventListener("shopify:section:load", function(e) {
                var t;
                e.target.closest("[data-shopify-editor-section*=pagefly_section]") && (e = document.querySelectorAll("[data-shopify-editor-section*=pf-]"), t = document.querySelectorAll("[data-shopify-editor-section*=pagefly_section]"), [...e, ...t].forEach(e => {
                    var t = e.cloneNode(!0);
                    e.replaceWith(t)
                }), document.querySelectorAll("[data-pf-type=ProductQuantity]").forEach(e => {
                    e.removeAttribute("listener")
                }), _pf_executeScriptElements(), _pf_runHelper())
            })
        } catch (e) {
            console.error("Run helper on theme editor", e)
        }
    },
    _pf_webStorage = {
        storage: null,
        init() {
            try {
                var e = "__webStorageTest__";
                window.localStorage.setItem(e, e), window.localStorage.removeItem(e), this.storage = window.localStorage
            } catch (e) {
                console.warn("LocalStorage is not available. Your data will not persist across sessions. Consider enabling third-party cookies for a better experience."), this.storage = {}
            }
        },
        setItem(e, t) {
            this.storage instanceof Storage ? this.storage.setItem(e, t) : this.storage[e] = t
        },
        getItem(e) {
            return this.storage instanceof Storage ? this.storage.getItem(e) || null : this.storage[e] || null
        },
        removeItem(e) {
            this.storage instanceof Storage ? this.storage.removeItem(e) : delete this.storage[e]
        },
        clear() {
            this.storage instanceof Storage ? this.storage.clear() : this.storage = {}
        }
    },
    _pf_setupEventTracking = async () => {
        (_pf_pfPageSetting.trackingIDs || _pf_pfSetting.trackingIDs || []).forEach(e => {
            let {
                gaEvent: t,
                type: r,
                pxEvent: o,
                pxCode: n,
                elementType: a,
                elementIndex: i
            } = e, s = `.pf-${i}_`;
            "ProductImage" === a && (s += ' [data-pf-type="MasterImage"]');
            e = document.querySelector(s);
            if (!e) return console.warn("Not found element", s);
            (t || o || n) && e.addEventListener("click", () => {
                var e;
                t && "function" == typeof window.ga && ("string" == typeof t ? (window.ga("send", "event", ...t.split(",")), console.info("Send Ga event:: ", r, ...t.split(","))) : (e = {
                    hitType: "event",
                    eventCategory: t[0] || "",
                    eventAction: t[1] || "",
                    eventLabel: t[2] || ""
                }, window.ga("send", e), console.info("Send Ga event:: ", r, e))), n && "function" == typeof window.fbq && (new Function(n)(), console.info("Send FB Pixel event:: ", r, n, o))
            })
        })
    };

function _pf_getOffset(e) {
    var t = document.body.getBoundingClientRect(),
        r = e.getBoundingClientRect();
    return {
        top: r.top - t.top,
        height: (e.offsetHeight || r.height) / 4,
        clientRect: e.getBoundingClientRect()
    }
}
async function _pf_handleAnimation() {
    let r = window.innerHeight;
    var e = document.querySelectorAll(".__pf [class*=animate]"),
        t = document.querySelectorAll(".__pf [data-popup-animation]"),
        o = document.querySelectorAll(".__pf [data-animation]");
    if (!document.querySelector(`link[href*="${_pf_PAGEFLY_ANIMATION_CSS}.css"]`) && (e.length || t.length || o.length)) {
        let e = document.createElement("link");
        e.rel = "stylesheet", e.href = _pf_pfSetting.cdnURL + "/static/css/animation.css", e.media = "print", e.onload = () => {
            e.media = "all"
        }, document.head.appendChild(e)
    }
    let a = [];
    for (let e = 0; e < o.length; e++) {
        a.push({
            element: o[e],
            position: window.pfCustomGetOffset ? window.pfCustomGetOffset(o[e]) : _pf_getOffset(o[e]),
            animation: o[e].getAttribute("data-animation")
        });
        var n = a[a.length - 1],
            i = n.animation;
        if (i) {
            let e = n.element; - 1 !== i.toLowerCase().indexOf("in") && (e.style.visibility = "hidden");
            var s = window.scrollY || document.body.scrollTop;
            n.position.top + n.position.height <= r + s && (e.style.visibility = "visible", e.setAttribute("class", `${e.getAttribute("class")||""} pf-animated ` + i)), n.element.onanimationend = () => {
                setTimeout(() => {
                    e.classList.remove("pf-animated")
                }, 2e3)
            }
        }
    }
    document.addEventListener("scroll", e => {
        var t = window.scrollY || document.body.scrollTop;
        let n = r + t;
        a.forEach(({
            element: e,
            position: t,
            animation: r
        }) => {
            var o = Number(e.dataset.offset) || 0;
            t.top + t.height + o < n && r && !e.classList.contains(r) && (e.style.visibility = "visible", e.setAttribute("class", `${e.getAttribute("class")||""} pf-animated ` + r))
        })
    }, !0)
}

function _pf_loadMultipleScripts(e, r = {}, t = document.body) {
    let o = document.createDocumentFragment();
    e.length && (e.forEach(e => {
        var t = document.createElement("script");
        Object.assign(t, {
            src: e,
            ...r
        }), t.onload = () => {
            console.log("Script loaded successfully: " + e)
        }, t.onerror = () => {
            console.error("Error loading script: " + e)
        }, t.defer && t.setAttribute("defer", "defer"), o.appendChild(t)
    }), t.appendChild(o))
}

function _pf_elementsHelperTrigger() {
    try {
        var e = Object.keys(window ? .PAGEFLY ? .elements_asset_mapper).map(e => `[data-pf-type="${e}"]`).join(","),
            r = document.querySelectorAll(e);
        let t = new Set;
        r.forEach(e => {
            e = window ? .PAGEFLY ? .elements_asset_mapper[e.getAttribute("data-pf-type")];
            t.add(e)
        });
        var o = document.body || document.head || document.documentElement;
        t = _pf_handleLazyLoadLegacyBackgroundVideo(t), _pf_loadMultipleScripts(Array.from(t), {
            defer: !0
        }, o)
    } catch (e) {
        console.error("PF elements helper error: ", e)
    }
}
async function _pf_handleLazyLoadBackgroundImage() {
    setTimeout(() => {
        if ("IntersectionObserver" in window) {
            var e = [].slice.call(document.querySelectorAll(".pf-bg-lazy"));
            let r = new IntersectionObserver(function(e, t) {
                e.forEach(function(e) {
                    e.isIntersecting && ((e = e.target).classList.remove("pf-bg-lazy"), r.unobserve(e))
                })
            }, {
                rootMargin: "5%"
            });
            e.forEach(function(e) {
                r.observe(e)
            })
        } else setTimeout(() => {
            document.querySelectorAll(".pf-bg-lazy").forEach(e => {
                e.classList.remove("pf-bg-lazy")
            })
        }, 3e3)
    }), setTimeout(() => {
        document.querySelectorAll(".pf-bg-lazy").forEach(e => {
            e.classList.remove("pf-bg-lazy")
        })
    }, 1e4)
}
async function _pf_handlePrefetchAssets() {
    window.PAGEFLY ? .page_optimization ? .assets_prefetching && new _pf_PFPagePrefetcher
}

function _pf_getPFHelperVersion(e) {
    try {
        var t, r, o = /^https:\/\/(cdn|apps|wip|rc)\.pagefly\.io\/pagefly\/[^\/]+\/core\/helper\.js.*$/;
        return /^https:\/\/(cdn|apps|wip|rc)\.pagefly\.io\/assets\/pagefly\/assets\/[^\/]+\/helper\.js.*$/.test(e) ? (t = e.split("/"))[t.length - 2] : o.test(e) ? (r = e.split("/"))[r.length - 3] : null
    } catch (e) {
        console.error("Get PF helper version", e)
    }
}

function _pf_comparePFHelperVersion(e, t) {
    try {
        var r = e.split("."),
            o = t.split(".");
        return r[0] == o[0] ? r[1] == o[1] ? parseInt(r[2]) - parseInt(o[2]) : parseInt(r[1]) - parseInt(o[1]) : parseInt(r[0]) - parseInt(o[0])
    } catch (e) {
        console.error("Compare version helper", e)
    }
}

function _pf_executeScriptElements() {
    var e = document.querySelectorAll("script");
    Array.from(e).forEach(e => {
        if (!e.getAttribute("data-pf-activated")) {
            let t = document.createElement("script");
            Array.from(e.attributes).forEach(e => {
                t.setAttribute(e.name, e.value)
            }), t.appendChild(document.createTextNode(e.innerHTML)), t.setAttribute("data-pf-activated", "true"), e.parentNode.replaceChild(t, e)
        }
    })
}
async function _pf_handleGlobalSections() {
    var e = document.querySelectorAll('[data-pf-type="GlobalSection"]');
    0 < e.length && e.forEach(e => {
        var t;
        (t = e).querySelectorAll('[data-pf-type="Section"],[data-pf-type="FlexSection"]').forEach(e => {
            e = getComputedStyle(e);
            "sticky" === e.position && Object.assign(t.style, {
                position: e.position,
                top: e.top,
                zIndex: e.zIndex
            })
        })
    })
}
async function _pf_handleAction() {
    _pf_initModal().catch(console.error), _pf_hideModal().catch(console.error), _pf_initParallax().catch(console.error), _pf_openLightbox().catch(console.error), _pf_openUrl().catch(console.error), _pf_handleScrollToSection().catch(console.error), _pf_handleOpenPopup().catch(console.error), _pf_handleGlobalSections().catch(console.error), _pf_setupEventTracking().catch(console.error)
}
async function _pf_initModal() {
    var e = document.querySelectorAll('[data-action="modal"]'),
        t = document.querySelectorAll('[data-action="lightbox"]'),
        r = document.querySelectorAll('[data-action="popup-video"]');
    (e.length || t.length || r.length) && (e = document.createElement("style"), (t = document.createElement("dialog")).classList.add("pf-m"), document.body.append(t), (r = document.createElement("button")).innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 224.512 224.512" style="enable-background:new 0 0 224.512 224.512;" xml:space="preserve" width="16" height="16" class=""><g><g>
	<polygon style="fill:#FFFFFF" points="224.507,6.997 217.521,0 112.256,105.258 6.998,0 0.005,6.997 105.263,112.254    0.005,217.512 6.998,224.512 112.256,119.24 217.521,224.512 224.507,217.512 119.249,112.254  " data-original="#010002" class="active-path" data-old_color="#010002"></polygon>
</g></g> </svg>`, r.classList.add("pf-close-btn"), t.appendChild(r), document.head.appendChild(e), e.appendChild(document.createTextNode(_pf_modalDataCss)))
}

function _pf_handleRemoveModalContent(t) {
    Array.from(t.children).filter(e => !e.classList.contains("pf-close-btn")).forEach(e => t.removeChild(e)), t.style.display = "none", t.style.removeProperty("width"), t.style.removeProperty("max-height"), t.style.removeProperty("height")
}
async function _pf_hideModal() {
    let t = document.querySelector(".pf-m");
    t && (t.addEventListener("click", e => {
        e = e.target;
        e !== t && "button" !== e.tagName.toLowerCase() || t.close()
    }), t.addEventListener("close", () => {
        _pf_handleRemoveModalContent(t)
    }))
}
async function _pf_initParallax() {
    0 < document.querySelectorAll(_pf_PARALLAX_SELECTOR).length && (await _pf_loadJS("https://cdn.pagefly.io/static/assets/jarallax.min.js").catch(console.error), setTimeout(() => {
        document.querySelectorAll(_pf_PARALLAX_SELECTOR).forEach(e => {
            var t = e.getAttribute("data-parallax-speed") || 4;
            let r = e.querySelector(".pf-parallax-img");
            "jarallax" in window && window.jarallax(e, {
                speed: Number(t) / 10,
                imgElement: ".pf-parallax-img",
                onInit: function() {
                    r.style.opacity = 1
                }
            })
        })
    }, 100))
}
async function _pf_openLightbox() {
    document.querySelectorAll("[data-action='lightbox']").forEach(e => {
        e.addEventListener("click", e => {
            var t = e.currentTarget,
                e = (e.preventDefault(), e.stopPropagation(), document.querySelector(".pf-m")),
                r = (e.style.display = "flex", e.style.maxHeight = "100%", document.createElement("img")),
                t = t.getAttribute("data-href") || t.getAttribute("href");
            t && (r.src = _pf_getOriginalSrc(t)), e.appendChild(r), e.showModal()
        })
    })
}
async function _pf_handleOpenPopup() {
    var e = document.querySelectorAll('[data-action="modal"]');
    let f = document.querySelector(".pf-m");
    e.forEach(e => {
        e.addEventListener("click", async n => {
            n.stopPropagation();
            let a = document.createElement("iframe");
            _pf_setAttributes(a, {
                "data-pagefly-popup": !0,
                allowfullscreen: "allowfullscreen",
                style: "width: 100%; height: calc(100% - 24px)"
            });
            var r = n.currentTarget;
            let {
                src: e,
                width: t,
                height: o,
                popupAnimation: i,
                popupContent: s
            } = r.dataset;
            if (e) {
                if ("image" === s) {
                    var {
                        imagePopupObjFit: l,
                        imagePopupAlt: c,
                        imagePopupTitle: d,
                        imagePopupObjPosition: p
                    } = r.dataset, h = document.createElement("img"), l = {
                        src: _pf_getOriginalSrc(e),
                        style: `width: 100%; height: calc(100% - 24px); display: block; margin: auto; object-fit: ${l}; object-position: ` + p
                    };
                    c && (l.alt = c), d && (l.title = d), _pf_setAttributes(h, l), i && (h.className = "pf-animated " + i), Array.from(f.children).length < 2 && f.append(h)
                } else if ("youtube" === s || "vimeo" === s) Array.from(f.children).length < 2 && f.append(a), _pf_setAttributes(a, {
                    src: e
                });
                else if ("video" === s) {
                    var {
                        muted: p,
                        loop: c,
                        controls: d,
                        autoplay: l
                    } = r.dataset;
                    let e = r.dataset.src,
                        t = document.createElement("video");
                    _pf_setAttributes(t, {
                        style: "width: 100%; height: calc(100% - 24px)"
                    }), t.classList.add("pf-html5-video"), Array.from(f.children).length < 2 && f.append(t), n.preventDefault(), n.stopPropagation(), l = "true" === l, d = "true" === d, c = "true" === c, p = "true" === p, f.style.cssText = "visibility: visible; width: 650px; height: 450px;", _pf_setAttributes(t, {
                        src: e
                    }), d && _pf_setAttributes(t, {
                        controls: ""
                    }), l && t.play(), t.addEventListener("click", e => {
                        e.preventDefault(), e.stopPropagation(), !1 === e.currentTarget.hasAttribute("controls") && (t.paused ? t.play() : t.pause())
                    }), c && _pf_setAttributes(t, {
                        loop: ""
                    }), t.muted = p
                } else if ("shopify" === s) {
                    let t = !1,
                        r = !1,
                        o = await _pf_getHttpRequest(e);
                    a.onload = e => {
                        console.log("iframe load", e, a.contentDocument), a.contentDocument && t ? r && !t || (console.log("addIframeEvent", a.contentDocument), r = !0, a.contentDocument.querySelectorAll("form").forEach(t => {
                            t.addEventListener("submit", function(e) {
                                e.preventDefault(), _pf_pageflyPost(t.getAttribute("action"), _pf_serializeArray(new FormData(t)))
                            })
                        }), a.contentDocument.querySelectorAll("a").forEach(e => {
                            e.addEventListener("click", function(e) {
                                e.preventDefault();
                                var e = e.currentTarget,
                                    t = (console.log("redirect", e), e.getAttribute("href")),
                                    e = e.getAttribute("target");
                                t && ("_blank" === e ? window.open(t) : window.location.href = t)
                            })
                        })) : (_pf_setAttributes(a, {
                            srcdoc: o
                        }), t = !0)
                    }, Array.from(f.children).length < 2 && f.append(a), setTimeout(() => {
                        console.log("iframe error", n, a.contentDocument), a.contentDocument || (_pf_setAttributes(a, {
                            srcdoc: o
                        }), t = !0)
                    }, 1e3)
                }
                f.style.display = "flex", f.style.width = t, f.style.height = `calc(${o} + 24px)`, f.showModal(), i && (a.className = "pf-animated " + i)
            }
        })
    })
}

function _pf_serializeArray(e) {
    var t, r, o = [];
    for ([t, r] of e) o.push({
        name: t,
        value: r
    });
    return o
}

function _pf_pageflyPost(e, t, r = "post") {
    let o = document.createElement("form");
    o.method = r, o.action = e, t.forEach(function(e) {
        var t = document.createElement("input");
        t.type = "hidden", t.name = e.name, t.value = e.value, o.appendChild(t)
    }), document.body.appendChild(o), o.submit()
}
async function _pf_openUrl() {
    document.querySelectorAll("[data-href][data-pf-type]").forEach(e => {
        let o = e.getAttribute("data-href") || "";
        if (o && (!e.getAttribute("data-action") || ["url", "phone", "email"].includes(e.getAttribute("data-action")))) {
            let r = e.getAttribute("data-target") || "_self";
            e.addEventListener("click", e => {
                e.stopPropagation();
                var t = () => {
                    o && (e.ctrlKey || e.metaKey) ? window.open(o, "_blank") : o && window.open(o, r)
                };
                _pf_isTrackingActive() && window.gtag && -1 < o.indexOf("/products/") ? window.gtag("event", "pf_view_product", Object.assign({
                    send_to: "pagefly",
                    pf_view_product: 1,
                    pf_product_handle: o,
                    pf_event: "view_product",
                    event_callback: t
                }, window.pfPageInfo)) : t()
            })
        }
    })
}
async function _pf_handleScrollToSection() {
    var e = document.querySelectorAll("[data-to-section]");
    let a = _pf_getDevice();
    e.forEach(o => {
        let n = JSON.parse(o.getAttribute("data-offset"));
        window.addEventListener("load", () => {
            var e = o.getAttribute("data-to-section");
            let t = (document.querySelector(`[data-section-id=${e}]`) || document.querySelector("." + e)) ? .previousElementSibling;
            for (; t;) {
                var r = t.querySelectorAll('img[loading="lazy"]:not([decoding])');
                for (let e = 0; e < r.length; e++) r[e].removeAttribute("loading");
                t = t ? .previousElementSibling
            }
        }), o.addEventListener("click", e => {
            var t = n[a] ? parseInt(n[a]) : 0;
            e.preventDefault(), e.stopPropagation();
            var e = e.currentTarget.getAttribute("data-to-section"),
                r = "pf_accordion_offset" in window ? window.pf_accordion_offset : 0;
            e && (e = (document.querySelector(`[data-section-id=${e}]`) || document.querySelector("." + e)).getBoundingClientRect().top - document.body.getBoundingClientRect().top, _pf_smoothScroll(e - r - t, 1e3))
        })
    })
}
window.__pagefly__.handleLazyLoadBackgroundImage = _pf_handleLazyLoadBackgroundImage, _pf_runHelper(), _pf_runHelperOnThemeEditor(), _pf_webStorage.init(), window.__webStorage__ = _pf_webStorage.storage, _pf_handleAction().catch(console.error), window.__openUrl = _pf_openUrl;