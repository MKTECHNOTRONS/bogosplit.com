function _defineProperty(e, t, a) {
    return (t = _toPropertyKey(t)) in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e
}

function _toPropertyKey(e) {
    e = _toPrimitive(e, "string");
    return "symbol" == typeof e ? e : e + ""
}

function _toPrimitive(e, t) {
    if ("object" != typeof e || !e) return e;
    var a = e[Symbol.toPrimitive];
    if (void 0 === a) return ("string" === t ? String : Number)(e);
    a = a.call(e, t || "default");
    if ("object" != typeof a) return a;
    throw new TypeError("@@toPrimitive must return a primitive value.")
}
class _pf_ProductImage {
    get boxId() {
        return this._boxId
    }
    get pId() {
        return this._pId
    }
    constructor(e) {
        _defineProperty(this, "handleItemSelect", (e, t = !0) => {
            var {
                limit: a,
                listLayout: r
            } = this.setting, a = a[this.device];
            (e = e.closest(_pf_ProductImage.selector.item)) && (this.active = this.index, this.index = Object.values(this.$Items).indexOf(e), this.active === this.index && a % 2 == 1 || (this.switchImage(this.index, this.active, !0, t), r === _pf_LIST_LAYOUT.SLIDE && this.handleSlideList(a)))
        }), this.$el = e, this.handleItemClick = this.handleItemClick.bind(this), this.handleItemSelect = this.handleItemSelect.bind(this), this.triggerClickAction = this.triggerClickAction.bind(this), this.init()
    }
    init() {
        this.initValue(), this.initDefault()
    }
    initValue() {
        var e = _pf_ProductImage.selector;
        this.device = _pf_getDevice(), this._pId = this.$el.getAttribute("data-product-id"), this.product = _pf_pageflyProducts[this.pId], this.setting = _pf_getFrontEndSettings(this.$el) || {}, console.log("this.setting", this.setting), this.boxName = this.$el.closest(e.box) ? .className, this._boxId = _pf_getProductBoxId(this.$el), this.$master = this.$el.querySelector(e.master), this.$MasterImg = this.$master.querySelector("img"), this.$List = this.$el.querySelector(e.list), this.$Paginator = this.$el.querySelectorAll(e.pagination + ">span"), this.$Items = this.$el.querySelectorAll(e.item), this.itemLength = this.$Items.length, 0 !== this.itemLength && (this.transform = new _pf_Transform(this.$List, this.setting, this.$Items[0], .5), this.activeIndex = 0, this.active = 0, this.index = 0)
    }
    initDefault() {
        if (0 !== this.itemLength) {
            var a = this.setting.imageSource,
                r = _pf_pageflyProducts[this.pId] ? .selected_or_first_available_variant || _pf_pageflyProducts[this.pId] ? .variants[0];
            if (r) {
                let e = r ? .featured_image ? .position,
                    t = ("variant" === a && "number" == typeof e ? setTimeout(() => this.handleItemSelect(this.$Items[e - 1], !1), 500) : (this.$Items[0] ? .setAttribute("data-active", "true"), this.$Paginator[0] ? .setAttribute("data-active", "true")), "");
                switch (this.device) {
                    case "all":
                        t = "pf-lg-hide";
                        break;
                    case "laptop":
                        t = "pf-md-hide";
                        break;
                    case "tablet":
                        t = "pf-sm-hide";
                        break;
                    case "mobile":
                        t = "pf-hide"
                }
                this.$Items.forEach(e => {
                    t && e.classList.contains(t) && e.setAttribute("hidden", "hidden"), e.classList.remove("pf-lg-hide", "pf-md-hide", "pf-sm-hide", "pf-hide")
                })
            }
        }
    }
    triggerClickAction() {
        var t = this.setting.clickAction;
        if (t === _pf_CLICK_ACTION.SHOW_FULLSCREEN) this.showImageGallery();
        else if (t === _pf_CLICK_ACTION.LINK_TO_PRODUCT) {
            let e = this.$master.getAttribute("data-href");
            e && window && (t = () => window.open(e, "_self"), _pf_isTrackingActive() && -1 < e.indexOf("/products/") && window.gtag ? window.gtag("event", "pf_view_product", Object.assign({
                send_to: "pagefly",
                pf_view_product: 1,
                pf_product_handle: e,
                pf_event: "view_product",
                event_callback: t
            }, window.pfPageInfo)) : t())
        }
    }
    run() {
        0 !== this.itemLength && (["mobile", "tablet"].includes(this.device) ? this.handleSwipe() : this.handleHover(), this.$master.addEventListener("click", this.triggerClickAction), this.$Items.forEach(e => e.addEventListener("click", this.handleItemClick)), this.$el.querySelector(_pf_ProductImage.selector.nextArrow) ? .addEventListener("click", e => {
            this.animating || this.$Items[this.index + 1] && this.handleItemSelect(this.$Items[this.index + 1])
        }), this.$el.querySelector(_pf_ProductImage.selector.prevArrow) ? .addEventListener("click", e => {
            this.animating || this.$Items[this.index - 1] && this.handleItemSelect(this.$Items[this.index - 1])
        }))
    }
    showImageGallery() {
        var e;
        this.imageGallery || (e = _pf_pageflyProducts[this.pId].media ? .filter(e => "image" === e ? .media_type), this.imageGallery = new _pf_MediaGallery(e, document.body)), this.imageGallery.show(this.index)
    }
    updateByVariant(e) {
        var e = e.featured_image;
        e && (e = e.id, e) && (e = this.$el.querySelector(`[data-img-id="${e}"]`)) && !e.getAttribute("data-active") && this.handleItemSelect(e)
    }
    switchImage(e = this.index, a = this.active, r = !0, i = !0) {
        var n = this.$Items[e].querySelector("img"),
            o = this.$Items[e].getAttribute("data-variant-id");
        if (!this.$MasterImg.classList.contains("pf-img-lazy") && (this.$MasterImg.setAttribute("src", n.src), this.$MasterImg.setAttribute("srcset", n.srcset)), o && this.$MasterImg.setAttribute("data-variant-id", o), r) {
            this.$Items[a].removeAttribute("data-active"), this.$Paginator[a].removeAttribute("data-active"), this.$Items[e].setAttribute("data-active", "true"), this.$Paginator[e].setAttribute("data-active", "true");
            o = this.$master.querySelector("div.zoom-image");
            o && (r = n.src, o.style.backgroundImage = `url('${r}')`, o.style.width = this.$MasterImg.width + "px", o.style.height = this.$MasterImg.height + "px");
            let t = this.$Items[e].getAttribute("data-img-id");
            a = this.product ? .variants.find(e => e.featured_image ? .id.toString() === t);
            a && i && ({
                variant_ids: n
            } = a.featured_image, r = this.product.pfCurrentVariant && this.product.pfCurrentVariant[this.boxId || _pf_OUTSIDE_BOX_KEY] ? .id, n.includes(r) || _pf_updateByCurrentVariant(this.pId, a, this.boxName, !1, !0))
        }
    }
    handleItemClick(e) {
        let t = e.target;
        t = t.closest(_pf_ProductImage.selector.item), this.handleItemSelect(t)
    }
    handleSlideList(e) {
        var t = (e - 1) / 2;
        let a = !0,
            r = (this.activeIndex + (this.index - this.active) < t && (a = !1), this.index - (a ? Math.floor(t) : Math.ceil(t))),
            i = this.index + (a ? Math.ceil(t) : Math.floor(t));
        this.activeIndex = a ? Math.floor(t) : Math.ceil(t), r < 0 ? (i -= r, r = 0, this.activeIndex = this.index) : i > this.itemLength - 1 && (r -= i - this.itemLength + 1, i = this.itemLength - 1, this.activeIndex = this.index % e + 1), this.$Items.forEach((e, t) => {
            t < r || t > i ? e.hasAttribute("hidden") || this.transform.hiddenList.push(e) : e.hasAttribute("hidden") && this.transform.showList.push(e)
        }), 0 < this.transform.hiddenList.length && (this.animating = !0, this.transform.endCallback.push(() => {
            this.animating = !1
        }), this.transform.run(a))
    }
    handleHover() {
        let a = 100,
            {
                onHover: e,
                hoverAction: t
            } = this.setting,
            r = this.index,
            i = !1;
        if (t === _pf_HOVER_ACTION.NONE) return;
        if (t === _pf_HOVER_ACTION.MAGNIFIER) {
            this.$master.setAttribute("data-magnifier", "true");
            let e = () => {
                window.innerWidth < 991 || setTimeout(() => {
                    _pf_initZoomImage(this.$master)
                }, 500)
            };
            return void(_pf_lazyLoad ? this.$MasterImg.onload = () => {
                e()
            } : e())
        }
        let n = null,
            o, s = (e === _pf_ON_HOVER.ALL_IMAGE ? this.$MasterImg.addEventListener("mousemove", function(e) {
                var t = () => {
                    (o = o || {}).x = e.offsetX, o.y = e.offsetY
                };
                o ? (Math.abs(e.offsetX - o.x) >= a || Math.abs(e.offsetY - o.y) >= a) && (r++, s(), t()) : t()
            }) : this.$MasterImg.addEventListener("mouseenter", () => {
                n = setTimeout(c, 300)
            }), this.$MasterImg.addEventListener("mouseleave", () => {
                "number" == typeof n && (clearTimeout(n), n = null), i && (this.switchImage(this.index, this.active, !1), i = !1)
            }), () => {
                r < 0 ? r = this.itemLength - 1 : r > this.itemLength - 1 && (r = 0), this.switchImage(r, this.active, !1), i = !0
            }),
            c = () => {
                switch (r = this.index, e) {
                    case _pf_ON_HOVER.NEXT_IMAGE:
                        r++;
                        break;
                    case _pf_ON_HOVER.LAST_IMAGE:
                        r--;
                        break;
                    case _pf_ON_HOVER.RANDOM_IMAGE:
                        r = Math.floor(Math.random() * (this.itemLength - 1))
                }
                s()
            }
    }
    handleSwipe() {
        let {
            listLayout: t,
            limit: e
        } = this.setting, a = e[this.device];
        var r = this.$MasterImg;
        let i = 60,
            n = 0,
            o = 0,
            s = !1,
            c, d = _pf_pageflyProducts[this.pId].images,
            l = new _pf_SwipeTransition(this.$master, this.$MasterImg, d[this.index - 1], d[this.index + 1]);
        r.addEventListener("touchstart", e => {
            e.stopPropagation(), !l.swiping && e.changedTouches && (n = e.changedTouches[0].clientX, o = e.changedTouches[0].clientY, l.setSrc(d[this.index - 1], d[this.index + 1]), l.start(), s = !1, c = void 0)
        }, {
            passive: !0
        }), r.addEventListener("touchmove", e => {
            var t, a;
            e.stopPropagation(), e.changedTouches && (s = !0, t = e.changedTouches[0].clientX - n, a = e.changedTouches[0].clientY - o, c || 0 === this.index && 0 < t || this.index === this.itemLength - 1 && t < 0 || 0 == t || (void 0 === (c = void 0 === c && 10 < Math.abs(t) ? !1 : c) && 10 < Math.abs(a) && (c = !0, l.resetStyle()), !1 === c && (e.cancelable && e.preventDefault(), l.move(t))))
        }, {
            passive: !1
        }), r.addEventListener("touchend", e => {
            e.stopPropagation(), s || this.triggerClickAction(), e.changedTouches && (e = e.changedTouches[0].clientX - n, !0 === c || e < i && e > -i || 0 === this.index && 0 < e || this.index === this.itemLength - 1 && e < 0 ? l.reset(!c) : (this.active = this.index, e > i && this.index--, e < -i && this.index++, this.index = this.index < 0 ? 0 : this.index >= this.itemLength ? this.itemLength - 1 : this.index, l.end(0 < e), this.switchImage(this.index, this.active), t === _pf_LIST_LAYOUT.SLIDE && this.handleSlideList(a))), c = void 0
        })
    }
}
_defineProperty(_pf_ProductImage, "selector", {
    box: '[data-pf-type="ProductBox"]',
    master: '[data-pf-type="MasterImage"]',
    list: '[data-pf-type="ProductImageList"]',
    pagination: '[data-pf-type="ProductImagePagination"]',
    item: '[data-pf-type="ImageItem"]',
    nextArrow: '[data-pf-nav="next"]',
    prevArrow: '[data-pf-nav="prev"]'
});
class _pf_SwipeTransition {
    get sign() {
        return this.isNext ? -1 : 1
    }
    constructor(e, t, a, r) {
        _defineProperty(this, "swiping", !1), _defineProperty(this, "isNext", !0), _defineProperty(this, "effect", window.__pf_image_swipeEffect || ""), this.$master = e, this.$MasterImg = t, this.offsetWidth = this.$master.offsetWidth, this.offsetHeight = this.$master.offsetHeight, this.setSrc(a, r)
    }
    setSrc(e, t) {
        this.nextSrc = t, this.prevSrc = e
    }
    start() {
        this.swiping = !0, this.isNext = null, this.$master.style.pointerEvents = "none", this.offsetWidth = this.$master.offsetWidth || this.offsetWidth, this.offsetHeight = this.$master.offsetHeight || this.offsetHeight, this.$Wrapper = document.createElement("div"), this.$Wrapper.style.cssText = `position: absolute; width: ${this.offsetWidth}px; height: ${this.offsetHeight}px; overflow: hidden; pointer-events: none;`, this.$Mask = document.createElement("div"), this.$Mask2 = document.createElement("div"), this.$Mask.id = "mask1", this.$Mask2.id = "mask2", this.$Img = this.$MasterImg.cloneNode(), this.$Img2 = this.$MasterImg.cloneNode(), this.$Img2.src = this.nextSrc, this.$Mask.style.cssText = `position: absolute; width: ${this.offsetWidth}px; height: ${this.offsetHeight}px; display: flex; justify-content: center; align-items: center; overflow: hidden;`, this.$Mask2.style.cssText = `position: absolute; width: ${this.offsetWidth}px; height: ${this.offsetHeight}px; display: flex; justify-content: center; align-items: center; right: -${this.offsetWidth}px; overflow: hidden;`, this.$Mask.appendChild(this.$Img), this.$Mask2.appendChild(this.$Img2), this.$Wrapper.appendChild(this.$Mask), this.$Wrapper.appendChild(this.$Mask2), this.$master.appendChild(this.$Wrapper), this.$MasterImg.style.cssText = "visibility: hidden"
    }
    setDirect(e) {
        var t, a;
        e !== this.isNext && (this.isNext = e, this.$Mask2.style.removeProperty("right"), this.$Mask2.style.removeProperty("left"), this.$Mask2.style.cssText += e ? `right: -${this.offsetWidth}px;` : `left: -${this.offsetWidth}px;`, e = e ? this.nextSrc : this.prevSrc, this.$Img2.src = e, t = this.$Img.src.indexOf("/"), a = this.$Img.src.lastIndexOf("_"), t = this.$Img.src.slice(t, a), a = e.lastIndexOf("."), e = e.slice(0, a), this.$Img2.setAttribute("srcset", this.$Img2.srcset.replaceAll(t, e)))
    }
    moveByEffect(e) {
        var t = window.__pf_image_swipeEffect;
        "slide" === t ? (this.$Img.style.cssText = `transform: translateX(${-e}px);`, this.$Img2.style.cssText = `transform: translateX(${-this.sign*(Math.abs(e)-this.offsetWidth)}px);`) : "carousel" !== t && (this.$Img.style.cssText = `transform: translateX(${-e/2}px);`, this.$Img2.style.cssText = `transform: translateX(${-this.sign*(Math.abs(e/2)-this.offsetWidth/2)}px);`)
    }
    move(e) {
        this.setDirect(e < 0), this.$Mask.style.cssText += `transform: translateX(${e}px);`, this.$Mask2.style.cssText += `transform: translateX(${e}px);`, this.moveByEffect(e)
    }
    get endCSS() {
        let e = `transform: translateX(${-this.sign*this.offsetWidth/2}px);`;
        switch (this.effect) {
            case "slide":
                e = `transform: translateX(${-this.sign*this.offsetWidth}px);`;
                break;
            case "carousel":
                e = ""
        }
        return e
    }
    get resetCSS() {
        let e = `transform: translateX(${this.isNext?"-":""}${this.offsetWidth/2}px);`;
        switch (this.effect) {
            case "slide":
                e = `transform: translateX(${this.sign*this.offsetWidth}px);`;
                break;
            case "carousel":
                e = "transform: translateX(0px);"
        }
        return e
    }
    end(e) {
        this.$Mask.style.cssText += `transition: all ${_pf_SwipeTransition.TIME}s;`, this.$Mask2.style.cssText += `transition: all ${_pf_SwipeTransition.TIME}s;`, this.$Img.style.cssText = `transition: all ${_pf_SwipeTransition.TIME}s;` + this.endCSS, this.$Img2.style.cssText = `transition: all ${_pf_SwipeTransition.TIME}s; transform: translateX(0);`, this.$Mask.style.cssText += `transform: translateX(${e?"":"-"}${this.offsetWidth}px);`, this.$Mask2.style.cssText += `transform: translateX(${e?"":"-"}${this.offsetWidth}px);`, setTimeout(() => {
            this.resetStyle()
        }, 1e3 * _pf_SwipeTransition.TIME)
    }
    resetStyle() {
        this.$MasterImg.style.cssText = "", this.$Wrapper && this.$master.removeChild(this.$Wrapper), this.$master.style.removeProperty("pointer-events"), this.$Wrapper = null, this.swiping = !1
    }
    reset(e = !0) {
        this.$Mask.style.cssText += `transition: all ${_pf_SwipeTransition.TIME}s;`, this.$Mask2.style.cssText += `transition: all ${_pf_SwipeTransition.TIME}s;`, this.$Img.style.cssText = `transition: all ${_pf_SwipeTransition.TIME}s; transform: translateX(0);`, this.$Img2.style.cssText = `transition: all ${_pf_SwipeTransition.TIME}s;` + this.resetCSS, setTimeout(() => {
            this.$Mask.style.cssText += "transform: translateX(0);", this.$Mask2.style.cssText += "transform: translateX(0);", setTimeout(() => {
                e && this.resetStyle()
            }, 1e3 * _pf_SwipeTransition.TIME)
        }, 10)
    }
}
_defineProperty(_pf_SwipeTransition, "TIME", .7);
class _pf_Transform {
    constructor(e, t, a, r = 1) {
        _defineProperty(this, "hiddenList", []), _defineProperty(this, "showList", []), _defineProperty(this, "endCallback", []), _defineProperty(this, "getElCss", (e, t) => {
            var a = this.hiddenList.length;
            let r = "position: absolute;";
            return "h" === this.layout ? r += `${t?"right":"left"}: -${(this.gutter+this.width)*(t?e+1:a-e)}px;` : r += `${t?"bottom":"top"}: -${(this.gutter+this.height)*(t?e+1:a-e)}px;`, r
        }), _defineProperty(this, "getListCss", e => {
            var t = this.hiddenList.length;
            let a = `transition: transform ${this.time}s ease-in-out; pointer-events: none;`;
            return "h" === this.layout ? a += `transform: translateX(${e?"-":""}${(this.width+this.gutter)*t}px); ` : a += `transform: translateY(${e?"-":""}${(this.height+this.gutter)*t}px); `, a
        });
        var i = _pf_getDevice();
        this.$List = e, this.width = a ? .offsetWidth, this.height = a ? .offsetHeight, this.gutter = Number.parseInt(t ? .spacing[i]), this.layout = t ? .listPosition === _pf_LIST_POSITION.TOP || t ? .listPosition === _pf_LIST_POSITION.BOTTOM ? "h" : "v", this.time = r
    }
    reset() {
        this.hiddenList.length = 0, this.showList.length = 0, this.endCallback.forEach(e => "function" == typeof e && e()), this.endCallback.length = 0
    }
    run(a) {
        var e = this.hiddenList.length;
        0 < e && this.showList.length === e && (this.showList.forEach((e, t) => {
            e.removeAttribute("hidden"), e.style.cssText = this.getElCss(t, a)
        }), this.$List.style.cssText = this.getListCss(a), setTimeout(() => {
            this.hiddenList.forEach(e => {
                e.setAttribute("hidden", "hidden")
            }), this.showList.forEach(e => {
                e.style.cssText = ""
            }), this.$List.style.cssText = "", this.reset()
        }, 1e3 * this.time))
    }
}
let _pf_pageflyLivePageRedirect = e => {
        var t = window.Shopify ? .designMode,
            a = (t ? window : window.top).location;
        console.log("PageFly:: redirect data:", {
            url: e,
            isInShopifyThemeEditor: t
        }), a.href = e
    },
    _pf_handleTimberTheme = async () => {
        var e = await window.getCart();
        window.ajaxCart.cartUpdateCallback(e)
    },
    _pf_handleBlumTheme = e => {
        "function" == typeof window.SHTHelper.forceUpdateCartStatus && window.SHTHelper.forceUpdateCartStatus(e)
    },
    _pf_lazyLoad = window.__pagefly_setting ? .imageLazyLoad || !1,
    _pf_ShopifyFormatterPrefix = {
        formatUnit: ({
            value: e,
            unit: t
        }) => options.showUnit ? e + " " + t : e + ".0",
        formatRating: ({
            value: e,
            scale_max: t
        }, a) => a.showMaxScale ? e + "/" + t : e
    },
    _pf_formatShopifyDate = (t, e) => {
        try {
            var a;
            return t ? (a = e.dateFormat, _pf_format(new Date(t), _pf_DATE_FORMATS_METAFIELD[a])) : null
        } catch (e) {
            return console.error("===> Error formatting Shopify date:", e), t
        }
    },
    _pf_formatShopifyDateTime = (i, n) => {
        try {
            var {
                dateFormat: o,
                showDate: s,
                showTime: c,
                timeFormat: d,
                showTimezone: l,
                isViewMode: p
            } = n, _ = new Date(i);
            if (!i) return null;
            let e = "",
                t = "",
                a = "",
                r = (s && (e = p ? o : _pf_DATE_FORMATS_METAFIELD[o]), c && (t = p ? "at " + d : "'at' " + _pf_TIME_FORMATS_METAFIELD[d]), l && (a = p ? "GMT%z" : "'GMT'xx"), _pf_format(_, `${e} ${t} ` + a));
            return r = p ? `${e} ${t} ` + a : r
        } catch (e) {
            return console.error("===> Error formatting Shopify date and time:", i, e), null
        }
    },
    _pf_formatShopifyUrl = (t, e) => {
        try {
            var {
                linkToUrl: a,
                linkText: r
            } = e;
            return a ? `<a href="${t}" target="_blank">${r||t}</a>` : t
        } catch (e) {
            return console.error("===> Error formatting Shopify URL:", e), t
        }
    },
    _pf_formatShopifyBoolean = (e, t) => {
        var {
            trueValText: t,
            falseValText: a
        } = t;
        return e ? t || String(e) : a || String(e)
    },
    _pf_formatShopifyMoney = (t, a) => {
        var {
            amount: t,
            currency_code: r
        } = t || {}, a = (a || {}).showUnit;
        try {
            return (Number(t).toLocaleString("en-US") + " " + (a ? r : "")) ? .replace(/,/g, ".")
        } catch (e) {
            return a ? t + " " + r : t
        }
    },
    _pf_formatShopifyList = (e, t, a) => {
        let {
            currentType: o,
            currentProps: s
        } = a || {}, c = (s || {}).showUnit, d = "";
        try {
            let n = t ? .children ? .[0] ? .className;
            return Array.isArray(e) && e.forEach((e = "") => {
                try {
                    switch (o) {
                        case _pf_TYPE_METAFIELD.LIST_URL_FIELD:
                            d += `<li class='${n}'>${_pf_formatShopifyUrl(e,s)}</li>`;
                            break;
                        case _pf_TYPE_METAFIELD.LIST_RATING_FIELD:
                            d += `<li class='${n}'>${_pf_ShopifyFormatterPrefix.formatRating(e,s)}</li>`;
                            break;
                        case _pf_TYPE_METAFIELD.LIST_DATE_FIELD:
                            d += `<li class='${n}'>${_pf_formatShopifyDate(e,s)}</li>`;
                            break;
                        case _pf_TYPE_METAFIELD.LIST_DATE_TIME_FIELD:
                            d += `<li class='${n}'>${_pf_formatShopifyDateTime(e,s)}</li>`;
                            break;
                        default:
                            var t, a, r, i;
                            "object" == typeof e && ({
                                value: t,
                                unit: a,
                                scale_max: r
                            } = e || {}, i = a || r || "", e = "" + t + (c ? " " + (_pf_UNIT_MAPPING_METAFIELD[i] || i) : ".0")), d += `<li class='${n}'>${e}</li>`
                    }
                } catch (e) {
                    d = ""
                }
            }), d
        } catch (e) {
            return d
        }
    },
    _pf_formatDataVariantMetafields = e => {
        try {
            let t = [];
            let {
                currentType: a,
                currentKey: r,
                currentProps: i
            } = _pf_textToJsonUseVal(e ? .[0]) || {}, n = a;
            var o = a ? .match(_pf_REGEX_CHECK_LAST_WORD_BEFORE_UNDERSCORE);
            return o && (n = o[1]), e.forEach(e => {
                Array.isArray(e) && (e = {
                    currentType: a,
                    currentTypeGuard: n,
                    currentProps: i,
                    currentVariantId: e[1].id,
                    currentKey: r,
                    ...e[0]
                }, t.push(e))
            }), t
        } catch (e) {
            return console.error("===> Error formatDataVariantMetafields:", e), []
        }
    },
    _pf_GROUPTHOUGHT_THEME = ["pipeline", "story"],
    _pf_handleGroupThoughtThemes = async () => {
        window.theme && window.theme ? .info ? .name && _pf_GROUPTHOUGHT_THEME.includes(window.theme ? .info ? .name) && _pf_handleGroupThoughtThemePartner().catch(console.error)
    },
    _pf_handleGroupThoughtThemePartner = async () => {
        var e = await window.getCart();
        document.dispatchEvent(new CustomEvent("theme:cart:change", {
            detail: {
                cart: e
            }
        })), document.querySelector('[data-drawer="drawer-cart"]') ? .dispatchEvent(new CustomEvent("theme:drawer:open"))
    },
    _pf_handleThemeEditions = () => {
        window.Shopify.getCart(e => {
            var t = document.querySelector("[data-header-cart-count]");
            t && (t.innerHTML = `(${e.item_count})`)
        })
    },
    _pf_handleThemeEmpire = () => {
        fetch("/cart.json").then(e => e.json()).then(e => {
            e = new CustomEvent("cartcount:update", {
                detail: e
            });
            window.dispatchEvent(e)
        })
    },
    _pf_handleThemeHandy = () => {},
    _pf_handleThemePacific = () => {
        window.Shopify.getCart(e => {
            window.$(".cart-item-count").html(e.item_count), window.$(".header-tools-cart").addClass("cart-has-content")
        })
    },
    _pf_handleThemeStartup = () => {
        window.Shopify.getCart(e => {
            document.dispatchEvent(new CustomEvent("cart:count", {
                detail: {
                    count: e.item_count
                }
            }))
        })
    },
    _pf_handleThemeAtlantic = () => {},
    _pf_handleThemeLaunch = () => {
        window.Shopify.getCart(t => {
            document.querySelectorAll(".cart-link .cart-count").forEach(e => e.innerHTML = t.item_count), document.querySelectorAll(".header-cart-count").forEach(e => e.classList.add("active"))
        })
    },
    _pf_handleThemeReach = () => {
        window.Shopify.getCart(t => {
            document.querySelectorAll("[data-cart-count]").forEach(e => e.innerHTML = t.item_count)
        })
    },
    _pf_handleThemeGrid = () => {},
    _pf_handleThemeVogue = () => {
        window.Shopify.getCart(t => {
            document.querySelectorAll("[data-cart-count]").forEach(e => e.innerHTML = t.item_count)
        })
    },
    _pf_RED_PLUG_DESIGN_THEME = ["Avenue"],
    _pf_handleRedPlugDesignThemes = async () => {
        window.themeInfo && window.themeInfo ? .name && _pf_RED_PLUG_DESIGN_THEME.includes(window.themeInfo ? .name) && _pf_handleRedPlugDesignTheme().catch(console.error)
    },
    _pf_handleRedPlugDesignTheme = async () => {
        "function" == typeof window.CartDrop && window.CartDrop(!1)
    },
    _pf_handleThemeOfStudioZash = () => {
        var e = __pagefly_helper_store__.lastATCResult,
            t = document.querySelector("cart-notification");
        t.setActiveElement(document.activeElement), t.renderContents(e)
    };

function _pf_convertSchemaToHtml(t, e = !1) {
    let a = "";
    if ("root" === t ? .type && 0 < t ? .children ? .length) a += e ? `
          <div class="${!0===e?"rte":e}">
            ${_pf_convertSchemaToHtml(t.children)}
          </div>
          ` : _pf_convertSchemaToHtml(t.children);
    else
        for (let e = 0; e < t.length; e++) {
            var r = t[e];
            switch (r ? .type) {
                case "paragraph":
                    a += _pf_buildParagraph(r);
                    break;
                case "heading":
                    a += _pf_buildHeading(r);
                    break;
                case "list":
                    a += _pf_buildList(r);
                    break;
                case "list-item":
                    a += _pf_buildListItem(r);
                    break;
                case "link":
                    a += _pf_buildLink(r);
                    break;
                case "text":
                    a += _pf_buildText(r)
            }
        }
    return a
}

function _pf_buildParagraph(e) {
    if (e ? .children) return `<p>${_pf_convertSchemaToHtml(e?.children)}</p>`
}

function _pf_buildHeading(e) {
    if (e ? .children) return `<h${e?.level}>${_pf_convertSchemaToHtml(e?.children)}</h${e?.level}>`
}

function _pf_buildList(e) {
    if (e ? .children) return "ordered" === e ? .listType ? `<ol>${_pf_convertSchemaToHtml(e?.children)}</ol>` : `<ul>${_pf_convertSchemaToHtml(e?.children)}</ul>`
}

function _pf_buildListItem(e) {
    if (e ? .children) return `<li>${_pf_convertSchemaToHtml(e?.children)}</li>`
}

function _pf_buildLink(e) {
    return `<a href="${e?.url}" title="${e?.title}" target="${e?.target}">${_pf_convertSchemaToHtml(e?.children)}</a>`
}

function _pf_buildText(e) {
    return e ? .bold ? `<strong>${e?.value}</strong>` : e ? .italic ? `<em>${e?.value}</em>` : e ? .value
}
async function _pf_DEPRECATED_handleFeaturedProductPrice() {
    let o = window.jQuery;
    o && o('[data-pf-type="Shopify.FeaturedProduct"]').each((e, t) => {
        o(t).find(".product__variants select").on("change", e => {
            var t = o(e.target),
                a = t.closest(".pf-feature-product__infos").find(".pf-fp-pr"),
                t = t.find(":selected"),
                r = t.data("regular"),
                i = t.data("sale"),
                t = t.data("image");
            let n = e.target;
            for (; n && "BODY" !== n.nodeName && !n.querySelector(".pf-c");) n = n.parentNode;
            i && (a.addClass("pf-p-hs"), parseInt(i) !== parseInt(r)) ? a.find(".pf-p-prr").removeClass("hide").html(i) : a.find(".pf-p-prr").addClass("hide"), a.find(".pf-p-prs").html(r), t && n.querySelector(".pf-feature-product__image img") && n.querySelector(".pf-feature-product__image img").setAttribute("src", t)
        })
    })
}
async function _pf_handleDEPRECATEDelements() {
    _pf_DEPRECATED_handleFeaturedProductPrice().catch(console.log)
}
async function _pf_runPaginationHelper() {
    _pf_storeSomeProductElements().catch(console.error), _pf_handleAction().catch(console.error), _pf_handleShopifyProductMedia().catch(console.error), _pf_handleShopifyProductMedia2().catch(console.error), _pf_handleDefaultVariant().catch(console.error), _pf_handleShopifyProductATC().catch(console.error), _pf_handleShopifyProductVariants().catch(console.error), _pf_handleShopifyProductImage().catch(console.error), _pf_handleShopifyProductQuantity().catch(console.error), _pf_handleProductCollectionDescription().catch(console.error), _pf_handleShopifyProductVariantSwatches().catch(console.warn), _pf_handleSPR().catch(console.error), window.__openUrl()
}
async function _pf_handleShopifyProduct() {
    _pf_storeSomeProductElements().catch(console.warn), _pf_handleShopifyProductMedia().catch(console.warn), _pf_handleShopifyProductMedia2().catch(console.warn), _pf_handleDefaultVariant().catch(console.warn), _pf_handleShopifyProductImage().catch(console.warn), _pf_handleShopifyProductBadge().catch(console.warn), _pf_handleShopifyProductVariants().catch(console.warn), _pf_handleShopifyProductATC().catch(console.warn), _pf_handleShopifyProductQuantity().catch(console.warn), _pf_handleProductCollectionDescription().catch(console.warn), _pf_handleShopifyProductList().catch(console.warn), _pf_handleDEPRECATEDelements().catch(console.warn), _pf_handleShopifyProductVariantSwatches().catch(console.warn), _pf_handleShopifyProductDynamicCheckout().catch(console.warn)
}
async function _pf_storeSomeProductElements() {
    var e = document.querySelectorAll('[data-product-type="price"]'),
        t = document.querySelectorAll('[data-product-type="compare_at_price"]'),
        a = [...document.querySelectorAll('[data-pf-type="ProductATC2"]'), ...document.querySelectorAll('[data-pf-type="ProductATC"]')],
        r = document.querySelectorAll('[data-pf-type="ProductMedia"]'),
        i = document.querySelectorAll(_pf_productMediaQueryString);
    _pf_storeElsInProductByType(e, "price"), _pf_storeElsInProductByType(t, "comparePrice"), _pf_storeElsInProductByType(a, "atc"), _pf_storeElsInProductByType(r, "media"), _pf_storeElsInProductByType(i, "media2")
}

function _pf_storeElemInProductByType(e, t) {
    var a, r, i, n = e.getAttribute("data-product-id"),
        n = _pf_pageflyProducts[n];
    n && (n[r = t + "Arr"] = n[r] || new Map, (i = e.closest('[data-pf-type="ProductBox"]')) ? ((a = n[r].get(_pf_getElemIdByClassname(i.className)) || []).push(e), n[r].set(_pf_getElemIdByClassname(i.className), a)) : ((i = n[r].get(_pf_OUTSIDE_BOX_KEY) || []).push(e), n[r].set(_pf_OUTSIDE_BOX_KEY, i)), "atc" === t) && ({
        atcContents: a = new Map
    } = n, r = _pf_getElemIdByClassname(e.className), a.get(r) || (i = e.innerHTML, a.set(r, i), n.atcContents = a))
}
async function _pf_storeElsInProductByType(e, t) {
    e.forEach(e => {
        _pf_storeElemInProductByType(e, t)
    })
}

function _pf_getDefaultRequestConfig() {
    return JSON.parse(JSON.stringify({
        credentials: "same-origin",
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/json;"
        }
    }))
}

function _pf_fetchJSON(e, t) {
    return fetch(e, t).then(e => e.json())
}

function _pf_getCart() {
    return _pf_fetchJSON("/cart.js", _pf_getDefaultRequestConfig())
}

function _pf_cartAdd(e, t, a) {
    var r = _pf_getDefaultRequestConfig();
    return r.method = "POST", r.body = JSON.stringify({
        id: e,
        quantity: t,
        properties: a
    }), _pf_fetchJSON(window.Shopify ? .routes ? .root ? window.Shopify.routes.root + "cart/add.js" : "/cart/add.js", r)
}

function _pf_cartAddFromForm(e) {
    var t = _pf_getDefaultRequestConfig();
    return delete t.headers["Content-Type"], t.method = "POST", t.body = e, _pf_fetchJSON(window.Shopify ? .routes ? .root ? window.Shopify.routes.root + "cart/add.js" : "/cart/add.js", t)
}

function _pf_cartClear() {
    var e = _pf_getDefaultRequestConfig();
    return e.method = "POST", _pf_fetchJSON("/cart/clear.js", e)
}

function _pf_cartUpdate(e) {
    var t = _pf_getDefaultRequestConfig();
    return t.method = "POST", t.body = JSON.stringify(e), _pf_fetchJSON("/cart/update.js", t)
}

function _pf_cartShippingRates() {
    return _pf_fetchJSON("/cart/shipping_rates.json", _pf_getDefaultRequestConfig())
}
async function _pf_createOrderItem(e) {
    try {
        var t = await fetch(_pf_APP_PROXY_URL + "/order-item/create", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e)
        });
        if (!t.ok) throw new Error("Bad response :<");
        var a = await t.json();
        if (!a.success) throw new Error(a.message)
    } catch (e) {
        console.error(e instanceof Error ? e.message : e)
    }
}
async function _pf_onCreateOrderItem(e) {
    let {
        shouldTrackOrder: t,
        pfPageInfo: a,
        atcId: r,
        data: i,
        generatedId: n,
        product: o,
        pageType: s,
        pageId: c,
        collectionsOfProduct: d
    } = e;
    try {
        let e = n;
        if (t && a) {
            var l = await _pf_getCart();
            if (l) {
                var p, _, f, u = l.items,
                    h = u.find(e => e.id === r && !!e.properties["" + _pf_ATC_PF_ANALYTICS_ID]),
                    {
                        pf_page_name: m,
                        pf_page_subject_id: g
                    } = (h && (i[`properties[${_pf_ATC_PF_ANALYTICS_ID}]`] = e = h.properties["" + _pf_ATC_PF_ANALYTICS_ID]), a),
                    y = window.__pagefly_setting__ ? .shopDomain,
                    E = {
                        _id: e,
                        shopDomain: y,
                        properties: {}
                    };
                if (o && ({
                        featured_image: p,
                        title: _
                    } = o, f = {
                        pageType: s,
                        pageId: c,
                        pageName: m,
                        pageSubjectId: g,
                        productPageImage: p,
                        productName: _
                    }, Object.assign(E.properties, f)), d && d instanceof Array) {
                    let r = [];
                    d.forEach(e => {
                        var {
                            id: e,
                            title: t,
                            image: a
                        } = e, a = a ? .src;
                        r.push({
                            collectionId: e,
                            collectionTitle: t,
                            collectionImageSrc: a
                        })
                    }), Object.assign(E.properties, {
                        collectionsOfProduct: r
                    })
                }
                await _pf_createOrderItem(E)
            }
        }
    } catch (e) {
        console.log(e instanceof Error ? e.message : e)
    }
}

function _pf_formcheck(i) {
    console.log("validating...", i);
    var e = window._pagefly_form_fields_selector || '[name][required]:not([hidden]):not([type="file"]):not([type="hidden"])',
        e = i.querySelectorAll(e);
    let n = [];
    return e.forEach((e, t) => {
        if (e.required && !["hidden", "file"].includes(e.type))
            if ("radio" === e.type) {
                let a = !1;
                var r = e.name;
                i.querySelectorAll(`input[name="${r}"]`).forEach((e, t) => {
                    e.value && (a = !0)
                }), a || n.push(e)
            } else e.value || n.push(e)
    }), n
}

function _pf_checkLanguage() {
    var e = __pagefly_helper_store__.cart;
    return e.attributes && e.attributes.ml_lang || window.Shopify.locale
}

function _pf_toFormData(e) {
    let a = new FormData;
    return "function" == typeof a._asNative && (a = a._asNative().fd), Object.entries(e).forEach(([e, t]) => {
        a.append(e, t)
    }), a
}

function _pf_ajaxCartUpdate(e) {
    try {
        __pagefly_helper_store__.cart && (__pagefly_helper_store__.lastATCResult = e, __pagefly_helper_store__.update(e));
        var t, {
            lastATCResult: a,
            autoCartUpdate: r
        } = __pagefly_helper_store__;
        r && a && window.Shopify ? .theme ? .name && (_pf_handlePixelUnionThemes(t = window.__pagefly_theme_atc_check__ || window.Shopify.theme.name), _pf_handleGroupThoughtThemes(), _pf_handleRedPlugDesignThemes(), _pf_handleRoarTheme(t), _pf_handleStudioZashTheme(t), _pf_handleBlumTheme(e), window.timber) && window.ajaxCart ? .cartUpdateCallback && _pf_handleTimberTheme().catch(console.error)
    } catch (e) {
        console.warn(e)
    }
}

function _pf_customDataForTheme() {
    var e = window.__pagefly_theme_atc_check__ || window ? .Shopify ? .theme ? .name;
    switch (!0) {
        case /Cindy|Carla|Claudia/i.test(e):
            return {
                sections: "cart-notification-product,cart-notification-button,cart-icon-bubble"
            };
        case /BeYours/i.test(e):
            return {
                sections: "cart-icon-bubble,mini-cart"
            };
        default:
            return {}
    }
}
async function _pf_handleShopifyProductATC() {
    _pf_DEPRECATED_addToCartHelper().catch(console.log);
    var e = [...document.querySelectorAll('[data-pf-type="ProductATC"]'), ...document.querySelectorAll('[data-pf-type="ProductATC2"]')];
    if (e.length) try {
        fetch("/cart.json").then(e => {
            e.json().then(function(e) {
                __pagefly_helper_store__.cart = e
            })
        }).catch(function(e) {
            console.warn(e)
        })
    } catch (e) {
        console.warn(e)
    }
    document.querySelectorAll('[data-pf-type="ProductText"][data-product-type="compare_at_price"]').forEach((e, t) => {
        var a = e.getAttribute("data-product-id");
        _pf_pageflyProducts[a] && (_pf_pageflyProducts[a].comparePrices = _pf_pageflyProducts[a].comparePrices || [], _pf_pageflyProducts[a].comparePrices.push(e))
    });
    let b = document.createElement("p");
    b.style.color = "red", b.style.marginTop = "15px", e.forEach(w => {
        let I = w.closest("form");
        let {
            iconPos: A = "left"
        } = _pf_getFrontEndSettings(w) || {}, P = w.querySelectorAll('[data-pf-type="Icon"],[data-pf-type="Icon2"]');
        w.addEventListener("click", async t => {
            t.preventDefault(), t.stopPropagation();
            let l = t.currentTarget,
                p = _pf_isTrackingActive() && !window.ReCharge,
                _ = _pf_pfPageSetting.pageId || _pf_pfSetting.pageId,
                f = _pf_pfPageSetting.pageType || _pf_pfSetting.pageType,
                u = l.getAttribute("data-checkout"),
                h = l.getAttribute("data-checkout-link");
            var r = l.getAttribute("data-product-id"),
                m = l.getAttribute("data-adding");
            let g = l.getAttribute("data-added"),
                y = _pf_pageflyProducts[r],
                E = _pf_pageflyProductCollections[r];
            var T = l.closest('[data-pf-type="ProductBox"]'),
                S = T && T.className;
            if (y) {
                let i;
                S = y.pfCurrentVariant && y.pfCurrentVariant[_pf_getElemIdByClassname(S) || _pf_OUTSIDE_BOX_KEY];
                if (!(i = S && S.id ? S.id : l.getAttribute("data-current-variant") ? l.getAttribute("data-current-variant") : y.selected_or_first_available_variant ? .id || y ? .variants[0] ? .id)) return console.warn("Variant have no product!");
                if (I) {
                    if (I.querySelector(".pplr-wrapper")) return I.checkValidity() ? I.submit() : void I.reportValidity();
                    if (window.shopstorm ? .apps ? .productCustomizer) try {
                        if (I.querySelector(".product-customizer-options") && I.querySelector('input[type="file"]')) {
                            window.shopstorm.apps.productCustomizer.addOptionPricingItemToCart(r);
                            var v = document.createElement("input");
                            if (v.type = "hidden", v.name = "id", v.value = i, I.appendChild(v), I.checkValidity()) return I.submit();
                            I.reportValidity()
                        }
                    } catch (t) {
                        console.warn(t)
                    }
                    S = I.querySelector('[data-pf-type="InfiniteProductOption"]');
                    if (S)
                        if (!(window.validate_options && await window.validate_options(r))) return;
                    v = I.querySelector('[data-pf-type="InfiniteOptionsShopPad"]');
                    if (v)
                        if (v.querySelector('[data-uploadery-valid="false"]')) return;
                    if ("__pf_formcheck_callback" in window && "function" == typeof window.__pf_formcheck_callback)
                        if (!window.__pf_formcheck_callback(I)) return;
                    if (!I.checkValidity()) return void I.reportValidity();
                    S = _pf_formcheck(I);
                    if (0 < S.length) {
                        console.warn("missing field", S);
                        let e = document.createElement("a");
                        return e.style.color = "#dc3545", e.textContent = "Please fill all the required fields(*) before Add To Cart!", l.insertAfter(e), void setTimeout(() => e.remove(), 3e3)
                    }
                }
                v = T ? T.querySelector('[data-pf-type="ProductQuantity"] input') : y.quantityArr && y.quantityArr.get(_pf_OUTSIDE_BOX_KEY) && y.quantityArr.get(_pf_OUTSIDE_BOX_KEY)[0].querySelector("input"), S = v && v.value || 1;
                let a, e = {};
                e = _pf_customDataForTheme(), window.__getPFCustomATCData && "function" == typeof window.__getPFCustomATCData && (e = window.__getPFCustomATCData(r));
                T = {
                    quantity: S,
                    id: i,
                    ...e
                };
                let n = window.pfPageInfo,
                    o = _pf_uuid(),
                    s = (_pf_isTrackingActive() && (v = (await _pf_getCart()).items, r = v.find(e => e.id === i && !!e.properties["" + _pf_ATC_PF_ANALYTICS_ID]), T[`properties[${_pf_ATC_PF_ANALYTICS_ID}]`] = r ? r.properties["" + _pf_ATC_PF_ANALYTICS_ID] : o), I ? ("function" == typeof(a = new FormData(I))._asNative && (a = a._asNative().fd), v = (S = I.querySelector('[name="id"]')) && S.value, Number(v) || a.append("id", i), Object.entries(e).forEach(([e, t]) => {
                        a.append(e, t)
                    }), n && p && T[`properties[${_pf_ATC_PF_ANALYTICS_ID}]`] && a.append(`properties[${_pf_ATC_PF_ANALYTICS_ID}]`, T[`properties[${_pf_ATC_PF_ANALYTICS_ID}]`])) : a = _pf_toFormData(T), l.textContent),
                    c = l.children,
                    d = ("ProductATC" === l.dataset.pfType ? Array.from(c).forEach(e => e.style.display = "none") : "ProductATC2" === l.dataset.pfType && (l.textContent = ""), document.createElement("span"));
                if (d.textContent = m, l.append(d), P && P.forEach(e => {
                        "left" === A ? w.prepend(e) : w.append(e)
                    }), l.setAttribute("disabled", "true"), _pf_isTrackingActive()) {
                    let e = "add_to_cart";
                    if ("undefined" != typeof window) {
                        if (!window.gtag) return;
                        window.gtag("event", "pf_add_to_cart", Object.assign({
                            pf_add_to_cart: sessionStorage.getItem(e) ? 0 : 1,
                            send_to: "pagefly",
                            pf_product_id: i,
                            pf_event: "add_to_cart",
                            event_callback: () => {
                                sessionStorage.setItem(e, "true")
                            }
                        }, window.pfPageInfo))
                    }
                }
                return _pf_cartAddFromForm(a).then(async e => {
                    console.log("PF ATC Result: ", e);
                    var {
                        status: t,
                        description: a
                    } = e;
                    if (422 <= t) l.parentElement.append(b), b.textContent = "* " + a;
                    else {
                        d.textContent = g;
                        let t = {
                            shouldTrackOrder: p,
                            pfPageInfo: n,
                            atcId: i,
                            data: e,
                            generatedId: o,
                            product: y,
                            pageType: f,
                            pageId: _,
                            collectionsOfProduct: E
                        };
                        a = new Promise(async e => {
                            await _pf_onCreateOrderItem(t), e("Created order item")
                        });
                        switch (await Promise.race([a, _pf_timeoutPromise()]), console.info("After ATC action: ", u), u) {
                            default:
                                case "same":
                                _pf_ajaxCartUpdate(e);
                            break;
                            case "cart":
                                    console.log("checkout..."),
                                _pf_pageflyLivePageRedirect("/cart");
                                break;
                            case "checkout":
                                    console.log("checkout...");
                                var r = _pf_checkLanguage();_pf_pageflyLivePageRedirect("/checkout" + (r ? "?locale=" + r : ""));
                                break;
                            case "link":
                                    _pf_pageflyLivePageRedirect(h)
                        }
                    }
                    if (setTimeout(() => {
                            d.remove(), "ProductATC" === l.dataset.pfType ? Array.from(c).forEach(e => e.style.display = "inline-block") : "ProductATC2" === l.dataset.pfType && (l.textContent = s), P && P.forEach(e => {
                                "left" === A ? w.prepend(e) : w.append(e)
                            }), l.removeAttribute("disabled"), b.remove()
                        }, t < 300 ? 1e3 : 1500), !(422 <= t)) return e
                }).catch(e => {
                    throw new Error(e)
                })
            }
        })
    })
}
async function _pf_DEPRECATED_addToCartHelper() {
    let s = window.jQuery;
    s && (s('a[data-action="AddToCart"]').length && _pf_getCart().then(e => {
        __pagefly_helper_store__.cart = e
    }), s(document).click(n => {
        if ("AddToCart" === n.target.getAttribute("data-action")) {
            let t = s(n.target),
                a = (n.preventDefault(), n.stopPropagation(), t.data("text")),
                r = t.data("checkout");
            var n = t.siblings('[name="quantity"]'),
                n = n.length ? n.eq(0).val() : 1,
                o = t.data("variation");
            let e;
            e = t.find("span").data("variant");
            n = {
                quantity: n,
                id: e = !o && e ? e : t.closest("form").find("select").val()
            };
            t.addClass("is-loading");
            let i = t.children().eq(0);
            i.addClass("pfa pfa-spinner pfa-spin"), i.text(""), s.ajax({
                type: "POST",
                url: window.Shopify ? .routes ? .root ? window.Shopify ? .routes ? .root + "cart/add.js" : "/cart/add.js",
                dataType: "text json",
                data: n,
                error: e => {
                    422 === e.status && (e = JSON.parse(e.responseText), t.html(`<p>${e.description}</p>`))
                },
                success: e => {
                    i.removeClass("pfa pfa-spinner pfa-spin"), t.removeClass("is-loading"), t.addClass("is-added"), i.text("Added"), _pf_ajaxCartUpdate(e), r ? (async () => {
                        var e = _pf_checkLanguage();
                        window.open(window.location.origin + "/checkout" + (e ? "?locale=" + e : ""), "_self")
                    })() : setTimeout(() => {
                        i.text(a), t.removeClass("is-added")
                    }, 2e3)
                }
            })
        }
    }))
}

function _pf_updateATCTextButtonOnChangeVariant(e, t, a) {
    var r;
    e && a ? .available ? (e.removeAttribute("disabled"), r = _pf_getElemIdByClassname(e.className), t = t.get(r), e.querySelector("span") ? (r = (r = (r = (new DOMParser).parseFromString(`<div>${t}</div>`, "text/xml")) ? .firstElementChild ? .querySelector('[data-pf-type="Text"]') || r ? .firstElementChild) ? r.innerHTML.trim().replace("/>", "></i>") : "Add to Cart", e.querySelector("span").innerHTML = r) : e.innerHTML = t) : e && (e.setAttribute("disabled", "true"), r = window.__pf_unavailable_text || "Unavailable", t = a ? e.getAttribute("data-soldout") || "Sold Out" : r, e.querySelector("span") ? e.querySelector("span").innerHTML = t : e.innerHTML = `<span>${t}</span>`)
}
async function _pf_handleShopifyProductBadge() {
    document.querySelectorAll('[data-pf-type="ProductBadge"]').forEach((e, t) => {
        _pf_storeElemInProductByType(e, "badge");
        var a = e.getAttribute("data-product-id"),
            r = _pf_pageflyProducts[a];
        _pf_isValidCondition(a, _pf_getFrontEndSettings(e)) && e.removeAttribute("hidden"), _pf_updateProductBadgeByVariant([e], r ? .selected_or_first_available_variant), _pf_updateProductBadgeByVariant([e], r ? .selected_or_first_available_variant) && (e.style.display = "none")
    })
}

function _pf_isValidCondition(e, t) {
    var {
        applyCondition: t = !1,
        tags: a = [],
        collectionSource: r = "",
        collectionIds: i = []
    } = t;
    if (!t) return !0;
    t = _pf_pageflyProducts[e].tags;
    let n = a ? .split(",").map(e => e.trim().toLowerCase()).filter(e => "" !== e) || [],
        o = window.__pagefly_product_collections[e].map(e => "" + e.id);
    a = !!t.some(e => n.includes(e.toLowerCase())), e = "custom" === r && !!i.filter(e => o.includes(e)).length, t = "all" === r && o.length === window.__pagefly_collections_count;
    return a || e || t
}

function _pf_updateProductBadgeByVariant(o, s) {
    let e = !1;
    var t, a;
    return o && s && ("number" == typeof(t = (t = window.__pagefly_variant_stock || {})[s.id]) && (a = o[0].querySelector("[data-badge-type='stock']")) && (a.textContent = t), e = (() => {
        let {
            price: e,
            compare_at_price: t
        } = s, a = 0, r = parseFloat(e || "0"), i = parseFloat(t || "0");
        i > r && 0 !== i && (a = 100 - Math.round(r / i * 100));
        var n = o[0].querySelectorAll("[data-badge-type='discount']");
        return !(!n.length || 0 !== a) || (n.forEach(e => {
            e.textContent = 0 < a ? "" + a : ""
        }), !1)
    })()), o ? .length && (o[0].style.display = e ? "none" : "block"), e
}
async function _pf_handleProductCollectionDescription() {
    var e = document.querySelectorAll('[data-pf-type="ProductDescription"][data-product-type="content"]:not([data-loaded-des="true"])'),
        t = document.querySelectorAll('[data-pf-type="CollectionDescription"][data-collection-type="description"]:not([data-loaded-des="true"])'),
        a = document.querySelectorAll('[data-pf-type="ArticleExcerpt"]:not([data-loaded-des="true"])');
    let r = r => {
        var e = r.getAttribute("data-compact");
        r.getAttribute("data-loaded-des") || r.setAttribute("data-loaded-des", "true");
        let i = r.innerHTML.replace(/<meta charset="utf-8"[^>]*>|(<style>((.|\s)*?)<\/style>)|(<script((.|\s)*?)<\/script>)/g, "");
        if (e) {
            var n = r.getAttribute("data-show-button");
            let a = _pf_truncateText(i, parseInt(e), "false" !== n);
            if (a.length < i.length) {
                r.setAttribute("data-collapse", "true");
                let e = r.getAttribute("data-more"),
                    t = (e = e && e.trim() || "More", r.getAttribute("data-less"));
                t = t && t.trim() || "Less", "false" !== n && (a = `${a} <a href="#" class="pf-read-more">${e.replace(/</g,"&lt;").replace(/>/g,"&gt;")}</a>`), r.innerHTML = a, "false" !== n && (r.onmousedown = function(e) {
                    e = e.target.closest(".pf-read-more");
                    e && (e.onclick = function(e) {
                        e.preventDefault(), "true" === r.getAttribute("data-collapse") ? (r.innerHTML = i.concat(` <a href="#" class="pf-read-more">${t.replace(/</g,"&lt;").replace(/>/g,"&gt;")}</a>`), r.setAttribute("data-collapse", "false")) : (r.innerHTML = a, r.setAttribute("data-collapse", "true"))
                    })
                })
            } else r.innerHTML = i
        } else r.innerHTML = i
    };
    Array.from(e).forEach(e => r(e)), Array.from(t).forEach(e => r(e)), Array.from(a).forEach(e => r(e))
}
async function _pf_handleShopifyProductDynamicCheckout() {
    var e = document.querySelectorAll('[data-pf-type="ProductDynamicCheckout"]');
    0 < e.length && e.forEach(e => {
        var t = e.getAttribute("data-value"),
            a = e.querySelector(".shopify-payment-button__button--unbranded"),
            a = (a && (a.innerHTML = t), e.closest('[data-pf-type="ProductBox"]')),
            t = e.querySelector('input[name="id"]');
        1 < a ? .querySelectorAll('[name="id"]').length && t ? .remove()
    })
}

function _pf_getProductBoxId(e) {
    e = e ? .closest('[data-pf-type="ProductBox"]');
    return _pf_getElemIdByClassname(e ? .className)
}

function _pf_storeInstanceInProductByType(e, t) {
    var a, r, i = e.pId,
        i = _pf_pageflyProducts[i];
    i && (t = t + "Instances", a = e.boxId || _pf_OUTSIDE_BOX_KEY, i[t] = i[t] || new Map, (r = i[t].get(a) || []).push(e), i[t].set(a, r))
}

function _pf_initOutSideCurrentVariantFromProductImage(e) {
    var t;
    e.closest('div[data-pf-type="ProductBox"]') || (e = e.getAttribute("data-product-id"), (e = _pf_pageflyProducts[e]) && !e.pfCurrentVariant && e.variants && (t = e.selected_or_first_available_variant || e.variants[0], e.pfCurrentVariant = {}, e.pfCurrentVariant["" + _pf_OUTSIDE_BOX_KEY] = t, _pf_updateOutsideBoxByVariant(e, t, !0)))
}
async function _pf_handleShopifyProductImage() {
    document.querySelectorAll('div[data-pf-type="ProductImage"]').forEach(e => {
        var t;
        e ? .hasAttribute("data-product-id") && (_pf_storeInstanceInProductByType(t = new _pf_ProductImage(e), "image"), _pf_initOutSideCurrentVariantFromProductImage(e), t.run())
    })
}
async function _pf_renderPagination() {
    var e = document.getElementsByClassName("pf-bpa");
    if (!e.length) return null;
    Array.from(e).map(e => _pf_renderPageIndexes(e, 0))
}

function _pf_getPageMap(t, e) {
    var a = [1];
    if (t <= 5)
        for (let e = 2; e <= t; e++) a.push(e);
    else 1 < e - 1 && a.push(e - 1), 1 < e && a.push(e), e + 1 <= t && a.push(e + 1), e + 2 <= t && a.push(t);
    return a
}

function _pf_appendPageIndex(i, n, e) {
    var o = document.createElement("a");
    if (n === e && (o.className += "currentPage"), o.innerText = "" + n, !isNaN(n)) {
        o.href = "#", o.setAttribute("data-order", "" + n);
        let a = i.getAttribute("data-private");
        let t = i.getAttribute("data-next-page").split("page=")[0],
            r = document.querySelectorAll(`[data-private="${a}"]`)[0];
        o.addEventListener("click", e => {
            e.preventDefault(), fetch(t + "page=" + n).then(e => e.text()).then(e => {
                e = (new DOMParser).parseFromString(e, "text/html");
                let t = "";
                e.querySelectorAll(a + " .pf-c").forEach(e => (t += e.outerHTML, e.outerHTML));
                e = document.querySelectorAll("" + a)[0];
                [].slice.call(e.getElementsByClassName("pf-c")).map(e => e.remove()), r.parentElement.insertAdjacentHTML("beforebegin", t)
            }), i.innerHTML = "", _pf_renderPageIndexes(i, n)
        })
    }
    i.appendChild(o)
}

function _pf_renderPageIndexes(t, a = 0) {
    var r = _pf_getPageMap(parseInt(t.getAttribute("data-page")), a = a || parseInt(t.getAttribute("data-current")));
    _pf_appendPageIndex(t, 1, a);
    for (let e = 1; e < r.length; e++) r[e - 1] + 1 < r[e] && _pf_appendPageIndex(t, "...", a), _pf_appendPageIndex(t, r[e], a)
}
async function _pf_handleProductPagination() {
    var e = document.querySelectorAll(".pf-cmIpgn a");
    Array.from(e).forEach(l => {
        l.addEventListener("click", e => {
            e.preventDefault(), l.parentElement.parentElement.classList.add("pf-loading");
            let o = new URL(window.location.href);
            e = new URL(l.href).searchParams.get("page");
            o.searchParams.set("page", e);
            let s = "" + l.parentElement.getAttribute("data-selector"),
                c = "" + l.closest("[data-pf-type]") ? .getAttribute("data-pf-type"),
                d = {
                    scrollY: window.scrollY
                };
            fetch(o.href).then(e => e.text()).then(e => {
                let t = !1;
                l.classList.contains("pf-cmIldm") ? (r = l.getAttribute("data-total"), a = o.searchParams.get("page"), t = !0, r === a ? (c ? .includes("ArticleList") ? l.innerText = "No more post" : l.innerText = "No more product", l.setAttribute("disabled", "disabled")) : (r = parseInt(a) + 1, o.searchParams.set("page", r.toString()), l.href = o.href)) : ([...l.parentElement.children].forEach(e => {
                    e !== l && e.classList.remove("pf-cmIatv")
                }), l.classList.add("pf-cmIatv"));
                var a = document.querySelector(s),
                    r = (new DOMParser).parseFromString(e, "text/html").querySelector(s),
                    e = r.querySelectorAll(":scope > div:not(.pf-cmIpgn)");
                let i = [],
                    n = (e.forEach(e => {
                        e = e.querySelectorAll("script");
                        if (e.length) {
                            let t = document.createElement("script");
                            e.forEach(e => t.innerHTML += e.innerHTML), i.push(t)
                        }
                    }), a.querySelectorAll("script").forEach((e, t) => {
                        i[t] && e.replaceWith(i[t])
                    }), t && l.parentElement.before(...e), Array.from(a.querySelectorAll('[data-pf-type^="ArticleBox"], [data-pf-type^="ProductBox"]')));
                e = Array.from(r.querySelectorAll('[data-pf-type^="ArticleBox"], [data-pf-type^="ProductBox"]'));
                t || _pf_hideElementIfNotFound(n, e), e.forEach((e, t) => n[t].replaceWith(e)), l.parentElement.parentElement.classList.remove("pf-loading"), l.classList.contains("pf-cmIldm") || (r = a.getBoundingClientRect().top - document.body.getBoundingClientRect().top - 100, _pf_smoothScroll(r, 800)), "__pf_loadmore_callback" in window && Array.isArray(window.__pf_loadmore_callback) && window.__pf_loadmore_callback.forEach(e => {
                    "function" == typeof e && e(d)
                }), _pf_runPaginationHelper(), _pf_handleShopifyProductBadge(), window.jdgm ? .customizeBadges && window.jdgm.customizeBadges()
            }).then(() => {
                window.$ ? .aliReviewsAddRatingCollection && window.$.aliReviewsAddRatingCollection(), window.SealSubs ? .refresh && window.SealSubs.refresh(), _pf_reloadLaiElement(), _pf_reloadAreviewsElement(), "function" == typeof window.printReviewRatings && window.printReviewRatings(), window.__handleSideEffectForOtherApp && "function" == typeof window.__handleSideEffectForOtherApp && window.__handleSideEffectForOtherApp()
            }).catch(e => console.log(e))
        })
    })
}
async function _pf_handleShopifyProductList() {
    _pf_renderPagination().catch(console.error), _pf_handleProductPagination().catch(console.error)
}
async function _pf_handleShopifyProductQuantity() {
    await _pf_storeElsInProductByType(document.querySelectorAll('div[data-pf-type="ProductQuantity"]'), "quantity"), setTimeout(() => {
        function t(r) {
            r.forEach(e => {
                let i;
                async function n(a) {
                    i && r.forEach(e => {
                        var t = i.querySelector("input") || e.querySelector("input"),
                            e = i.querySelector("[data-quantity-action='decrease']") || e.querySelector("[data-quantity-action='decrease']");
                        1 === (t.value = a) ? e ? .setAttribute("disabled", "disabled") : e ? .removeAttribute("disabled")
                    })
                }
                var t, a;
                e && (t = e.querySelector("input") ? .value, a = e.querySelector("[data-quantity-action='decrease']"), 1 === Number(t) && a && a.setAttribute("disabled", "disabled"), !e.getAttribute("listener")) && (e.addEventListener("click", function(t) {
                    var a = t.target,
                        r = t.currentTarget;
                    if (i = t.currentTarget, t = a.closest("[data-quantity-action]")) {
                        a = t.getAttribute("data-quantity-action"), t = r.querySelector("input"), r = parseInt(t.value, 10) || 0;
                        let e = "increase" === a ? r + 1 : r - 1;
                        n(e = e < 1 ? 1 : e).catch(console.error)
                    }
                }), e.querySelector("input") ? .addEventListener("blur", function(e) {
                    (e = e.target.closest("input")) && n(parseInt(e.value, 10) || 0).catch(console.error)
                }), e.setAttribute("listener", "true"))
            })
        }
        Object.keys(_pf_pageflyProducts).forEach(e => {
            e && (e = _pf_pageflyProducts[e]) && e.quantityArr && e.quantityArr.forEach(t)
        })
    }, 100)
}
async function _pf_handleShopifyProductRecommendations() {
    let productRecommendationsSections = document.querySelectorAll(".pf-r.pf-r-ew.pf-product-recommendations");
    productRecommendationsSections.length && productRecommendationsSections.forEach(async (productRecommendationsSection, index) => {
        let productId = productRecommendationsSection.getAttribute("data-product-id"),
            res = (window.__pageflyProducts = window.__pageflyProducts || {}, await fetch(productRecommendationsSection.dataset.url)),
            res2 = await fetch("/recommendations/products.json?product_id=" + productId),
            text = await res.text(),
            html = document.createElement("div"),
            res2JSON = (html.innerHTML = text, await res2.json()),
            pf_product = (window.__pageflyProducts = res2JSON.products.reduce((e, t) => ({ ...e,
                [t.id]: t
            }), window.__pageflyProducts), productRecommendationsSection.innerHTML = html.querySelectorAll(".pf-r.pf-r-ew.pf-product-recommendations")[index].innerHTML, document.querySelector(".pf-r.pf-r-ew.pf-product-recommendations")),
            arr_pf_product = pf_product.getElementsByTagName("script");
        for (let i = 0; i < arr_pf_product.length; i++) eval(arr_pf_product[i].innerHTML)
    })
}

function _pf_format(e, t) {
    var a = e => e < 10 ? "0" + e : e;
    let r = {
        yyyy: e.getFullYear(),
        yy: String(e.getFullYear()).slice(-2),
        MM: a(e.getMonth() + 1),
        M: e.getMonth() + 1,
        dd: a(e.getDate()),
        d: e.getDate(),
        HH: a(e.getHours()),
        H: e.getHours(),
        mm: a(e.getMinutes()),
        m: e.getMinutes(),
        ss: a(e.getSeconds()),
        s: e.getSeconds()
    };
    return t.replace(/yyyy|yy|MM|M|dd|d|HH|H|mm|m|ss|s/g, e => r[e])
}

function _pf_formatShopifyListColor(r, e) {
    try {
        let a = document.createElement("div");
        return e.forEach(e => {
            var t = r.childNodes[0].cloneNode(!0);
            t instanceof HTMLElement && (t.style.backgroundColor = e, a.appendChild(t))
        }), a.innerHTML
    } catch (e) {
        return null
    }
}

function _pf_formatMoney(e = "0", t = _pf_pfSetting.moneyFormat) {
    let a = "";
    var r = /\{\{\s*(\w+)\s*}}/;
    if (!t) return e;

    function i(e, t) {
        return void 0 === e ? t : e
    }

    function n(e, t, a, r) {
        return t = i(t, 2), a = i(a, ","), r = i(r, "."), isNaN(e) || null == e ? 0 : (t = (e = (e / 100).toFixed(t)).split("."))[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + a) + (t[1] ? r + t[1] : "")
    }
    switch ("string" == typeof e && (e = e.replace(".", "")), t.match(r)[1]) {
        case "amount":
            a = n(e, 2);
            break;
        case "amount_no_decimals":
            a = n(e, 0);
            break;
        case "amount_with_comma_separator":
            a = n(e, 2, ".", ",");
            break;
        case "amount_no_decimals_with_comma_separator":
            a = n(e, 0, ".", ",");
            break;
        case "amount_with_apostrophe_separator":
            a = n(e, 2, "'", ".");
            break;
        case "amount_with_space_separator":
            a = n(e, 2, " ", ",");
            break;
        case "amount_no_decimals_with_space_separator":
            a = n(e, 0, " ", " ");
            break;
        case "amount_with_period_and_space_separator":
            a = n(e, 2, " ", ".")
    }
    return t.replace(r, a)
}

function _pf_getProductObjectFromProductElement(e) {
    e = parseInt(e.getAttribute("data-product-id"));
    return _pf_pageflyProducts[e] || {}
}
async function _pf_handleShopifyProductVariantSwatches() {
    document.querySelectorAll('div[data-pf-type="ProductVariantSwatches"]').forEach((d, e) => {
        if (!(d.childElementCount <= 1)) {
            _pf_storeElemInProductByType(d, "swatches");
            let t = d.closest('[data-pf-type="ProductBox"]'),
                r = (t || document) ? .querySelectorAll('[data-pf-type="ProductVariantMetafield"]') || [],
                i = t && t.className,
                n = "true" === d.getAttribute("data-combined"),
                o = parseInt(d.getAttribute("data-product-id"));
            var a = _pf_getProductObjectFromProductElement(d);
            let s = a ? .variants || [],
                c = d.querySelectorAll(".pf-option-swatches");
            a = a ? .selected_or_first_available_variant || s[0];
            a && _pf_handleToggleVariantMetafield({ ...a,
                variantProductId: o,
                isOutSideBoxProduct: !t
            }, r), d.addEventListener("change", e => {
                let a;
                if (n)
                    if ("dropdown" === d.getAttribute("data-display")) {
                        let t = e.target;
                        a = s.find(e => e.id.toString() === t.value)
                    } else {
                        let t = e.target;
                        a = s.find(e => e.id.toString() === t.value)
                    }
                else {
                    let t = Array.from(c).map(e => ("dropdown" === e.getAttribute("data-swatch-type") ? e.querySelector("select") : e.querySelector("input:checked")).value).join(" / ");
                    a = s.find(e => e.title === t), _pf_updateByCurrentVariant(o, a, i, !0, !1, e.target)
                }
                a && (_pf_updateByCurrentVariant(o, a, i, !0, !1, e.target), "product" === _pf_getPageTypeFromPFPageSetting() && window.history.replaceState(null, null, a ? .id ? "?variant=" + a.id : ""), _pf_handleToggleVariantMetafield({ ...a,
                    variantProductId: o,
                    isOutSideBoxProduct: !t
                }, r))
            })
        }
    })
}

function _pf_handleToggleVariantMetafield(o, e) {
    let {
        variantProductId: s,
        isOutSideBoxProduct: c
    } = o || {};
    e.forEach(t => {
        if (t) {
            var a = t.querySelector(".variant-metafields"),
                r = t.querySelector('[data-pf-type="VariantMetafieldValue"]'),
                i = t.getAttribute("data-product-id");
            if (r && (!c || Number(i) === Number(s))) {
                var i = (_pf_formatDataVariantMetafields(_pf_textToJsonUseVal(a ? .textContent)) || []).find(e => e.currentVariantId === o ? .id) || {},
                    a = i.currentKey,
                    a = i ? .[a],
                    a = "string" == typeof a ? a.trim().replace(/\n/g, "<br>") : a,
                    n = !_pf_VALUE_NOT_SATISFY_METAFIELD.includes(a),
                    t = (t.style.cssText = n ? "" : "visibility: hidden; position: absolute;", i ? .currentType ? .startsWith("list."));
                let e = t ? r ? .childNodes ? .[0] : r;
                e || (e = document.createElement("div"), r.appendChild(e)), n && _pf_updateBoxValueVariantMetafield(i, r, e, a)
            }
        }
    })
}

function _pf_updateBoxValueVariantMetafield(e, t, a, r) {
    var {
        currentType: i,
        currentProps: n
    } = e || {};
    switch (i) {
        case _pf_TYPE_METAFIELD.COLOR_FIELD:
            t.style.setProperty("--color", r);
            break;
        case _pf_TYPE_METAFIELD.LIST_COLOR_FIELD:
            a.innerHTML = _pf_formatShopifyListColor(a, r);
            break;
        case _pf_TYPE_METAFIELD.DATE_TIME_FIELD:
        case _pf_TYPE_METAFIELD.DATE_FIELD:
            var o = (i === _pf_TYPE_METAFIELD.DATE_TIME_FIELD ? _pf_formatShopifyDateTime : _pf_formatShopifyDate)(r, n);
            a.innerHTML = o;
            break;
        case _pf_TYPE_METAFIELD.NUMBER_INTEGER_FIELD:
        case _pf_TYPE_METAFIELD.NUMBER_DECIMAL_FIELD:
            a.innerHTML = parseInt(r).toLocaleString("en-US");
            break;
        case _pf_TYPE_METAFIELD.WEIGHT_FIELD:
        case _pf_TYPE_METAFIELD.DIMENSION_FIELD:
        case _pf_TYPE_METAFIELD.VOLUME_FIELD:
            a.innerHTML = _pf_ShopifyFormatterPrefix.formatUnit(r, n);
            break;
        case _pf_TYPE_METAFIELD.MULTI_LINE_TEXT_FIELD:
        case _pf_TYPE_METAFIELD.SINGLE_LINE_TEXT_FIELD:
            a.innerHTML = r;
            break;
        case _pf_TYPE_METAFIELD.BOOLEAN_FIELD:
            a.innerHTML = _pf_formatShopifyBoolean(r, n);
            break;
        case _pf_TYPE_METAFIELD.RATING_FIELD:
            a.innerHTML = _pf_ShopifyFormatterPrefix.formatRating(r, n);
            break;
        case _pf_TYPE_METAFIELD.URL_FIELD:
            a.outerHTML = _pf_formatShopifyUrl(r, n);
            break;
        case _pf_TYPE_METAFIELD.MONEY_FIELD:
            a.innerHTML = _pf_formatShopifyMoney(r, n);
            break;
        case _pf_TYPE_METAFIELD.LIST_DATE_TIME_FIELD:
        case _pf_TYPE_METAFIELD.LIST_DATE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_NUMBER_INTEGER_FIELD:
        case _pf_TYPE_METAFIELD.LIST_NUMBER_DECIMAL_FIELD:
        case _pf_TYPE_METAFIELD.LIST_VARIANT_REFERENCE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_PRODUCT_REFERENCE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_FILE_REFERENCE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_PAGE_REFERENCE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_IMAGE_REFERENCE_FIELD:
        case _pf_TYPE_METAFIELD.LIST_META_OBJECT_FIELD:
        case _pf_TYPE_METAFIELD.LIST_WEIGHT_FIELD:
        case _pf_TYPE_METAFIELD.LIST_VOLUME_FIELD:
        case _pf_TYPE_METAFIELD.LIST_RATING_FIELD:
        case _pf_TYPE_METAFIELD.LIST_DIMENSION_FIELD:
        case _pf_TYPE_METAFIELD.LIST_SINGLE_LINE_TEXT_FIELD:
        case _pf_TYPE_METAFIELD.LIST_URL_FIELD:
            t.innerHTML = _pf_formatShopifyList(r, t, {
                currentType: i,
                currentProps: n
            });
            break;
        default:
            a.innerHTML = _pf_convertSchemaToHtml(r)
    }
}

function _pf_updateOneSwatchesByValue(i, e, n = []) {
    var t = "true" === i.getAttribute("data-combined");
    let o = i.getAttribute("data-sw-id"),
        s = i.getAttribute("data-product-id");
    t ? "dropdown" === i.getAttribute("data-display") ? (t = i ? .querySelector('select:not([name="id"])')) && t.value !== e.id ? .toString() && (t.value = e.id) : (t = i.querySelector(`input[type='radio'][value*='${e.id}']`)) && !t.checked && (t.checked = !0) : e.options.forEach((e, t) => {
        var a, r = i.querySelector(`[data-unique-id="${t+1}"].pf-option-swatches`);
        "dropdown" === r ? .getAttribute("data-swatch-type") ? (a = r ? .querySelector(`select>option[value='${e.replace(/\'/g,"\\'")}']`)).selected || (a.selected = !0) : (a = n[t], t = `pf-${o}-${a}-${e.replace(/\"/g,"").replaceAll(" ","-")}-` + s, (a = r ? .querySelector(`input[id*='${t.replace(/\'/g,"\\'")}']`)) && !a.checked && (a.checked = !0))
    });
    t = i.querySelector("input[type='hidden'][name='id']");
    t.value !== e.id ? .toString() && (t.value = e.id)
}

function _pf_getCurrentSelectedVariantFromSelectDropDown(e, t) {
    let a = [],
        r = (e.forEach((e, t) => {
            a.push(e.querySelector("option:checked").value)
        }), a.join(" / "));
    return t.find(e => r === e.title) || t.find(e => -1 < r.indexOf(e.title))
}

function _pf_updateOneVariantByValue(r, i, e = []) {
    var t, a = r.getAttribute("data-display");
    !0 == ("true" === r.getAttribute("data-combined")) ? (t = r ? .querySelector("select")) && t.value !== i.id ? .toString() && (t.value = i.id) : "dropdown" === a ? e.forEach((e, a) => {
        (r ? .querySelectorAll(`select[data-key="${e}"]`)) ? .forEach((e, t) => {
            e.value = "" + i["option" + (a + 1)]
        })
    }) : "radio" === a && e.forEach((e, a) => {
        var t = r.querySelectorAll(".pf-c[data-unique-id]")[a] ? .getAttribute("data-unique-id") || 0 + a;
        (r ? .querySelectorAll(`input[name="pf-v-${e}${t}"]`)) ? .forEach((e, t) => {
            e.value !== i["option" + (a + 1)] || e.checked || (e.checked = !0, e.setAttribute("checked", "checked"))
        })
    })
}

function _pf_handleBackInStockBySureSwiftAfterSelectVariant(t) {
    var e, a = window.__pageflyProducts,
        r = document.querySelector('[data-pf-type="BackInStock"]');
    null !== r && (a = a[r.closest("form").getAttribute("data-productid")] ? .quantity.find(e => e.includes(t ? .id)), a = t && a.split(t.id + ":")[1], e = window.BISConfig ? .instock_qty_level, !t ? .available || a < e ? r.style.display = "block" : r.style.display = "none")
}
async function _pf_handleShopifyProductVariants() {
    var e = document.querySelectorAll('div[data-pf-type="ProductVariant"]');
    let p = 0;
    e.forEach((t, e) => {
        _pf_storeElemInProductByType(t, "variant");
        var a = t,
            i = a.closest('[data-pf-type="ProductBox"]');
        let o = i && i.className,
            s = parseInt(a.getAttribute("data-product-id"));
        var r = "true" === a.getAttribute("data-combined"),
            c = a.getAttribute("data-display");
        let d = "true" === a.getAttribute("data-label");
        var l = _pf_pageflyProducts[s],
            n = 1 === l ? .variants ? .length && "Default Title" === l ? .variants[0] ? .title;
        if (!i && l && ((i = l.variantEls || []).push(t), l.variantEls = i), l ? .variants ? .length < 1 || n) a.style.display = "none";
        else if (l && l.options) {
            let {
                variants: n,
                options: e
            } = l;
            i = e.map((e, t) => {
                let a = n.map(e => e["option" + (t + 1)]);
                return {
                    key: e,
                    value: a.filter((e, t) => a.indexOf(e) === t)
                }
            });
            if (!0 != r) {
                if (null === t.querySelector(".pf-c"))
                    if ("dropdown" === c) {
                        t.innerHTML = t.innerHTML + i.map(e => `<div class="pf-c">
											${d?`<label class="pf-variant-label">${e.key}</label>`:""}
											<select class="pf-variant-select" data-key="${e.key}">
												${e.value.map(e=>`<option value="${e.replace(/"/g,"&quot;")}">${e}</option>`).join("")}
											</select>
								</div>`).join("");
                        let a = t.querySelectorAll("select");
                        a.forEach(e => {
                            e.addEventListener("change", () => {
                                var e = _pf_getCurrentSelectedVariantFromSelectDropDown(a, n),
                                    t = (_pf_updateByCurrentVariant(s, e, o), e && (_pf_handlePushOwlBackInStock(e.id), _pf_handleBackInStockBySureSwiftAfterSelectVariant(e), _pf_handlePushOwlPriceDrop(e.id)), _pf_getPageTypeFromPFPageSetting());
                                "product" === t && window.history.replaceState(null, null, e ? .id ? "?variant=" + e.id : "")
                            })
                        })
                    } else if ("radio" === c) {
                    t.innerHTML = t.innerHTML + i.map((r, i) => `<div class="pf-c" data-unique-id="${++p}">
									${d?`<label class="pf-variant-label">${r.key}</label>`:""}
									<div class="pf-variant-radio">
										${r.value.map((e,t)=>{var a=`pf-v-${(""+s).toLowerCase()}-`+i+t+p;return`<div>
										<input ${0===t?"checked":""}
														type="radio"
														id="${a}" name="pf-v-${r.key+p}" value="${e.replace(/"/g,"&quot;")}"/>
										<label style="margin-left:8px" for="${a}">${e}</label>
									</div>`}).join("")}</div>
						</div>`).join("");
                    let r = t.querySelectorAll(".pf-variant-radio:not(input)");
                    [...r].map((e, t) => [...e.querySelectorAll("input")]).reduce((e, t) => e.concat(t)).forEach(e => {
                        e.addEventListener("change", e => {
                            e.preventDefault();
                            var e = (() => {
                                    let a = [],
                                        t = (r.forEach((e, t) => {
                                            a.push(e.querySelector("input:checked").value)
                                        }), a.join(" / "));
                                    return n.find(e => e.title === t)
                                })(),
                                t = (_pf_updateByCurrentVariant(s, e, o), e && (_pf_handlePushOwlBackInStock(e.id), _pf_handleBackInStockBySureSwiftAfterSelectVariant(e), _pf_handlePushOwlPriceDrop(e.id)), _pf_getPageTypeFromPFPageSetting());
                            "product" === t && window.history.replaceState(null, null, e ? .id ? "?variant=" + e.id : "")
                        })
                    })
                }
            } else t.querySelectorAll("select").forEach(i => {
                i.addEventListener("change", e => {
                    let t = i.querySelector("option:checked").value;
                    var a = n.find(e => e.id.toString() === t),
                        r = (_pf_updateByCurrentVariant(s, a, o), a && (_pf_handlePushOwlBackInStock(a.id), _pf_handleBackInStockBySureSwiftAfterSelectVariant(a), _pf_handlePushOwlPriceDrop(a.id)), _pf_getPageTypeFromPFPageSetting());
                    "product" === r && window.history.replaceState(null, null, a ? .id ? "?variant=" + a.id : "")
                })
            })
        }
    })
}

function _pf_getDefaultVariant(e) {
    var t = e.querySelector('[data-pf-type="ProductMedia"]'),
        a = e.querySelector(_pf_productMediaQueryString),
        r = e.querySelectorAll('[data-pf-type="ProductMedia"]'),
        i = e.querySelectorAll(_pf_productMediaQueryString);
    let n;
    t && (t = _pf_getFrontEndSettings(t), n = t ? .imageSource || "featured"), a && (t = _pf_getFrontEndSettings(a), n = t ? .imageSource || "featured");
    let o, s = parseInt(e.getAttribute("data-default-variant"));
    "product" === _pf_getPageTypeFromPFPageSetting() && (a = _pf_variantIdByURL()) && (o = a);
    t = e.getAttribute("data-product-id"), a = _pf_pageflyProducts[t];
    if (a ? .variants) {
        e = a.selected_or_first_available_variant || a.variants[0], t = a.variants.find(e => e.id === s) || e;
        if (o) {
            e = a.variants.find(e => e.id === o);
            if (e) return {
                variant: e,
                changeMasterImg: !0
            }
        }
        if (t) return 1 < r.length ? (r.forEach(e => {
            "default-variant" !== _pf_getFrontEndSettings(e) ? .imageSource && e.setAttribute("data-not-default-variant", "true")
        }), {
            variant: t,
            changeMasterImage: !0
        }) : 1 < i.length ? (i.forEach(e => {
            "default-variant" !== _pf_getFrontEndSettings(e) ? .imageSource && e.setAttribute("data-not-default-variant", "true")
        }), {
            variant: t,
            changeMasterImage: !0
        }) : {
            variant: t,
            changeMasterImg: "default-variant" === n
        }
    }
    return {
        variant: null,
        changeMasterImg: !1
    }
}
async function _pf_handleDefaultVariant() {
    setTimeout(() => {
        document.querySelectorAll('div[data-pf-type="ProductBox"]').forEach((e, t) => {
            var a = e.className,
                r = e.getAttribute("data-product-id"),
                {
                    variant: i,
                    changeMasterImg: n
                } = _pf_getDefaultVariant(e);
            e.querySelectorAll('[data-pf-type="MainMedia"] [data-splide]') ? .forEach(e => {
                e ? .closest("." + _pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE) && e ? .setAttribute("data-no-move-again", "true")
            }), i && _pf_updateByCurrentVariant(r, i, a, n, !0, e)
        })
    }, 100)
}

function _pf_updateOutsideBoxByVariant(t, a, e = !1, r) {
    (t.pfCurrentVariant["" + _pf_OUTSIDE_BOX_KEY] = a) && (t.variantEls && t.variantEls.forEach(e => {
        _pf_updateOneVariantByValue(e, a, t.options)
    }), (t.swatchesArr && t.swatchesArr.get(_pf_OUTSIDE_BOX_KEY)) ? .forEach(e => _pf_updateOneSwatchesByValue(e, a, t.options)), t.priceArr && t.priceArr.get(_pf_OUTSIDE_BOX_KEY) && t.priceArr.get(_pf_OUTSIDE_BOX_KEY).forEach(e => {
        "number" == typeof a.price && (e.innerHTML = _pf_formatMoney(a.price))
    }), t.comparePriceArr && t.comparePriceArr.get(_pf_OUTSIDE_BOX_KEY) && t.comparePriceArr.get(_pf_OUTSIDE_BOX_KEY).forEach(e => {
        e.innerHTML = a.compare_at_price ? _pf_formatMoney(a.compare_at_price) : ""
    }), t.quantityArr && t.quantityArr.get(_pf_OUTSIDE_BOX_KEY) && t.quantityArr.get(_pf_OUTSIDE_BOX_KEY).forEach(e => {
        var t, e = e.querySelector('[data-pf-type="QuantityField"]');
        e && (t = (e ? .getAttribute("data-variants-continue")).includes("" + a.id), r && parseInt(r) <= 0 && a.available || t ? e ? .removeAttribute("max") : e ? .setAttribute("max", r || "999"))
    }), _pf_updateProductMediaOutsideBox(t ? .mediaArr ? .get(_pf_OUTSIDE_BOX_KEY), a), _pf_updateProductMediaOutsideBox2(t ? .mediaArr ? .get(_pf_OUTSIDE_BOX_KEY), a), _pf_updateProductBadgeByVariant(t ? .badgeArr ? .get(_pf_OUTSIDE_BOX_KEY), a), e || t ? .imageInstances ? .get(_pf_OUTSIDE_BOX_KEY) ? .forEach(e => e.updateByVariant(a)));
    let i = t.atcContents;
    t.atcArr && t.atcArr.get(_pf_OUTSIDE_BOX_KEY) && t.atcArr.get(_pf_OUTSIDE_BOX_KEY).filter(e => !!e).forEach(e => {
        _pf_updateATCTextButtonOnChangeVariant(e, i, a)
    })
}

function _pf_updateByCurrentVariant(i, n, e, o = !0, s = !1, c = null) {
    let d;
    d = c ? c.closest(`[data-product-id="${i}"][data-pf-type="ProductBox"]`) : e && document.querySelectorAll(`[data-product-id="${i}"].` + e.trim().replace(/\s/g, "."))[0];
    c = _pf_pageflyProducts[i];
    if (c && c.variants) {
        var l = _pf_pageflyProducts[i] ? .quantity.find(e => e.includes(n ? .id));
        _pf_handleBackInStockBySureSwiftAfterSelectVariant(n);
        let r = n && l.split(n.id + ":")[1];
        if (_pf___pagefly_product_store_data__.update({
                productId: i,
                variant: n
            }), c.pfCurrentVariant || (c.pfCurrentVariant = {}), setTimeout(() => {
                window.BOLD ? .subscriptions && window.BOLD ? .BsubWidget ? .products && window.BOLD.BsubWidget._renderPrices()
            }, 500), (d ? .querySelectorAll(".pf-variant-" + i)) ? .forEach(e => e.value = n ? .id), e) {
            l = _pf_getElemIdByClassname(e);
            c.pfCurrentVariant[l] = n;
            let t = c.options;
            var p, e = () => {
                    n && ((d ? .querySelectorAll('[data-product-type="price"]')) ? .forEach(e => {
                        n && "number" == typeof n.price && (e.innerHTML = _pf_formatMoney(n.price))
                    }), (d ? .querySelectorAll('[data-product-type="compare_at_price"]')) ? .forEach(e => {
                        n && (e.innerHTML = n.compare_at_price ? _pf_formatMoney(n.compare_at_price) : "")
                    }))
                },
                _ = () => {
                    var e = d ? .querySelectorAll('[data-pf-type="QuantityField"]');
                    n && _pf_pageflyProducts[i] ? .quantity && e && e ? .forEach(e => {
                        var t = e.getAttribute("data-variants-continue").includes("" + n.id);
                        e && parseInt(r) <= 0 && n.available || t ? e.removeAttribute("max") : e.setAttribute("max", r)
                    })
                },
                o = (o && n && n.id ? (o = d ? .querySelectorAll(`[data-product-id="${i}"][data-pf-type="ProductImage"]`), f = d ? .querySelectorAll(`[data-product-id="${i}"][data-pf-type="ProductMedia"]`), p = d ? .querySelectorAll(`[data-product-id="${i}"][data-pf-type="ProductMedia2"], [data-product-id="${i}"][data-pf-type="ProductMedia3"]`), o ? .length ? (o = n.featured_image, o && (console.log(c ? .imageInstances), c ? .imageInstances ? .get(l) ? .forEach(e => e ? .updateByVariant(n)))) : f ? .length ? f.forEach(e => {
                    var t = _pf_getProductMediaId(e);
                    e.getAttribute("data-not-default-variant") || _pf_updateImageByVariant(t, n), e.removeAttribute("data-not-default-variant")
                }) : p ? .length && p.forEach(e => {
                    var t = _pf_getProductMediaId2(e);
                    e.getAttribute("data-not-default-variant") || _pf_updateImageByVariant2(t, n), e.removeAttribute("data-not-default-variant")
                }), e(), _()) : s && (e(), _()), c ? .badgeArr ? .get(l)),
                f = (_pf_updateProductBadgeByVariant(o, n), [...d ? .querySelectorAll('[data-pf-type="ProductATC"]'), ...d ? .querySelectorAll('[data-pf-type="ProductATC2"]')]);
            let a = _pf_pageflyProducts[i].atcContents;
            f ? .forEach(e => {
                _pf_updateATCTextButtonOnChangeVariant(e, a, n)
            }), n && ((c ? .variantArr ? .get(l)) ? .forEach(e => {
                _pf_updateOneVariantByValue(e, n, t)
            }), p = d ? .querySelector(`[data-product-id="${i}"][data-pf-type="ProductVariantSwatches"]`)) && _pf_updateOneSwatchesByValue(p, n, t)
        } else _pf_updateOutsideBoxByVariant(c, n, !1, r)
    }
}

function _pf_variantIdByURL() {
    var e = window.location.href,
        e = new URLSearchParams(e.split("?")[1]).get("variant");
    return e ? parseInt(e) : null
}

function _pf_handlePixelUnionThemes(e) {
    switch (!0) {
        case /Editions/i.test(e):
            _pf_handleThemeEditions();
            break;
        case /Empire/i.test(e):
            _pf_handleThemeEmpire();
            break;
        case /Handy/i.test(e):
            _pf_handleThemeHandy();
            break;
        case /Pacific/i.test(e):
            _pf_handleThemePacific();
            break;
        case /Startup/i.test(e):
            _pf_handleThemeStartup();
            break;
        case /Atlantic/i.test(e):
            _pf_handleThemeAtlantic();
            break;
        case /Launch/i.test(e):
            _pf_handleThemeLaunch();
            break;
        case /Reach/i.test(e):
            _pf_handleThemeReach();
            break;
        case /Grid/i.test(e):
            _pf_handleThemeGrid();
            break;
        case /Vogue/i.test(e):
            _pf_handleThemeVogue()
    }
}

function _pf_handleRoarTheme(e) {
    var t = __pagefly_helper_store__.lastATCResult;
    window.Fastor ? .setupCartPopup ? _pf_handleThemeFastor(t) : /BeYours/i.test(e) && _pf_handleThemeBeYours(t)
}

function _pf_handleThemeFastor(e) {
    window.Fastor.setupCartPopup(e)
}

function _pf_handleThemeBeYours(e) {
    document.querySelector("mini-cart").renderContents(e)
}

function _pf_handleStudioZashTheme(e) {
    switch (!0) {
        case /Cindy/i.test(e):
        case /Carla/i.test(e):
        case /Claudia/i.test(e):
            _pf_handleThemeOfStudioZash()
    }
}

function _pf_reloadAreviewsElement() {
    0 < document.querySelectorAll(".areviews_product_item").length && "function" == typeof window.show_infiniti_areviews && window.show_infiniti_areviews()
}

function _pf_handleBackInStockBySureSwift(t) {
    var e, a = window.__pageflyProducts,
        r = document.querySelector('[data-pf-type="BackInStock"]');
    null !== r && (a = a[r.closest("form").getAttribute("data-productid")] ? .quantity.find(e => e.includes(t ? .id)), a = t && a.split(t.id + ":")[1], e = window.BISConfig ? .instock_qty_level, !t ? .available || a < e ? r.style.display = "block" : r.style.display = "none")
}

function _pf_reloadLaiElement() {
    if (void 0 !== window.SMARTIFYAPPS && window.SMARTIFYAPPS.rv.installed) return window.SMARTIFYAPPS.rv.scmReviewsRate.actionCreateReviews()
}

function _pf_setButtonText(e, t) {
    e.innerText = t
}

function _pf_handlePushOwlBackInStock(t) {
    window.pushowl.push(() => {
        window.pushowl.isProductVariantSubscribed("back_in_stock", "")
    });
    var e = document.querySelectorAll('[data-pf-type="PushOwl"].js-pushowl--bis');
    if (0 < e.length) {
        let a = {};
        var r = e[0].getAttribute("data-product-id"),
            r = _pf_pageflyProducts[r];
        a = t && (r.variants.find(e => e.id === t) || r.selected_or_first_available_variant) || r.variants[0], console.log(a), e.forEach(e => {
            var t = _pf_getFrontEndSettings(e);
            a.available ? (console.log("hide bis", e), e.style.display = "none") : window.pushowl.isProductVariantSubscribed("back_in_stock", a.id) ? "none" === t.postDisplay ? e.style.display = "none" : (_pf_setButtonText(e, t.postSubscriptionText), e.style.display = t.postDisplay) : (console.log("show bis"), _pf_setButtonText(e, t.btnText), e.style.display = t.preDisplay)
        })
    }
}

function _pf_handlePushOwlPriceDrop(t) {
    var e = document.querySelectorAll('[data-pf-type="PushOwl"].js-pushowl--pd');
    if (0 < e.length) {
        let a = {};
        var r = e[0].getAttribute("data-product-id"),
            r = _pf_pageflyProducts[r];
        a = t && (r.variants.find(e => e.id === t) || r.selected_or_first_available_variant) || r.variants[0], e.forEach(e => {
            var t = _pf_getFrontEndSettings(e);
            window.pushowl.isProductVariantSubscribed("price_drop", a.id) ? "none" === t.postDisplay ? e.style.display = "none" : (_pf_setButtonText(e, t.postSubscriptionText), e.style.display = t.postDisplay) : (_pf_setButtonText(e, t.btnText), e.style.display = t.preDisplay)
        })
    }
}
async function _pf_handleSPR() {
    var e = window.SPR;
    e && (e.registerCallbacks(), e.initRatingHandler(), e.initDomEls(), e.loadProducts(), e.loadBadges())
}
_pf_handleShopifyProduct(), window.__pagefly__.pageflyLivePageRedirect = _pf_pageflyLivePageRedirect, window.pushowl = window.pushowl || [];