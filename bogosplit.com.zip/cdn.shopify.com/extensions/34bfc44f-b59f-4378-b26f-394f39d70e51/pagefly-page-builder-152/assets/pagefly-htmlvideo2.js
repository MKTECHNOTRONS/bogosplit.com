class _pf_HTMLVideoHandler extends _pf_BaseElementLazyLoader {
    constructor({
        optionsObserver: e,
        ...t
    }) {
        super(e), Object.assign(this, t), this.init()
    }
    init() {
        this.container = document.querySelectorAll(this.selector), this.container.length && _pf_executeChunk(this.container, this.handleElement.bind(this))
    }
    handleElement(e) {
        let t = "video" === e ? .tagName ? .toLowerCase() ? e : e.querySelector("video");
        t && ("lazy" === t.getAttribute("data-lazyloading") ? this.observerElement(() => this.loadVideo({
            element: e,
            video: t
        }), e) : this.loadVideo({
            element: e,
            video: t
        }))
    }
    addEvent({
        element: e,
        type: t,
        callback: i,
        options: a = !1
    }) {
        e.addEventListener(t, i, a)
    }
    loadVideo({
        element: e,
        video: t
    }) {
        let i = e.querySelector(".pf-video-cover-button"),
            a = e.querySelector(".pf-play-button");
        var l = t.hasAttribute("autoplay");
        let s = t.hasAttribute("controls");
        var o = t.hasAttribute("muted");
        i && !l || this.setProp(t) && this.removeProp(t);
        let d = e => e.classList.add("pf-visibility-hidden"),
            n = e => e.classList ? .remove("pf-visibility-hidden");
        this.addEvent({
            element: t,
            type: "loadeddata",
            callback: () => t && n(t)
        }), this.addEvent({
            element: e,
            type: "click",
            callback: e => {
                t.getAttribute("src") || this.setProp(t) && this.removeProp(t), i && !i.classList.contains("pf-visibility-hidden") ? (t.play(), d(i)) : s || (t.paused ? t.play() : t.pause())
            }
        }), this.addEvent({
            element: t,
            type: "pause",
            callback: () => a && n(a)
        }), this.addEvent({
            element: t,
            type: "play",
            callback: () => a && d(a)
        }), l && o && (i && d(i), a && d(a), t.play())
    }
}
let _pf_handleHTMLVideo2 = async () => {
    new _pf_HTMLVideoHandler({
        optionsObserver: {
            threshold: .3
        },
        selector: '[data-pf-type="HTML.Video2"], [data-pf-type="HTML.Video3"], .pf-media-bg-video'
    })
};
_pf_handleHTMLVideo2().catch(console.error);