(e => {
    "function" == typeof define && define.amd ? define(e) : "object" == typeof exports ? module.exports = e() : e()
})(function() {
    var a = "undefined" != typeof window ? window : this,
        e = a.Glider = function(e, t) {
            var i = this;
            if (e._glider) return e._glider;
            if (i.ele = e, i.ele.classList.add("glider"), (i.ele._glider = i).opt = Object.assign({}, {
                    slidesToScroll: 1,
                    slidesToShow: 1,
                    resizeLock: !0,
                    duration: .5,
                    easing: function(e, t, i, o, r) {
                        return o * (t /= r) * t + i
                    }
                }, t), i.animate_id = i.page = i.slide = 0, i.arrows = {}, i._opt = i.opt, i.opt.skipTrack) i.track = i.ele.children[0];
            else
                for (i.track = document.createElement("div"), i.ele.appendChild(i.track); 1 !== i.ele.children.length;) i.track.appendChild(i.ele.children[0]);
            i.track.classList.add("glider-track"), i.init(), i.resize = i.init.bind(i, !0), i.event(i.ele, "add", {
                scroll: i.updateControls.bind(i)
            }), i.event(a, "add", {
                resize: i.resize
            })
        },
        t = e.prototype;
    return t.init = function(e, t) {
        var i, o = this,
            r = 0,
            s = 0,
            l = (o.slides = o.track.children, [].forEach.call(o.slides, function(e, t) {
                e.classList.add("glider-slide"), e.setAttribute("data-gslide", t)
            }), o.containerWidth = o.ele.clientWidth, o.settingsBreakpoint());
        t = t || l, "auto" !== o.opt.slidesToShow && void 0 === o.opt._autoSlide || (i = o.containerWidth / o.opt.itemWidth, o.opt._autoSlide = o.opt.slidesToShow = o.opt.exactWidth ? i : Math.max(1, Math.floor(i))), "auto" === o.opt.slidesToScroll && (o.opt.slidesToScroll = Math.floor(o.opt.slidesToShow)), o.itemWidth = o.opt.exactWidth ? o.opt.itemWidth : o.containerWidth / o.opt.slidesToShow, [].forEach.call(o.slides, function(e) {
            e.style.height = "auto", e.style.width = o.itemWidth + "px", r += o.itemWidth, s = Math.max(e.offsetHeight, s)
        }), o.track.style.width = r + "px", o.trackWidth = r, o.isDrag = !1, o.preventClick = !1, o.opt.resizeLock && o.scrollTo(o.slide * o.itemWidth, 0), (l || t) && (o.bindArrows(), o.buildDots(), o.bindDrag()), o.updateControls(), o.emit(e ? "refresh" : "loaded")
    }, t.bindDrag = function() {
        function e() {
            i.mouseDown = void 0, i.ele.classList.remove("drag"), i.isDrag && (i.preventClick = !0), i.isDrag = !1
        }
        var i = this,
            t = (i.mouse = i.mouse || i.handleMouse.bind(i), {
                mouseup: e,
                mouseleave: e,
                mousedown: function(e) {
                    var t = e.target;
                    ["SELECT", "INPUT", "TEXTAREA"].includes(t.tagName) ? i.preventClick = !1 : (e.preventDefault(), e.stopPropagation(), i.mouseDown = e.clientX, i.ele.classList.add("drag"))
                },
                mousemove: i.mouse,
                click: function(e) {
                    i.preventClick && (e.preventDefault(), e.stopPropagation()), i.preventClick = !1
                }
            });
        i.ele.classList.toggle("draggable", !0 === i.opt.draggable), i.event(i.ele, "remove", t), i.opt.draggable && i.event(i.ele, "add", t)
    }, t.buildDots = function() {
        var e = this;
        if (e.opt.dots) {
            if ("string" == typeof e.opt.dots ? e.dots = document.querySelector(e.opt.dots) : e.dots = e.opt.dots, e.dots) {
                e.dots.innerHTML = "", e.dots.classList.add("glider-dots");
                for (var t = 0; t < Math.ceil(e.slides.length / e.opt.slidesToShow); ++t) {
                    var i = document.createElement("button");
                    i.dataset.index = t, i.setAttribute("aria-label", "Page " + (t + 1)), i.setAttribute("role", "tab"), i.className = "glider-dot " + (t ? "" : "active"), e.event(i, "add", {
                        click: e.scrollItem.bind(e, t, !0)
                    }), e.dots.appendChild(i)
                }
            }
        } else e.dots && (e.dots.innerHTML = "")
    }, t.bindArrows = function() {
        var i = this;
        i.opt.arrows ? ["prev", "next"].forEach(function(e) {
            var t = i.opt.arrows[e];
            (t = t && ("string" == typeof t ? document.querySelector(t) : t)) && (t._func = t._func || i.scrollItem.bind(i, e), i.event(t, "remove", {
                click: t._func
            }), i.event(t, "add", {
                click: t._func
            }), i.arrows[e] = t)
        }) : Object.keys(i.arrows).forEach(function(e) {
            e = i.arrows[e];
            i.event(e, "remove", {
                click: e._func
            })
        })
    }, t.updateControls = function(e) {
        var n = this,
            t = (e && !n.opt.scrollPropagate && e.stopPropagation(), n.containerWidth >= n.trackWidth),
            a = (n.opt.rewind || (n.arrows.prev && (n.arrows.prev.classList.toggle("disabled", n.ele.scrollLeft <= 0 || t), n.arrows.prev.classList.contains("disabled") ? n.arrows.prev.setAttribute("aria-disabled", !0) : n.arrows.prev.setAttribute("aria-disabled", !1)), n.arrows.next && (n.arrows.next.classList.toggle("disabled", Math.ceil(n.ele.scrollLeft + n.containerWidth) >= Math.floor(n.trackWidth) || t), n.arrows.next.classList.contains("disabled") ? n.arrows.next.setAttribute("aria-disabled", !0) : n.arrows.next.setAttribute("aria-disabled", !1))), n.slide = Math.round(n.ele.scrollLeft / n.itemWidth), n.page = Math.round(n.ele.scrollLeft / n.containerWidth), n.slide + Math.floor(Math.floor(n.opt.slidesToShow) / 2)),
            d = Math.floor(n.opt.slidesToShow) % 2 ? 0 : a + 1;
        1 === Math.floor(n.opt.slidesToShow) && (d = 0), n.ele.scrollLeft + n.containerWidth >= Math.floor(n.trackWidth) && (n.page = n.dots ? n.dots.children.length - 1 : 0), [].forEach.call(n.slides, function(e, t) {
            var i = e.classList,
                e = i.contains("visible"),
                o = n.ele.scrollLeft,
                r = n.ele.scrollLeft + n.containerWidth,
                s = n.itemWidth * t,
                l = s + n.itemWidth,
                s = ([].forEach.call(i, function(e) {
                    /^left|right/.test(e) && i.remove(e)
                }), i.toggle("active", n.slide === t), a === t || d && d === t ? i.add("center") : (i.remove("center"), i.add([t < a ? "left" : "right", Math.abs(t - (!(t < a) && d || a))].join("-"))), Math.ceil(s) >= Math.floor(o) && Math.floor(l) <= Math.ceil(r));
            i.toggle("visible", s), s !== e && n.emit("slide-" + (s ? "visible" : "hidden"), {
                slide: t
            })
        }), n.dots && [].forEach.call(n.dots.children, function(e, t) {
            e.classList.toggle("active", n.page === t)
        }), e && n.opt.scrollLock && (clearTimeout(n.scrollLock), n.scrollLock = setTimeout(function() {
            clearTimeout(n.scrollLock), .02 < Math.abs(n.ele.scrollLeft / n.itemWidth - n.slide) && (n.mouseDown || n.trackWidth > n.containerWidth + n.ele.scrollLeft && n.scrollItem(n.getCurrentSlide()))
        }, n.opt.scrollLockDelay || 250))
    }, t.getCurrentSlide = function() {
        return this.round(this.ele.scrollLeft / this.itemWidth)
    }, t.scrollItem = function(e, t, i) {
        i && (i.preventDefault(), i.stopPropagation()), t ? .preventDefault && t.preventDefault();
        var o, r = this,
            s = e;
        return ++r.animate_id, e = !0 === t ? (e *= r.containerWidth, Math.round(e / r.itemWidth) * r.itemWidth) : ("string" == typeof e && (i = "prev" === e, e = r.opt.slidesToScroll % 1 || r.opt.slidesToShow % 1 ? r.getCurrentSlide() : r.slide, i ? e -= r.opt.slidesToScroll : e += r.opt.slidesToScroll, r.opt.rewind) && (o = r.ele.scrollLeft, e = i && !o ? r.slides.length : !i && Math.ceil(o + r.containerWidth) >= Math.floor(r.trackWidth) ? 0 : e), e = Math.max(Math.min(e, r.slides.length), 0), r.slide = e, r.itemWidth * e), r.scrollTo(e, r.opt.duration * Math.abs(r.ele.scrollLeft - e), function() {
            r.updateControls(), r.emit("animated", {
                value: s,
                type: "string" == typeof s ? "arrow" : t ? "dot" : "slide"
            })
        }), !1
    }, t.settingsBreakpoint = function() {
        var e = this,
            t = e._opt.responsive;
        if (t) {
            t.sort(function(e, t) {
                return t.breakpoint - e.breakpoint
            });
            for (var i = 0; i < t.length; ++i) {
                var o = t[i];
                if (a.innerWidth >= o.breakpoint) return e.breakpoint !== o.breakpoint && (e.opt = Object.assign({}, e._opt, o.settings), e.breakpoint = o.breakpoint, !0)
            }
        }
        var r = 0 !== e.breakpoint;
        return e.opt = Object.assign({}, e._opt), e.breakpoint = 0, r
    }, t.scrollTo = function(t, i, o) {
        var r = this,
            s = (new Date).getTime(),
            l = r.animate_id,
            n = function() {
                var e = (new Date).getTime() - s;
                r.ele.scrollLeft = r.ele.scrollLeft + (t - r.ele.scrollLeft) * r.opt.easing(0, e, 0, 1, i), e < i && l === r.animate_id ? a.requestAnimationFrame(n) : (r.ele.scrollLeft = t, o && o.call(r))
            };
        a.requestAnimationFrame(n)
    }, t.removeItem = function(e) {
        var t = this;
        t.slides.length && (t.track.removeChild(t.slides[e]), t.refresh(!0), t.emit("remove"))
    }, t.addItem = function(e) {
        this.track.appendChild(e), this.refresh(!0), this.emit("add")
    }, t.handleMouse = function(e) {
        var t = this;
        t.mouseDown && (t.isDrag = !0, t.ele.scrollLeft += (t.mouseDown - e.clientX) * (t.opt.dragVelocity || 3.3), t.mouseDown = e.clientX)
    }, t.round = function(e) {
        var t = 1 / (this.opt.slidesToScroll % 1 || 1);
        return Math.round(e * t) / t
    }, t.refresh = function(e) {
        this.init(!0, e)
    }, t.setOption = function(t, e) {
        var i = this;
        i.breakpoint && !e ? i._opt.responsive.forEach(function(e) {
            e.breakpoint === i.breakpoint && (e.settings = Object.assign({}, e.settings, t))
        }) : i._opt = Object.assign({}, i._opt, t), i.breakpoint = 0, i.settingsBreakpoint()
    }, t.destroy = function() {
        function e(t) {
            t.removeAttribute("style"), [].forEach.call(t.classList, function(e) {
                /^glider/.test(e) && t.classList.remove(e)
            })
        }
        var t = this,
            i = t.ele.cloneNode(!0);
        i.children[0].outerHTML = i.children[0].innerHTML, e(i), [].forEach.call(i.getElementsByTagName("*"), e), t.ele.parentNode.replaceChild(i, t.ele), t.event(a, "remove", {
            resize: t.resize
        }), t.emit("destroy")
    }, t.emit = function(e, t) {
        e = new a.CustomEvent("glider-" + e, {
            bubbles: !this.opt.eventPropagate,
            detail: t
        });
        this.ele.dispatchEvent(e)
    }, t.event = function(e, t, i) {
        var o = e[t + "EventListener"].bind(e);
        Object.keys(i).forEach(function(e) {
            o(e, i[e])
        })
    }, e
});