((t, e) => {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? exports.SnapSlider = e() : t.SnapSlider = e()
})(window, function() {
    return n = [function(t, e) {
        t.exports = function(t) {
            var e = typeof t;
            return null != t && ("object" == e || "function" == e)
        }
    }, function(t, e, n) {
        var y = n(0),
            m = n(7),
            x = n(10),
            S = Math.max,
            w = Math.min;
        t.exports = function(o, n, t) {
            var r, i, s, a, l, c, u = 0,
                f = !1,
                d = !1,
                e = !0;
            if ("function" != typeof o) throw TypeError("Expected a function");

            function p(t) {
                var e = r,
                    n = i;
                return r = i = void 0, u = t, a = o.apply(n, e)
            }

            function h(t) {
                var e = t - c;
                return void 0 === c || n <= e || e < 0 || d && s <= t - u
            }

            function v() {
                var t, e = m();
                if (h(e)) return b(e);
                l = setTimeout(v, (t = n - (e - c), d ? w(t, s - (e - u)) : t))
            }

            function b(t) {
                return l = void 0, e && r ? p(t) : (r = i = void 0, a)
            }

            function g() {
                var t = m(),
                    e = h(t);
                if (r = arguments, i = this, c = t, e) {
                    if (void 0 === l) return u = t = c, l = setTimeout(v, n), f ? p(t) : a;
                    if (d) return clearTimeout(l), l = setTimeout(v, n), p(c)
                }
                return void 0 === l && (l = setTimeout(v, n)), a
            }
            return n = x(n) || 0, y(t) && (f = !!t.leading, s = (d = "maxWait" in t) ? S(x(t.maxWait) || 0, n) : s, e = "trailing" in t ? !!t.trailing : e), g.cancel = function() {
                void 0 !== l && clearTimeout(l), r = c = i = l = void(u = 0)
            }, g.flush = function() {
                return void 0 === l ? a : b(m())
            }, g
        }
    }, function(t, e, n) {
        var i = n(1),
            s = n(0);
        t.exports = function(t, e, n) {
            var o = !0,
                r = !0;
            if ("function" != typeof t) throw TypeError("Expected a function");
            return s(n) && (o = "leading" in n ? !!n.leading : o, r = "trailing" in n ? !!n.trailing : r), i(t, e, {
                leading: o,
                maxWait: e,
                trailing: r
            })
        }
    }, function(t, e, n) {
        var n = n(8),
            o = "object" == typeof self && self && self.Object === Object && self,
            n = n || o || Function("return this")();
        t.exports = n
    }, function(t, e, n) {
        n = n(3).Symbol;
        t.exports = n
    }, function(t, e, n) {
        t.exports = {
            polyfill: function() {
                var t, e, a, l, n, c = window,
                    u = document;

                function f(t, e) {
                    this.scrollLeft = t, this.scrollTop = e
                }

                function o(t) {
                    if (null === t || "object" != typeof t || void 0 === t.behavior || "auto" === t.behavior || "instant" === t.behavior) return !0;
                    if ("object" == typeof t && "smooth" === t.behavior) return !1;
                    throw TypeError("behavior member of ScrollOptions " + t.behavior + " is not a valid value for enumeration ScrollBehavior.")
                }

                function r(t, e) {
                    return "Y" === e ? t.clientHeight + n < t.scrollHeight : "X" === e ? t.clientWidth + n < t.scrollWidth : void 0
                }

                function i(t, e) {
                    t = c.getComputedStyle(t, null)["overflow" + e];
                    return "auto" === t || "scroll" === t
                }

                function s(t, e, n) {
                    var o, r, i, s = l(),
                        t = t === u.body ? (r = (o = c).scrollX || c.pageXOffset, i = c.scrollY || c.pageYOffset, a.scroll) : (r = (o = t).scrollLeft, i = t.scrollTop, f);
                    (function t(e) {
                        var n = (l() - e.startTime) / 468,
                            n = .5 * (1 - Math.cos(Math.PI * (1 < n ? 1 : n))),
                            o = e.startX + (e.x - e.startX) * n,
                            n = e.startY + (e.y - e.startY) * n;
                        e.method.call(e.scrollable, o, n), o === e.x && n === e.y || c.requestAnimationFrame(t.bind(c, e))
                    })({
                        scrollable: o,
                        method: t,
                        startTime: s,
                        startX: r,
                        startY: i,
                        x: e,
                        y: n
                    })
                }
                "scrollBehavior" in u.documentElement.style && !0 !== c.__forceSmoothScrollPolyfill__ || (e = c.HTMLElement || c.Element, a = {
                    scroll: c.scroll || c.scrollTo,
                    scrollBy: c.scrollBy,
                    elementScroll: e.prototype.scroll || f,
                    scrollIntoView: e.prototype.scrollIntoView
                }, l = c.performance && c.performance.now ? c.performance.now.bind(c.performance) : Date.now, t = c.navigator.userAgent, n = RegExp("MSIE |Trident/|Edge/").test(t) ? 1 : 0, c.scroll = c.scrollTo = function() {
                    void 0 !== arguments[0] && (!0 !== o(arguments[0]) ? s.call(c, u.body, void 0 !== arguments[0].left ? ~~arguments[0].left : c.scrollX || c.pageXOffset, void 0 !== arguments[0].top ? ~~arguments[0].top : c.scrollY || c.pageYOffset) : a.scroll.call(c, void 0 !== arguments[0].left ? arguments[0].left : "object" != typeof arguments[0] ? arguments[0] : c.scrollX || c.pageXOffset, void 0 !== arguments[0].top ? arguments[0].top : void 0 !== arguments[1] ? arguments[1] : c.scrollY || c.pageYOffset))
                }, c.scrollBy = function() {
                    void 0 !== arguments[0] && (o(arguments[0]) ? a.scrollBy.call(c, void 0 !== arguments[0].left ? arguments[0].left : "object" != typeof arguments[0] ? arguments[0] : 0, void 0 !== arguments[0].top ? arguments[0].top : void 0 !== arguments[1] ? arguments[1] : 0) : s.call(c, u.body, ~~arguments[0].left + (c.scrollX || c.pageXOffset), ~~arguments[0].top + (c.scrollY || c.pageYOffset)))
                }, e.prototype.scroll = e.prototype.scrollTo = function() {
                    if (void 0 !== arguments[0])
                        if (!0 !== o(arguments[0])) {
                            var t = arguments[0].left,
                                e = arguments[0].top;
                            s.call(this, this, void 0 === t ? this.scrollLeft : ~~t, void 0 === e ? this.scrollTop : ~~e)
                        } else {
                            if ("number" == typeof arguments[0] && void 0 === arguments[1]) throw SyntaxError("Value could not be converted");
                            a.elementScroll.call(this, void 0 !== arguments[0].left ? ~~arguments[0].left : "object" != typeof arguments[0] ? ~~arguments[0] : this.scrollLeft, void 0 !== arguments[0].top ? ~~arguments[0].top : void 0 !== arguments[1] ? ~~arguments[1] : this.scrollTop)
                        }
                }, e.prototype.scrollBy = function() {
                    void 0 !== arguments[0] && (!0 !== o(arguments[0]) ? this.scroll({
                        left: ~~arguments[0].left + this.scrollLeft,
                        top: ~~arguments[0].top + this.scrollTop,
                        behavior: arguments[0].behavior
                    }) : a.elementScroll.call(this, void 0 !== arguments[0].left ? ~~arguments[0].left + this.scrollLeft : ~~arguments[0] + this.scrollLeft, void 0 !== arguments[0].top ? ~~arguments[0].top + this.scrollTop : ~~arguments[1] + this.scrollTop))
                }, e.prototype.scrollIntoView = function() {
                    var t, e, n;
                    !0 !== o(arguments[0]) ? (e = (t = (t => {
                        for (; t !== u.body && !1 === (n = void 0, n = r(e = t, "Y") && i(e, "Y"), e = r(e, "X") && i(e, "X"), n || e);) t = t.parentNode || t.host;
                        var e, n;
                        return t
                    })(this)).getBoundingClientRect(), n = this.getBoundingClientRect(), t !== u.body ? (s.call(this, t, t.scrollLeft + n.left - e.left, t.scrollTop + n.top - e.top), "fixed" !== c.getComputedStyle(t).position && c.scrollBy({
                        left: e.left,
                        top: e.top,
                        behavior: "smooth"
                    })) : c.scrollBy({
                        left: n.left,
                        top: n.top,
                        behavior: "smooth"
                    })) : a.scrollIntoView.call(this, void 0 === arguments[0] || arguments[0])
                })
            }
        }
    }, function(t, e) {
        var n = ["input", "select", "textarea", "a[href]", "button", "[tabindex]", "audio[controls]", "video[controls]", '[contenteditable]:not([contenteditable="false"])'],
            l = n.join(","),
            c = "undefined" == typeof Element ? function() {} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;

        function o(t, e) {
            e = e || {};
            var n, o, r, i = [],
                s = [],
                a = t.querySelectorAll(l);
            for (e.includeContainer && c.call(t, l) && (a = Array.prototype.slice.apply(a)).unshift(t), n = 0; n < a.length; n++) u(o = a[n]) && (0 === (r = f(o)) ? i.push(o) : s.push({
                documentOrder: n,
                tabIndex: r,
                node: o
            }));
            return s.sort(d).map(function(t) {
                return t.node
            }).concat(i)
        }

        function u(t) {
            var e, n;
            return !(!r(t) || s(e = n = t) && "radio" === e.type && (e = n).name && (n = (t => {
                for (var e = 0; e < t.length; e++)
                    if (t[e].checked) return t[e]
            })(e.ownerDocument.querySelectorAll('input[type="radio"][name="' + e.name + '"]'))) && n !== e || f(t) < 0)
        }

        function r(t) {
            var e;
            return !(t.disabled || s(e = t) && "hidden" === e.type || null === t.offsetParent || "hidden" === getComputedStyle(t).visibility)
        }
        o.isTabbable = function(t) {
            if (t) return !1 !== c.call(t, l) && u(t);
            throw Error("No node provided")
        }, o.isFocusable = function(t) {
            if (t) return !1 !== c.call(t, i) && r(t);
            throw Error("No node provided")
        };
        var i = n.concat("iframe").join(",");

        function f(t) {
            var e = parseInt(t.getAttribute("tabindex"), 10);
            return isNaN(e) ? "true" === t.contentEditable ? 0 : t.tabIndex : e
        }

        function d(t, e) {
            return t.tabIndex === e.tabIndex ? t.documentOrder - e.documentOrder : t.tabIndex - e.tabIndex
        }

        function s(t) {
            return "INPUT" === t.tagName
        }
        t.exports = o
    }, function(t, e, n) {
        var o = n(3);
        t.exports = function() {
            return o.Date.now()
        }
    }, function(e, t, n) {
        ! function(t) {
            t = "object" == typeof t && t && t.Object === Object && t;
            e.exports = t
        }.call(this, n(9))
    }, function(t, e) {
        var n = function() {
            return this
        }();
        try {
            n = n || Function("return this")()
        } catch (t) {
            "object" == typeof window && (n = window)
        }
        t.exports = n
    }, function(t, e, n) {
        var o = n(11),
            r = n(0),
            i = n(13),
            s = /^[-+]0x[0-9a-f]+$/i,
            a = /^0b[01]+$/i,
            l = /^0o[0-7]+$/i,
            c = parseInt;
        t.exports = function(t) {
            if ("number" == typeof t) return t;
            if (i(t)) return NaN;
            if (r(t) && (e = "function" == typeof t.valueOf ? t.valueOf() : t, t = r(e) ? e + "" : e), "string" != typeof t) return 0 === t ? t : +t;
            t = o(t);
            var e = a.test(t);
            return e || l.test(t) ? c(t.slice(2), e ? 2 : 8) : s.test(t) ? NaN : +t
        }
    }, function(t, e, n) {
        var o = n(12),
            r = /^\s+/;
        t.exports = function(t) {
            return t && t.slice(0, o(t) + 1).replace(r, "")
        }
    }, function(t, e) {
        var n = /\s/;
        t.exports = function(t) {
            for (var e = t.length; e-- && n.test(t.charAt(e)););
            return e
        }
    }, function(t, e, n) {
        var o = n(14),
            r = n(17);
        t.exports = function(t) {
            return "symbol" == typeof t || r(t) && "[object Symbol]" == o(t)
        }
    }, function(t, e, n) {
        var o = n(4),
            r = n(15),
            i = n(16),
            s = o ? o.toStringTag : void 0;
        t.exports = function(t) {
            return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : (s && s in Object(t) ? r : i)(t)
        }
    }, function(t, e, n) {
        var n = n(4),
            o = Object.prototype,
            i = o.hasOwnProperty,
            s = o.toString,
            a = n ? n.toStringTag : void 0;
        t.exports = function(t) {
            var e = i.call(t, a),
                n = t[a];
            try {
                var o = !(t[a] = void 0)
            } catch (t) {}
            var r = s.call(t);
            return o && (e ? t[a] = n : delete t[a]), r
        }
    }, function(t, e) {
        var n = Object.prototype.toString;
        t.exports = function(t) {
            return n.call(t)
        }
    }, function(t, e) {
        t.exports = function(t) {
            return null != t && "object" == typeof t
        }
    }, function(t, e, n) {
        n.r(e);
        var o = n(5),
            r = n.n(o),
            o = n(6),
            i = n.n(o),
            o = n(1),
            s = n.n(o),
            o = n(2),
            a = n.n(o);

        function l(t) {
            return Array.prototype.slice.call(t)
        }

        function c(t, e) {
            return t ? l((e || document).querySelectorAll(t)) : []
        }

        function u(t, e) {
            return "string" == typeof t ? c(t, e) : t instanceof Element ? [t] : t ? Array.prototype.slice.call(t) : []
        }

        function f(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }

        function d(t) {
            return t && "Object" === t.constructor.name
        }

        function p(t, e, n) {
            return Math.max(e, t = Math.min(n, t))
        }
        var h = (() => {
            var t = !1;
            try {
                var e = Object.defineProperty({}, "passive", {
                    get: function() {
                        t = {
                            passive: !0
                        }
                    }
                });
                window.addEventListener("testPassive", null, e), window.removeEventListener("testPassive", null, e)
            } catch (t) {}
            return t
        })();

        function v(e, t) {
            var n, o = Object.keys(e);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(e), t && (n = n.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            })), o.push.apply(o, n)), o
        }

        function b(o) {
            for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? arguments[t] : {};
                t % 2 ? v(Object(r), !0).forEach(function(t) {
                    var e, n;
                    e = o, n = r[t = t], t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(r)) : v(Object(r)).forEach(function(t) {
                    Object.defineProperty(o, t, Object.getOwnPropertyDescriptor(r, t))
                })
            }
            return o
        }

        function g(t, e) {
            for (var n = 0; n < e.length; n++) {
                var o = e[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
            }
        }
        var y = 1,
            m = (n = [{
                key: "isValidIndex",
                value: function(t) {
                    return 0 <= ["first", "middle", "last", "prev", "next"].indexOf(t) || 1 <= parseInt(t, 10)
                }
            }, {
                key: "getButtonTarget",
                value: function(t) {
                    var e, n, o, r = t ? t.getAttribute("data-snap-slider-goto") : "";
                    return r ? (e = (r = r.split(":").map(function(t) {
                        return t.trim()
                    })).pop(), (r = r.pop()) || (o = t.closest("[data-snap-slider-nav]"), n = t.closest("[data-snap-slider]"), o && (r = o.getAttribute("data-snap-slider-nav")), n && (r = n.getAttribute("data-snap-slider"))), r || (o = t.closest("data-snap-slider")) && (r = o.getAttribute("data-snap-slider")), {
                        sliderID: r,
                        index: e
                    }) : {}
                }
            }, {
                key: "handleGoto",
                value: function(t) {
                    var e = t.target.closest("[data-snap-slider-goto]"),
                        e = x.getButtonTarget(e),
                        n = e.sliderID,
                        n = window._SnapSliders[n];
                    n && n.goto(e.index, null, t)
                }
            }, {
                key: "isRelative",
                value: function(t) {
                    return "prev" === t || "next" === t
                }
            }, {
                key: "notFound",
                value: function(t) {}
            }, {
                key: "get",
                value: function(t) {
                    return window._SnapSliders[t]
                }
            }, {
                key: "debug",
                value: function(t) {}
            }], g((o = x).prototype, [{
                key: "init",
                value: function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        t = (d(t) && (e = t), this.options = b({
                            container: t,
                            id: "",
                            slides: "",
                            nav: "",
                            buttons: "",
                            prev: "",
                            next: "",
                            start: 0,
                            loop: null,
                            on: {}
                        }, e), u(this.options.container).shift());
                    if (t) {
                        for (var n in this.container = t, this.options.buttons = e.buttons || this.container.getAttribute("data-snap-slider-buttons"), this.options.prev = e.prev || this.container.getAttribute("data-snap-slider-prev"), this.options.next = e.next || this.container.getAttribute("data-snap-slider-next"), this.id = this.getMaybeSetID(t, this.options.id), this.slides = this.getMaybeSetSlides(t, this.options.slides), this.align = this.getMaybeSetAlign(t, this.options.align), this.current = this.getMaybeSetStart(t, this.options.start), this.loop = this.getMaybeSetLoop(t, this.options.loop), this.transition = null, this.scrolling = !1, this.options.on) f(this.options.on, n) && this.on(n, this.options.on[n]);
                        o = this.options;
                        var o, e = ["buttons", "prev", "next"].reduce(function(t, e) {
                            return t[e] = o[e], t
                        }, {});
                        this.addGotoButtons(b(b({}, e), {}, {
                            container: t
                        })), this.addNav('[data-snap-slider-nav="'.concat(this.id, '"]'), e), this.options.nav && this.addNav(this.options.nav, e), this.update()
                    }
                }
            }, {
                key: "getMaybeSetID",
                value: function(t, e) {
                    return (e = e || t.getAttribute("data-snap-slider") || t.id) || (e = "slider-".concat(y), y += 1), t.setAttribute("data-snap-slider", e), e
                }
            }, {
                key: "getMaybeSetSlides",
                value: function(t, e) {
                    e = e && "string" == typeof e ? e : t.getAttribute("data-snap-slider-slides"), t.setAttribute("data-snap-slider-slides", e || "");
                    e = e ? u(e, t) : l(t.children);
                    return e.forEach(function(t) {
                        return t.setAttribute("tabindex", "-1")
                    }), e
                }
            }, {
                key: "getMaybeSetAlign",
                value: function(t, e) {
                    return e = e || t.getAttribute("data-snap-slider-align") || "", t.setAttribute("data-snap-slider-align", e), e
                }
            }, {
                key: "getMaybeSetStart",
                value: function(t, e) {
                    return x.isValidIndex(e) || (e = t.getAttribute("data-snap-slider-start") || 1), t.setAttribute("data-snap-slider-start", e), e
                }
            }, {
                key: "getMaybeSetLoop",
                value: function(t, e) {
                    return e = "boolean" == typeof e ? e : "true" === t.getAttribute("data-snap-slider-loop"), t.setAttribute("data-snap-slider-loop", e), e
                }
            }, {
                key: "getSnapAlign",
                value: function(t) {
                    var e = "scrollSnapAlign",
                        n = (n = window.getComputedStyle(t)) && f(n, e) ? n[e] : "",
                        e = "data-snap-slider-align";
                    return n && n.indexOf("none") < 0 ? n : ((n = (n = t) && n.closest("[".concat(e, "]"))) ? n.getAttribute(e) : "") || "start"
                }
            }, {
                key: "getSlide",
                value: function(t) {
                    return t = this.getIndexNumber(t), this.slides[t - 1]
                }
            }, {
                key: "getCurrentSlide",
                value: function() {
                    return this.slides[this.current - 1]
                }
            }, {
                key: "getIndexNumber",
                value: function(t) {
                    t = "first" === t ? 1 : "middle" === t ? Math.ceil(this.slides.length / 2) : "last" === t ? this.slides.length : "prev" === t ? this.current - 1 : "next" === t ? this.current + 1 : parseInt(t, 10) || -1;
                    return this.loop ? (t = t < 1 ? this.slides.length : t) > this.slides.length && (t = 1) : (t < 1 || t > this.slides.length) && (t = -1), t || 1
                }
            }, {
                key: "getScrollOffset",
                value: function(t) {
                    var e = this.container,
                        n = this.getSnapAlign(t),
                        o = t.offsetTop,
                        r = t.offsetLeft;
                    return 0 <= n.indexOf("center") ? (o = t.offsetTop + t.offsetHeight / 2 - e.offsetHeight / 2, r = t.offsetLeft + t.offsetWidth / 2 - e.offsetWidth / 2) : 0 <= n.indexOf("end") && (o = t.offsetTop - e.offsetHeight + t.offsetHeight, r = t.offsetLeft - e.offsetWidth + t.offsetWidth), {
                        top: o = p(o, 0, e.scrollHeight),
                        left: r = p(r, 0, e.scrollWidth)
                    }
                }
            }, {
                key: "goto",
                value: function(t) {
                    var e, n, o = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        r = 2 < arguments.length ? arguments[2] : void 0,
                        o = b({
                            focus: !0,
                            force: !1,
                            ignoreCallbacks: !1,
                            immediate: !1
                        }, o),
                        t = this.getIndexNumber(t);
                    return !(!o.force && t === this.current || !(n = this.getSlide(t)) || (e = (n = this.getScrollOffset(n)).top, n = n.left, o.immediate ? "function" == typeof this.container.scroll && this.container.scroll({
                        top: e,
                        left: n
                    }) : (this.startTransition(t), "function" == typeof this.container.scroll && this.container.scroll({
                        top: e,
                        left: n,
                        behavior: "smooth"
                    })), this.current = t, this.fireEvent("change", r, o), 0))
                }
            }, {
                key: "buildGoto",
                value: function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "",
                        n = "";
                    return t || (n += "".concat(this.id, ":")), n + e
                }
            }, {
                key: "setGoto",
                value: function(t, e) {
                    var n = this;
                    (t = u(t)).forEach(function(t) {
                        t.setAttribute("data-snap-slider-goto", n.buildGoto(t.closest("[data-snap-slider], [data-snap-slider-nav]"), e))
                    })
                }
            }, {
                key: "startTransition",
                value: function(t) {
                    var e = this,
                        n = (this.transition = {
                            from: this.current,
                            to: t,
                            diff: Math.abs(t - this.current)
                        }, this.transition.to);
                    this.checkTransition && clearTimeout(this.checkTransition), this.checkTransition = setTimeout(function() {
                        e.transition.to === n && e.stopTransition()
                    }, 1e3)
                }
            }, {
                key: "stopTransition",
                value: function() {
                    this.transition = null, clearTimeout(this.checkTransition)
                }
            }, {
                key: "isPrevButton",
                value: function(t) {
                    return !!(t = u(t).shift()) && ((t.getAttribute("data-snap-slider-goto") || "").match(/\bprev$/) || t.textContent.toLowerCase().match(this.terms.prev) || t.className.toLowerCase().match(this.terms.prev))
                }
            }, {
                key: "isNextButton",
                value: function(t) {
                    return !!(t = u(t).shift()) && ((t.getAttribute("data-snap-slider-goto") || "").match(/\bnext$/) || t.textContent.toLowerCase().match(this.terms.next) || t.className.toLowerCase().match(this.terms.next))
                }
            }, {
                key: "isCurrent",
                value: function(t) {
                    return !x.isRelative(t) && this.getIndexNumber(t) === this.current
                }
            }, {
                key: "addGotoButtons",
                value: function(t) {
                    var n = this,
                        e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        t = u((e = b({
                            container: "",
                            buttons: t,
                            prev: "",
                            next: ""
                        }, e = d(t) ? t : e)).buttons, e.container),
                        o = u(e.prev, e.container),
                        r = u(e.next, e.container),
                        i = (o.forEach(function(t) {
                            return t.hasAttribute("data-snap-slider-goto") || n.setGoto(o, "prev")
                        }), r.forEach(function(t) {
                            return t.hasAttribute("data-snap-slider-goto") || n.setGoto(r, "next")
                        }), 1);
                    return t.forEach(function(t) {
                        var e;
                        return t.hasAttribute("data-snap-slider-goto") ? null : n.isPrevButton(t) ? n.setGoto(t, "prev") : n.isNextButton(t) ? n.setGoto(t, "next") : (e = parseInt(t.textContent.replace(/.*\b(\d+)\b.*/, "$1"), 10) || i, i = e + 1, n.setGoto(t, e))
                    }), this.updateButtons(), !0
                }
            }, {
                key: "getNavs",
                value: function() {
                    var e = this;
                    return c("[data-snap-slider-nav]").filter(function(t) {
                        return t.getAttribute("data-snap-slider-nav") === e.id
                    })
                }
            }, {
                key: "getButtons",
                value: function() {
                    var e = this;
                    return c("[data-snap-slider-goto]").filter(function(t) {
                        return x.getButtonTarget(t).sliderID === e.id
                    })
                }
            }, {
                key: "updateButtons",
                value: function() {
                    var n = this;
                    this.current && this.getButtons().forEach(function(t) {
                        var e = x.getButtonTarget(t).index;
                        n.isCurrent(e) ? t.classList.add("is-current") : t.classList.remove("is-current"), !n.loop && x.isRelative(e) && ("prev" === e && 1 === n.current || "next" === e && n.current === n.slides.length ? t.classList.add("is-disabled") : t.classList.remove("is-disabled"))
                    })
                }
            }, {
                key: "updateSlides",
                value: function() {
                    var n = this;
                    this.slides.forEach(function(t, e) {
                        e === n.current - 1 ? (t.classList.add("is-current"), t.removeAttribute("aria-hidden"), c("[data-snap-slider-tabindex]", t).forEach(function(t) {
                            t.removeAttribute("tabindex")
                        })) : (t.classList.remove("is-current"), t.setAttribute("aria-hidden", "true"), i()(t).forEach(function(t) {
                            t.setAttribute("tabindex", "-1"), t.setAttribute("data-snap-slider-tabindex", "")
                        }))
                    })
                }
            }, {
                key: "addNav",
                value: function(t) {
                    var r = this,
                        i = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        t = u((i = b({
                            container: t,
                            buttons: "",
                            prev: "",
                            next: ""
                        }, i = d(t) ? t : i)).container);
                    return !!t.length && (t.forEach(function(t) {
                        t.setAttribute("data-snap-slider-nav", r.id);
                        var e = t.getAttribute("data-snap-slider-buttons") || i.buttons || "button",
                            n = i.prev || t.getAttribute("data-snap-slider-prev"),
                            o = i.next || t.getAttribute("data-snap-slider-next");
                        r.addGotoButtons({
                            container: t,
                            buttons: e,
                            prev: n,
                            next: o
                        })
                    }), !0)
                }
            }, {
                key: "getClosest",
                value: function() {
                    var r = this;
                    return this.slides.reduce(function(t, e, n) {
                        n += 1;
                        var o = r.getScrollOffset(e),
                            n = {
                                index: n,
                                slide: e,
                                diff: {
                                    top: Math.abs(r.container.scrollTop - o.top),
                                    left: Math.abs(r.container.scrollLeft - o.left)
                                }
                            };
                        return !t || n.diff.left <= t.diff.left && n.diff.top <= t.diff.top ? n : t
                    }, !1)
                }
            }, {
                key: "watchForChanges",
                value: function() {
                    var i = this;
                    this.scrollListener = a()(function(t) {
                        var e = i.getClosest();
                        i.transition || e.index === i.current || (i.current = e.index, i.fireEvent("change", t)), i.scrolling || (i.scrolling = !0, i.fireEvent("scroll.start", t)), i.fireEvent("scroll", t)
                    }, 250), this.scrollEndListener = s()(function(t) {
                        i.scrolling = !1, i.fireEvent("scroll.end", t), i.stopTransition()
                    }, 100), this.arrowKeyListener = a()(function(t) {
                        var e, n;
                        !t.defaultPrevented && (e = 0 <= ["Up", "ArrowUp", "Left", "ArrowLeft"].indexOf(t.key), n = 0 <= ["Down", "ArrowDown", "Right", "ArrowRight"].indexOf(t.key), e || n) && (i.goto(n ? "next" : "prev", null, t), t.preventDefault())
                    }, 250), this.focusListener = function(n) {
                        var o, r;
                        i.scrolling && !i.transition || (i.slides.forEach(function(t, e) {
                            t.contains(n.target) && (o = t, r = e + 1)
                        }, null), o && i.goto(r, null, n))
                    }, this.resizeObserver = {
                        observe: function() {},
                        disconnect: function() {}
                    }, "ResizeObserver" in window && (this.resizeObserver = new ResizeObserver(this.resizeCallback.bind(this))), setTimeout(function() {
                        i.container.addEventListener("scroll", i.scrollListener, h), i.container.addEventListener("scroll", i.scrollEndListener, h), i.resizeObserver.observe(i.container), i.fireEvent("load")
                    }, 100)
                }
            }, {
                key: "hasLoaded",
                value: function() {
                    this.container.classList.add("has-loaded")
                }
            }, {
                key: "update",
                value: function() {
                    this.goto(this.current, {
                        focus: !1,
                        force: !0,
                        ignoreCallbacks: !0,
                        immediate: !0
                    })
                }
            }, {
                key: "destroy",
                value: function() {
                    for (var t in this.stopTransition(), this.container.removeEventListener("scroll", this.scrollListener), this.container.removeEventListener("scroll", this.scrollEndListener), this.container.removeEventListener("keydown", this.arrowKeyListener), this.resizeObserver.disconnect(), this.callbacks) f(this.callbacks, t) && (this.callbacks[t] = []);
                    delete this.container.SnapSlider, delete window._SnapSliders[this.id]
                }
            }, {
                key: "reset",
                value: function() {
                    var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
                        e = this.options;
                    delete e.on, delete t.container, delete t.id, this.init(this.container, b(b({}, e), t))
                }
            }, {
                key: "resizeCallback",
                value: function() {
                    this.update()
                }
            }, {
                key: "fireEvent",
                value: function(t, e) {
                    var n = this,
                        o = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
                    f(this.callbacks, t) && (o = b({
                        focus: !0,
                        ignoreCallbacks: !1
                    }, o), "load" === t && this.hasLoaded(), "change" === t && (this.updateButtons(), this.updateSlides()), o.focus && this.handleFocus(t, e), !o.ignoreCallbacks) && (e = e || {}, o = [t], f(this.callbacks, "".concat(t, ".").concat(e.type)) && o.push("".concat(t, ".").concat(e.type)), o.forEach(function(t) {
                        n.callbacks[t].forEach(function(t) {
                            "function" == typeof t && t(n, e)
                        })
                    }))
                }
            }, {
                key: "handleFocus",
                value: function(t, e) {
                    if (this.transition) {
                        if (e && "change" === t) {
                            e = e.target.closest("[data-snap-slider-goto]"), e = x.getButtonTarget(e).index;
                            if (x.isRelative(e)) return
                        }
                        1 < this.transition.diff && "scroll.end" === t && (document.activeElement && document.activeElement !== document.body && !document.activeElement.closest("[data-snap-slider-goto]") || this.getCurrentSlide().focus({
                            preventScroll: !0
                        }))
                    }
                }
            }, {
                key: "on",
                value: function(t, e) {
                    f(this.callbacks, t) && "function" == typeof e && this.callbacks[t].push(e)
                }
            }]), g(o, n), x);

        function x(t) {
            var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                n = this,
                o = x;
            if (!(n instanceof o)) throw TypeError("Cannot call a class as a function");
            this.terms = {
                prev: /(prev|back|before|left|up)/,
                next: /(next|forward|after|right|down)/
            }, this.callbacks = {
                load: [],
                change: [],
                "change.click": [],
                "change.scroll": [],
                "change.keydown": [],
                "change.focusin": [],
                scroll: [],
                "scroll.start": [],
                "scroll.end": []
            }, this.init(t, e), this.container && (this.watchForChanges(), this.container.SnapSlider = this, window._SnapSliders[this.id] = this)
        }
        window._SnapSliders = [], window.SnapSlider = m, "undefined" != typeof $ && $.fn && ($.fn.snapSlider = function(t) {
            return new m(this, t)
        }), o = function() {
            var a, l, t = window;
            "function" != typeof(t = t.Element.prototype).matches && (t.matches = t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector || function(t) {
                for (var e = (this.document || this.ownerDocument).querySelectorAll(t), n = 0; e[n] && e[n] !== this;) ++n;
                return Boolean(e[n])
            }), "function" != typeof t.closest && (t.closest = function(t) {
                for (var e = this; e && 1 === e.nodeType;) {
                    if (e.matches(t)) return e;
                    e = e.parentNode
                }
                return null
            }), r.a.polyfill(), c("[data-snap-slider]").forEach(function(t) {
                return new m(t)
            }), a = m.handleGoto, (l = document.querySelector("body")) && l.addEventListener("click", function(t) {
                for (var e = l.querySelectorAll("[data-snap-slider-goto]"), n = t.target, o = 0, r = e.length; o < r; o += 1)
                    for (var i = n, s = e[o]; i && i !== l;) {
                        if (i === s) return a.call(s, t);
                        i = i.parentNode
                    }
            })
        }, "loading" !== document.readyState ? o() : document.addEventListener("DOMContentLoaded", o), e.default = m
    }], o = {}, r.m = n, r.c = o, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function(e, t) {
        if (1 & t && (e = r(e)), 8 & t || 4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) r.d(n, o, function(t) {
                return e[t]
            }.bind(null, o));
        return n
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "", r(r.s = 18).default;

    function r(t) {
        var e;
        return (o[t] || (e = o[t] = {
            i: t,
            l: !1,
            exports: {}
        }, n[t].call(e.exports, e, e.exports, r), e.l = !0, e)).exports
    }
    var n, o
});