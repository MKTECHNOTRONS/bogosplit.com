function _defineProperty(e, t, i) {
    return (t = _toPropertyKey(t)) in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e
}

function _toPropertyKey(e) {
    e = _toPrimitive(e, "string");
    return "symbol" == typeof e ? e : e + ""
}

function _toPrimitive(e, t) {
    if ("object" != typeof e || !e) return e;
    var i = e[Symbol.toPrimitive];
    if (void 0 === i) return ("string" === t ? String : Number)(e);
    i = i.call(e, t || "default");
    if ("object" != typeof i) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.")
}
class _pf_MediaGallery {
    constructor(e, t, i = 0) {
        _defineProperty(this, "isZoom", !1), _defineProperty(this, "transformState", {
            scale: 1,
            transX: 0,
            transY: 0
        }), _defineProperty(this, "pointState", {
            startX0: null,
            startY0: null,
            endX0: null,
            endY0: null,
            startX1: null,
            startY1: null,
            endX1: null,
            endY1: null
        }), _defineProperty(this, "twoTouchesMoveTimeStamp", 0), _defineProperty(this, "loaded", !1), this.getDevice(), this.media = [...e], this.index = i, this.$GalleryEl = document.createElement("div"), t.appendChild(this.$GalleryEl)
    }
    load() {
        this.loadCSS(), this.fillHtmlIntoContainer(), this.getElement(), this.initEvent(), this.loaded = !0
    }
    getDevice() {
        this.isTouchDevice = ["mobile", "tablet"].includes(_pf_getDevice()), this.isTouchDevice ? this.limit = 5 : this.limit = 10
    }
    fillHtmlIntoContainer() {
        this.$GalleryEl.classList.add("pf-gallery-container", "pf-gallery-hide");
        var e = this.media.map((e, t) => _pf_MediaGallery.html.item(e.preview_image.src, t, e.media_type)).join("");
        this.$GalleryEl.innerHTML = _pf_MediaGallery.html.container(this.media[0].preview_image.src, e, this.media.length)
    }
    getElement() {
        var e = _pf_MediaGallery.selector;
        this.$master = this.$GalleryEl.querySelector(e.master), this.$masterImg = this.$master.querySelector("img"), this.$List = this.$GalleryEl.querySelector(e.list), this.$Items = this.$List.querySelectorAll(e.item), this.$hint = this.$GalleryEl.querySelector(e.hint)
    }
    initEvent() {
        this.isTouchDevice ? (this.$masterImg.addEventListener("touchstart", this.touchStartHandler.bind(this), {
            passive: !0
        }), this.$masterImg.addEventListener("touchmove", this.touchMoveHandler.bind(this)), this.$masterImg.addEventListener("touchend", this.touchEndHandler.bind(this)), this.$masterImg.addEventListener("click", this.touchEndHandler.bind(this)), this.handleSwipe()) : (this.$masterImg.addEventListener("mousedown", this.handleMouseDown.bind(this)), this.$masterImg.addEventListener("mouseup", this.handleMouseUp.bind(this))), this.$masterImg.addEventListener("load", this.onLoadedMasterImageHandler.bind(this)), this.$GalleryEl.addEventListener("click", this.handleClickEvent.bind(this))
    }
    handleMouseDown(e) {
        if (this.pointState.startX0 = e.pageX, this.pointState.startY0 = e.pageY, this.pointState.endX0 = e.pageX, this.pointState.endY0 = e.pageY, this.isZoom) {
            let e = this.moveZoomedImageOnDesktopHandler.bind(this);
            window.addEventListener("mousemove", e), window.addEventListener("mouseup", () => {
                window.removeEventListener("mousemove", e)
            })
        }
    }
    handleMouseUp(e) {
        this.pointState.endX0 === e.pageX && this.pointState.endY0 === e.pageY && this.toggleZoom()
    }
    moveZoomedImageOnDesktopHandler(e) {
        e.preventDefault(), this.updateStyleOnMovingZoomedImage({
            pageX: e.pageX,
            pageY: e.pageY
        })
    }
    touchStartHandler(e) {
        e.preventDefault(), 1 === e.touches.length && (this.pointState = { ...this.pointState,
            startX0: e.touches[0].pageX,
            startY0: e.touches[0].pageY
        }), 2 === e.touches.length && (this.pointState = { ...this.pointState,
            startX0: e.touches[0].pageX,
            startY0: e.touches[0].pageY,
            startX1: e.touches[1].pageX,
            startY1: e.touches[1].pageY
        })
    }
    touchMoveHandler(e) {
        e.preventDefault();
        var t = e.timeStamp - this.twoTouchesMoveTimeStamp < 300;
        1 === e.touches.length && 1 < this.transformState.scale && !t && this.updateStyleOnMovingZoomedImage({
            pageX: e.touches[0].pageX,
            pageY: e.touches[0].pageY
        }), 2 === e.touches.length && (this.twoTouchesMoveTimeStamp = e.timeStamp, this.updateStyleOnPinchingZoomingImage({
            pageX: e.touches[0].pageX,
            pageY: e.touches[0].pageY
        }, {
            pageX: e.touches[1].pageX,
            pageY: e.touches[1].pageY
        }))
    }
    touchEndHandler(e) {
        this.pointState = null
    }
    updateStyleOnMovingZoomedImage(e) {
        var t = this.getTranslateRange(),
            i = (e.pageX - this.pointState.startX0) / this.transformState.scale,
            a = (e.pageY - this.pointState.startY0) / this.transformState.scale;
        let r = i + this.transformState.transX,
            s = a + this.transformState.transY;
        Math.abs(r) > Math.abs(t.x) && (r = 0 < r ? t.x : -t.x), Math.abs(s) > Math.abs(t.y) && (s = 0 < s ? t.y : -t.y), this.$masterImg.style.transform = `scale(${this.transformState.scale}) translate(${r}px, ${s}px)`, this.transformState.transX = r, this.transformState.transY = s, this.pointState.startX0 = e.pageX, this.pointState.startY0 = e.pageY
    }
    updateStyleOnPinchingZoomingImage(e, t) {
        var i = this.getDistanceBetweenTwoPoints({
                point0: {
                    x: this.pointState.startX0,
                    y: this.pointState.startY0
                },
                point1: {
                    x: this.pointState.startX1,
                    y: this.pointState.startY1
                }
            }),
            a = this.getDistanceBetweenTwoPoints({
                point0: {
                    x: e.pageX,
                    y: e.pageY
                },
                point1: {
                    x: t.pageX,
                    y: t.pageY
                }
            }),
            a = Math.abs(a / i);
        let r = isNaN(a) ? this.transformState.scale : a * this.transformState.scale,
            s = this.transformState.transX,
            d = this.transformState.transY;
        (r = 8 < r ? 8 : r) < 1 && (r = r < .25 ? .25 : r, s = 0, d = 0), this.$masterImg.style.transform = `scale(${r}) translate(${s}px, ${d}px)`, this.transformState = {
            scale: r,
            transX: s,
            transY: d
        }, this.pointState = { ...this.pointState,
            startX0: e.pageX,
            startY0: e.pageY,
            startX1: t.pageX,
            startY1: t.pageY
        }
    }
    getDistanceBetweenTwoPoints(e) {
        var {
            point0: e,
            point1: t
        } = e, i = e.x - t.x, e = e.y - t.y;
        return Math.sqrt(Math.pow(i, 2) + Math.pow(e, 2))
    }
    getTranslateRange() {
        var {
            offsetWidth: e,
            offsetHeight: t
        } = this.$master, {
            width: i,
            height: a
        } = this.$masterImg;
        return {
            x: Math.floor(Math.abs(i * this.transformState.scale - e) / (2 * this.transformState.scale)),
            y: Math.floor(Math.abs(a * this.transformState.scale - t) / (2 * this.transformState.scale))
        }
    }
    turnOnZoom() {
        var e = _pf_MediaGallery.desktopScale;
        this.isZoom = !0, this.$master.style.width = "100%", this.$master.style.height = "100%", this.$masterImg.style.cursor = "move", this.$masterImg.style.transform = `scale(${e}) translate(0px, 0px)`, this.transformState = {
            scale: e,
            transX: 0,
            transY: 0
        }
    }
    turnOffZoom() {
        this.$master.style.removeProperty("width"), this.$master.style.removeProperty("height"), this.$masterImg.style.cursor = "zoom-in", this.$masterImg.style.transform = "none", this.transformState = {
            scale: 1,
            transX: 0,
            transY: 0
        }, this.isZoom = !1
    }
    toggleZoom() {
        this.isZoom ? this.turnOffZoom() : this.turnOnZoom()
    }
    show(e = -1) {
        this.loaded || this.load(), this.$GalleryEl.classList.remove("pf-gallery-hide"), document.querySelector("body").classList.add("pf-gallery-open"), -1 !== e && (this.setImage(e), this.scrollItemToView(e))
    }
    hide() {
        document.querySelector("body").classList.remove("pf-gallery-open"), this.$GalleryEl.classList.add("pf-gallery-hide"), this.turnOffZoom()
    }
    handleClickEvent(e) {
        e = e.target;
        e.closest(_pf_MediaGallery.selector.exit) ? this.hide() : e.closest(_pf_MediaGallery.selector.left) ? this.setImage(this.index - 1) : e.closest(_pf_MediaGallery.selector.right) ? this.setImage(this.index + 1) : e.closest(_pf_MediaGallery.selector.item) && this.handleClickItem(e)
    }
    handleSelectMedia(e) {
        var t = this.$master.querySelector(".video-wrapper");
        switch (t.innerHTML = "", e.media_type) {
            case "image":
                t.style.removeProperty("display"), t.style.removeProperty("width");
                break;
            case "model":
                var i = e.sources[0].url,
                    a = e.preview_image.src;
                i && _pf_loadModelViewer(t, i, a, e.alt), t.style.display = "block";
                break;
            case "video":
                i = _pf_getVideoSrcOfHighestQuality(e.sources);
                i && _pf_loadVideo(t, i), t.style.display = "block";
                break;
            case "external_video":
                var {
                    host: a,
                    external_id: i
                } = e;
                a && i && _pf_loadExternalVideo(t, a, i), t.style.display = "block"
        }
    }
    onLoadedMasterImageHandler(e) {
        this.$masterImg.style.display = "block"
    }
    setImage(e = 0) {
        if (e !== this.index) {
            e < 0 ? e = this.media.length - 1 : e >= this.media.length && (e = 0);
            for (let e = 0; e < this.$master.children.length - 1; e++) this.$master.children[e].style.display = "none";
            this.turnOffZoom(), "image" === this.media[e].media_type ? (this.$masterImg.src = this.media[e].preview_image.src, this.$hint.style.display = "block") : (this.$masterImg.style.display = "none", this.$hint.style.display = "none"), this.handleSelectMedia(this.media[e]), this.$Items[this.index].removeAttribute("data-active"), this.scrollItemToView(e), this.$Items[e].setAttribute("data-active", ""), this.index = e
        }
    }
    handleClickItem(e) {
        e = e.closest(_pf_MediaGallery.selector.item);
        e = Number.parseInt(e.getAttribute("data-index"));
        this.setImage(e)
    }
    scrollItemToView(e) {
        var t = this.$List;
        let i = this.$Items[e];
        var a = t.scrollLeft > i.offsetLeft,
            r = i.offsetLeft + i.offsetWidth > t.scrollLeft + t.offsetWidth;
        let s = null;
        if (a && (s = i.offsetLeft - .75 * i.offsetWidth, 0 === e) && (s = 0), r && (a = i.offsetLeft + i.offsetWidth - (t.scrollLeft + t.offsetWidth), s = t.scrollLeft + a + .5 * i.offsetWidth), null !== s && this.$List.scroll({
                left: s,
                behavior: "smooth"
            }), null === s && 0 === t.scrollLeft && 0 === i.offsetLeft && 0 !== e) {
            let e = null;
            e = setInterval(() => {
                i.offsetLeft && (clearInterval(e), this.$List.scroll({
                    left: i.offsetLeft - .75 * i.offsetWidth,
                    behavior: "smooth"
                }))
            }, 100)
        }
    }
    handleSwipe() {
        var e = this.$masterImg;
        let i = 70,
            a = {
                x: 0,
                time: 0
            },
            r = 0;
        e.addEventListener("touchstart", e => {
            this.transformState.scale <= 1 && 1 < e.touches.length && (r = e.timeStamp), this.transformState.scale <= 1 && e.changedTouches && (a = {
                x: e.changedTouches[0].clientX,
                time: e.timeStamp
            })
        }, {
            passive: !0
        }), e.addEventListener("touchend", e => {
            if (this.transformState.scale <= 1 && e.timeStamp - r < 500) return !1;
            var t;
            this.transformState.scale <= 1 && 1 === e.changedTouches ? .length && 0 === e.touches.length && (t = e.changedTouches[0].clientX - a.x, e.timeStamp - a.time < 500) && Math.abs(t) > i && (t > i && this.setImage(this.index - 1), t < -i) && this.setImage(this.index + 1)
        })
    }
    loadCSS() {
        var e = window.__pagefly_setting__,
            t = document.createElement("link");
        t.rel = "stylesheet", t.href = e.baseURL + "/static/assets/imageGallery.css?v=" + e.pageflyVersion, document.head.appendChild(t)
    }
}
_defineProperty(_pf_MediaGallery, "desktopScale", 2.5), _defineProperty(_pf_MediaGallery, "selector", {
    container: ".pf-gallery-container",
    master: ".pf-gallery-master",
    list: ".pf-gallery-list",
    item: ".pf-gallery-item",
    exit: ".pf-gallery-exit",
    arrow: ".pf-gallery-arrow",
    left: ".pf-left",
    right: ".pf-right",
    hint: ".pf-gallery-hint"
}), _defineProperty(_pf_MediaGallery, "classes", {
    hide: "pf-gallery-hide"
}), _defineProperty(_pf_MediaGallery, "html", {
    container: (e, t, i) => `
			<span class="pf-gallery-exit">&times;</span>
			<div class="pf-image-gallery">
				${1<i?`<span class="pf-gallery-arrow pf-left">${_pf_leftIcon}</span>
			  <span class="pf-gallery-arrow pf-right">${_pf_rightIcon}</span>`:""}
				<div class="pf-gallery-master">
				  <img draggable="false" src="${e}" alt="Master Image"/>
				  <div class="video-wrapper"></div>
				  <button class="pf-gallery-hint">Click or tap to zoom</button>
				 
				</div>
				<div class="pf-gallery-list">
					${t}
				</div>
			</div>

		`,
    item: (e, t, i) => `
			<div class="pf-gallery-item" data-index="${t}" ${0===t?"data-active":""} 
            ${"image"===i?"data-image":""}
      >
				<img src="${e}&width=450" alt="Image item" loading="lazy" decoding="async" fetchpriority="low"/>
				<span class="icon-indicator">
				  ${"model"===i?_pf_modelIcon:_pf_videoIcon}
        </span>
			</div>
		`
});
let _pf_videoTypes = {
        youtube: "https://www.youtube.com/embed/",
        vimeo: "https://player.vimeo.com/video/"
    },
    _pf_loadExternalVideo = (t, i, e) => {
        i = _pf_videoTypes[i] + e;
        let a = t.querySelector("iframe");
        if (a) a.setAttribute("src", i), a.classList.remove("pf-hidden");
        else {
            let e = document.createElement("iframe");
            e.src = i, e.style.border = "none", e.classList.add("featured-media"), t.prepend(e)
        }
    },
    _pf_loadVideo = (t, i) => {
        let e = t.querySelector("video");
        if (e) e.setAttribute("src", i), e.removeAttribute("poster"), e.classList.remove("pf-hidden");
        else {
            let e = document.createElement("video");
            e.src = i, e.setAttribute("controls", ""), e.classList.add("featured-media"), t.prepend(e)
        }
    },
    _pf_loadModelViewer = (t, i, a, r) => {
        window.Shopify.loadFeatures([{
            name: "model-viewer",
            version: "1.12"
        }]);
        let e = t.querySelector("model-viewer");
        if (e) e.setAttribute("poster", a), e.setAttribute("src", i), e.setAttribute("alt", r), e.classList.remove("pf-hidden");
        else {
            let e = document.createElement("model-viewer");
            e.loading = "eager", e.setAttribute("camera-controls", ""), e.setAttribute("poster", a), e.setAttribute("src", i), e.setAttribute("alt", r), e.classList.add("featured-media"), t.prepend(e)
        }
    },
    _pf_getVideoSrcOfHighestQuality = t => {
        let i = t[0];
        for (let e = 1; e < t.length; e++) t[e].format === t[0].format && t[e].height > i.height && (i = t[e]);
        return i.url
    },
    _pf_mainSlider2 = window.mainSlider2 = {},
    _pf_sliderList = window.sliderList = {},
    _pf_maximumQuantityToUseOldLayoutPagination = 7,
    _pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE = "accept-update-variant-by-image",
    _pf_handleReplaceTargetMediaToOriginalMedia = e => {
        var t, i = e ? .querySelector("template");
        i && (t = i.content, e ? .replaceChild(t.cloneNode(!0), e ? .firstElementChild), (t = e ? .firstElementChild ? .querySelector("video")) && (e = t.poster, t.poster = e), i.remove())
    },
    _pf_handleAddStyleScrollSnapType = e => {
        e.container && (e.container.style.scrollSnapType = "x mandatory")
    },
    _pf_handleScrollToDefaultVariant = (e, t, i, a) => {
        a.disableSlideshow && (_pf_handleOriginalRatioMainMediaStyleWhenTurnOffSlideshow2(e, a), 0 < i) && _pf_updateMainMediaWhenTurnOffSlideshow2(e, t, i - 1, !0)
    },
    _pf_updateImageByVariant2 = (e, t) => {
        var i = _pf_mainSlider2[e],
            e = _pf_sliderList[e];
        let a = t ? .featured_media ? .id;
        a && i && (t = (_pf_getFrontEndSettings(i.container ? .closest('[data-pf-type*="MediaMain"]')) || {}).disableSlideshow, t ? (t = i.container ? .closest(_pf_productMediaQueryString) ? .getAttribute("data-product-id"), _pf_updateMainMediaWhenTurnOffSlideshow2(i, e, _pf_pageflyProducts[t].media.findIndex(e => e.id === a), !0)) : ({
            slides: e,
            current: t
        } = i, e = e.findIndex(e => e.getAttribute("data-media-id") === a.toString()) + 1, isNaN(e) || Number(e) === Number(t) || (i.container ? .closest("." + _pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE) && i.container.setAttribute("data-no-move-again", "true"), i.goto(e))))
    },
    _pf_updateProductMediaOutsideBox2 = (e, t) => {
        e ? .length && e.forEach(e => {
            e = _pf_getProductMediaId2(e);
            _pf_updateImageByVariant2(e, t)
        })
    },
    _pf_getCurrentRatio = e => {
        var t = e[_pf_getDevice()];
        return "unset" === t ? e.all : t
    },
    _pf_mainSlider = window.mainSlider = {},
    _pf_subSlider = window.subSlider = {},
    _pf_dataCss = "@keyframes splide-loading{0%{transform:rotate(0)}to{transform:rotate(1turn)}}.splide__container{position:relative;box-sizing:border-box}.splide__list{margin:0!important;padding:0!important;width:-webkit-max-content;width:max-content;will-change:transform}.splide.is-active .splide__list{display:flex}.splide__pagination{display:flex;align-items:center;flex-wrap:wrap;justify-content:center;padding:0;margin:7px 0 0;}.splide__pagination li{list-style-type:none;line-height:1;}.splide{visibility:hidden}.splide,.splide__slide{position:relative;outline:none}.splide__slide{box-sizing:border-box;list-style-type:none!important;margin:0;flex-shrink:0}.splide__slide img{vertical-align:bottom}.splide__slider{position:relative}.splide__spinner{position:absolute;top:0;left:0;right:0;bottom:0;margin:auto;display:inline-block;width:20px;height:20px;border-radius:50%;border:2px solid #999;border-left-color:transparent;animation:splide-loading 1s linear infinite}.splide__track{position:relative;z-index:0;overflow:hidden}.splide--draggable>.splide__track>.splide__list>.splide__slide{-webkit-user-select:none;user-select:none}.splide--fade>.splide__track>.splide__list{display:block}.splide--fade>.splide__track>.splide__list>.splide__slide{position:absolute;top:0;left:0;z-index:0;opacity:0}.splide--fade>.splide__track>.splide__list>.splide__slide.is-active{position:relative;z-index:1;opacity:1}.splide--rtl{direction:rtl}.splide--ttb>.splide__track>.splide__list{display:block}.splide--ttb>.splide__pagination{width:auto}.splide__arrow{position:absolute;z-index:1;top:50%;transform:translateY(-50%);width:2em;height:2em;border-radius:2px;display:flex;align-items:center;justify-content:center;border:none;padding:0;opacity:.7;background:#ccc}.splide__arrow svg{width:1.2em;height:1.2em}.splide__arrow:hover{cursor:pointer;opacity:.9}.splide__arrow:focus{outline:none}.splide__arrow--prev{left:1em}.splide__arrow--prev svg{transform:scaleX(-1)}.splide__arrow--next{right:1em}.splide__pagination__page{display:inline-block;width:8px;height:8px;background:#d9d9d9;border-radius:50% !important;margin:3px;padding:0!important;min-height:initial!important;transition:transform .2s linear;border:none;opacity:.5;min-width:initial;box-shadow:initial;background-blend-mode: multiply;mix-blend-mode: exclusion;}.splide__pagination__page.is-active{transform:scale(1.4);opacity:1;}.splide__pagination__page:hover{cursor:pointer;opacity:1;box-shadow:initial;}.splide__pagination__page:focus{outline:none}.splide__progress__bar{width:0;height:3px;background:#d9d9d9}.splide--nav>.splide__track>.splide__list>.splide__slide{border:3px solid transparent}.splide--nav>.splide__track>.splide__list>.splide__slide.is-active{border-color:#000}.splide--nav>.splide__track>.splide__list>.splide__slide:focus{outline:none}.splide--rtl>.splide__arrows .splide__arrow--prev,.splide--rtl>.splide__track>.splide__arrows .splide__arrow--prev{right:1em;left:auto}.splide--rtl>.splide__arrows .splide__arrow--prev svg,.splide--rtl>.splide__track>.splide__arrows .splide__arrow--prev svg{transform:scaleX(1)}.splide--rtl>.splide__arrows .splide__arrow--next,.splide--rtl>.splide__track>.splide__arrows .splide__arrow--next{left:1em;right:auto}.splide--rtl>.splide__arrows .splide__arrow--next svg,.splide--rtl>.splide__track>.splide__arrows .splide__arrow--next svg{transform:scaleX(-1)}.splide--ttb>.splide__arrows .splide__arrow,.splide--ttb>.splide__track>.splide__arrows .splide__arrow{left:50%;transform:translate(-50%)}.splide--ttb>.splide__arrows .splide__arrow--prev,.splide--ttb>.splide__track>.splide__arrows .splide__arrow--prev{top:1em}.splide--ttb>.splide__arrows .splide__arrow--prev svg,.splide--ttb>.splide__track>.splide__arrows .splide__arrow--prev svg{transform:rotate(-90deg)}.splide--ttb>.splide__arrows .splide__arrow--next,.splide--ttb>.splide__track>.splide__arrows .splide__arrow--next{top:auto;bottom:1em}.splide--ttb>.splide__arrows .splide__arrow--next svg,.splide--ttb>.splide__track>.splide__arrows .splide__arrow--next svg{transform:rotate(90deg)}.splide--ttb>.splide__pagination{display:flex;flex-direction:column;bottom:50%;left:auto;right:.5em;transform:translateY(50%)}",
    _pf_setActiveItemOnGridMode = (i, e) => {
        e && e.length && e.forEach((e, t) => {
            i !== t ? e.removeAttribute("data-active") : e.setAttribute("data-active", "true")
        })
    },
    _pf_updateImageByVariant = (e, t) => {
        var i = _pf_mainSlider[e],
            e = _pf_subSlider[e];
        let a = t ? .featured_media ? .id;
        a && i && (t = (i ? .Components.Elements.getSlides()).find(e => e.slide.getAttribute("data-media-id") === a.toString()) ? .index, isNaN(t) || (i.root ? .closest("." + _pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE) && i.root.setAttribute("data-no-move-again", "true"), i.go(t), e && e.go(t)))
    },
    _pf_updateVariantByImage = (e, t) => {
        var i = parseInt(e.getAttribute("data-product-id")),
            a = e.closest('[data-pf-type="ProductBox"]'),
            a = a && a.className,
            r = _pf_getElemIdByClassname(a),
            s = _pf_pageflyProducts[i],
            r = s ? .pfCurrentVariant ? .[r || _pf_OUTSIDE_BOX_KEY] ? .id,
            s = s ? .variants || [];
        let d = t ? .slide ? .dataset ? .mediaId;
        t = s.find(e => e.featured_media ? .id === d);
        r !== t ? .id && t && _pf_updateByCurrentVariant(i, t, a, !1, !0, e)
    },
    _pf_updateProductMediaOutsideBox = (e, t) => {
        e ? .length && e.forEach(e => {
            e = _pf_getProductMediaId(e);
            _pf_updateImageByVariant(e, t)
        })
    },
    _pf_updateARButton = (e, t) => {
        e.querySelector(".pf-ar-btn") ? .setAttribute("data-shopify-model3d-id", t)
    },
    _pf_showARButton = e => {
        e = e ? .querySelector(".pf-ar-btn-wrapper");
        e && e.classList.contains("pf-ar-compatible") && e.classList.remove("pf-ar-btn-hidden")
    },
    _pf_moved = !1,
    _pf_firstLoading = !1;
window.mediaGallery = {};
let _pf_activeVideo, _pf_defaultIndexActive;

function _pf_getProductMediaId2(e) {
    e = e ? .closest(_pf_productMediaQueryString);
    return _pf_getElemIdByClassname(e ? .className) + e ? .getAttribute("data-product-id") + "_" + e ? .getAttribute("data-media-id")
}
async function _pf_handleShopifyProductMedia2(e) {
    let c = _pf_getDevice();
    e = (e || document).querySelectorAll(_pf_productMediaQueryString);
    if (window.SnapSlider) {
        for (let f of e) {
            var u = _pf_getProductMediaId2(f);
            let _ = f.querySelector(".product-media2-inner");
            if (!_pf_isElementInsideHiddenTabs(f)) {
                let t = f.querySelector('[data-pf-type*="MediaMain"]');
                var m = f.querySelector('[data-pf-type="MediaList2"]'),
                    h = f.querySelector('[data-pf-type*="MediaMain"] .pf-media-slider'),
                    g = f.querySelector('[data-pf-type="MediaList2"] .pf-media-slider');
                let i = _pf_getFrontEndSettings(t),
                    a = _pf_getFrontEndSettings(m),
                    {
                        navStyle: r,
                        paginationStyle: s
                    } = i,
                    {
                        navStyle: d,
                        listLayout: e = {}
                    } = a,
                    o = e[c] === _pf_LIST_LAYOUT.SLIDE;
                m = h.querySelectorAll(".pf-slide-main-media");
                let n = _pf_getIndexOfUserDefaultSource(f, m),
                    l = (0 === n && _.classList.remove("product-media-loading"), _pf_handleReplaceTargetMediaToOriginalMedia(h), new window.SnapSlider(h, {
                        id: h.getAttribute("data-id"),
                        slides: ".pf-slide-main-media",
                        start: n,
                        on: {
                            load: e => {
                                _pf_handleAddStyleScrollSnapType(e), _pf_initVisibleObservers(e), _pf_handleSlidesScrollStop(e, i, c), _pf_handleHoverMedia2(e, t, i), _pf_handleOpenMediaGallery2(e, i, f), _pf_handleNavigationButtons(e, i, c, !1, _pf_sliderList), _pf_handlePaginationButtons(e, i, c), ["pagination-style-2", "pagination-style-3"].includes(s) && e.slides.length > _pf_maximumQuantityToUseOldLayoutPagination && _pf_handlePaginationButtonsWithNumberOfVariantsRemaining(e, i, c), _pf_handleClickMediaMain(e), _pf_updateActiveSlide2(e), _pf_handleScrollToDefaultVariant(e, _pf_sliderList, n, i)
                            },
                            "scroll.end": e => {
                                _pf_updateActiveSlide2(e, p), _pf_handleChangeMainMedia2(e, f), "none" !== r && _pf_updateNavigationButtonsState(e, i, c), "none" !== s && _pf_updatePaginationButtonsState(e, i, c), ["pagination-style-2", "pagination-style-3"].includes(s) && e.slides.length > _pf_maximumQuantityToUseOldLayoutPagination && _pf_updatePaginationButtonsWithNumberOfVariantsRemainingState(e), "none" !== d && o && _pf_updateNavigationButtonsState(p, a, c), _.classList.remove("product-media-loading")
                            }
                        }
                    })),
                    p = new window.SnapSlider(g, {
                        id: g.getAttribute("data-id"),
                        slides: ".pf-slide-list-media",
                        start: n,
                        on: {
                            load: e => {
                                o && _pf_handleAddStyleScrollSnapType(e), o && _pf_initVisibleObservers(e), o && _pf_handleSlidesScrollStop(e, a, c), o && _pf_handleNavigationButtons(l, a, c, !0, e), _pf_handleClickOnSliderMode(e, i, a, l, c), _pf_updateActiveSlide2(e), _pf_handleScrollToDefaultVariant(l, e, n, i)
                            },
                            "scroll.end": e => {
                                "none" !== d && o && _pf_updateNavigationButtonsState(e, a, c), _.classList.remove("product-media-loading")
                            }
                        }
                    });
                window.mainSlider2[u] = l, window.sliderList[u] = p
            }
        }
        _pf_shouldLoadShopifyXR() && _pf_loadShopifyXr()
    }
}

function _pf_getIndexOfUserDefaultSource(e, t) {
    var i = e.getAttribute("data-product-id"),
        a = e.closest('div[data-pf-type="ProductBox"]'),
        i = _pf_pageflyProducts[i],
        {
            media: r = []
        } = i || {},
        e = _pf_getFrontEndSettings(e) ? .imageSource || "featured",
        s = window.location.search;
    let d = new URLSearchParams(s).get("variant");
    if ("default-variant" === e && a && !d) {
        let t = a.getAttribute("data-default-variant");
        return i ? .variants ? .find(e => e.id == t) ? .featured_media ? .position
    }
    s = d ? i ? .variants ? .findIndex(e => e.id.toString() === d) : -1;
    let o = i ? .variants[0 < s ? s : 0];
    return ("variant" === e || 0 <= s) && o && o ? .featured_media && (a = r.findIndex(e => {
        e = e.id;
        return o.featured_media.id === e
    })) ? a + 1 : 0
}

function _pf_handleOpenMediaGallery2(e, t, s) {
    e = e.slides;
    let d = t ? .disableSlideshow;
    t ? .clickAction === _pf_CLICK_ACTION.SHOW_FULLSCREEN && e.forEach((a, r) => {
        a.addEventListener("click", () => {
            if ("image" === a.getAttribute("data-media-type")) {
                var t = s.getAttribute("data-product-id"),
                    i = _pf_pageflyProducts[t].media;
                window.mediaGallery[t] || (window.mediaGallery[t] = new _pf_MediaGallery(i, document.body));
                let e = r;
                if (d) {
                    let t = a.getAttribute("data-media-id");
                    e = i.findIndex(e => e ? .id === +t)
                }
                window.mediaGallery[t].show(e)
            }
        })
    })
}

function _pf_handleChangeMainMedia2(e, t) {
    var i, a = e.current - 1,
        a = e.slides[a],
        r = a.getAttribute("data-media-type");
    t ? .className ? .includes(_pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE) && (i = {
        slide: {
            dataset: {
                mediaId: a ? .getAttribute("data-media-id")
            }
        }
    }, e.container.getAttribute("data-no-move-again") || _pf_updateVariantByImage(t, i), e.container.removeAttribute("data-no-move-again")), "model" === r ? (i = a.getAttribute("data-media-id"), _pf_updateARButton(t, i), _pf_showARButton(t), _pf_isTouchDevice || a.querySelector(".pf-mask").classList.add("pf-hidden")) : _pf_hideARButton(t), "external_video" === r && _pf_togglePlayExternalVideo("pause", (e = a.querySelector(".pf-media-wrapper")).querySelector("iframe"), e.getAttribute("data-video-host"))
}

function _pf_handleClickMediaMain(e) {
    e = e.slides;
    e.forEach(a => {
        a.registeredClickEvent || (a.registeredClickEvent = !0, a.addEventListener("click", () => {
            var e, t, i = a.getAttribute("data-media-type");
            "model" === i && _pf_isTouchDevice ? (t = a.querySelector(".pf-mask")).classList.contains("pf-hidden") ? t.classList.remove("pf-hidden") : t.classList.add("pf-hidden") : "external_video" === i && (i = (t = a.querySelector(".pf-media-wrapper")).querySelector("iframe"), e = t.querySelector(".pf-mask-iframe"), t = t.getAttribute("data-video-host"), "false" === e.getAttribute("data-play") ? (e.setAttribute("data-play", "true"), _pf_togglePlayExternalVideo("play", i, t)) : (e.setAttribute("data-play", "false"), _pf_togglePlayExternalVideo("pause", i, t)))
        }))
    })
}

function _pf_handleClickOnSliderMode(a, e, r, s, d) {
    let o = e ? .disableSlideshow;
    a ? .slides.forEach((e, i) => {
        e.addEventListener("mousedown", e => {
            e.stopPropagation(), "none" !== r ? .paginationStyle && _pf_updatePaginationButtonsState(s, r, d, i + 1), a.slides.find(e => e.getAttribute("data-active")) ? .removeAttribute("data-active") ? .setAttribute("aria-hidden", !0), a.slides[i].setAttribute("data-active", !0), a.slides[i].removeAttribute("aria-hidden");
            var e = "none" !== r.navStyle,
                t = r.listLayout ? .[d] === _pf_LIST_LAYOUT.SLIDE;
            e && t && _pf_updateNavigationButtonsState(a, r, d), o ? _pf_updateMainMediaWhenTurnOffSlideshow2(s, a, i, !1) : s.goto(i + 1)
        })
    })
}

function _pf_handleFindModelOrVideo2(e) {
    return e.find(e => e.classList.contains("is-current")).querySelector(".pf-media-wrapper")
}

function _pf_handleMagnifierMedia2(e, t) {
    e = e.slides;
    e.forEach(e => {
        "image" !== e.getAttribute("data-media-type") && !t || _pf_initZoomImage2(e)
    })
}

function _pf_changeProductMediaOnly2(e, t, i) {
    var a, r;
    t !== i && (a = e[t].querySelector("img"), r = e[i].querySelector("img"), a) && r && (_pf_moved = !0, e[t].appendChild(r), e[i].appendChild(a))
}

function _pf_handleHoverMedia2(e, o, n) {
    let l = e.slides;
    if (!_pf_isTouchDevice && n.hoverAction !== _pf_HOVER_ACTION.NONE) {
        let s = e.current - 1,
            d = (e, t) => e === t ? 0 : e + 1;
        o.onmouseenter = function() {
            if (!_pf_moved) {
                let t = e.current - 1,
                    i = t,
                    a = t;
                var r = l.length - 1;
                if (n.hoverAction === _pf_HOVER_ACTION.HOVER && 1 < l.length && !_pf_handleFindModelOrVideo2(l)) switch (n.onHover) {
                    case _pf_ON_HOVER.NEXT_IMAGE:
                        for (a = t < r ? 1 + t : 0;
                            "image" !== l[a].getAttribute("data-media-type") || i === a;) a = a < r ? a + 1 : 0;
                        _pf_changeProductMediaOnly2(l, t, a), i = a;
                        break;
                    case _pf_ON_HOVER.LAST_IMAGE:
                        for (a = r; !("image" === l[a].getAttribute("data-media-type") && 0 !== a || (a = a === t ? a - 2 : a - 1) < 0););
                        _pf_changeProductMediaOnly2(l, t, a), i = a;
                        break;
                    case _pf_ON_HOVER.RANDOM_IMAGE:
                        for (; a = Math.floor(Math.random() * l.length), "image" !== l[a].getAttribute("data-media-type") || i === a;);
                        _pf_changeProductMediaOnly2(l, t, a), i = a;
                        break;
                    case _pf_ON_HOVER.ALL_IMAGE:
                        a = d(s, r);
                        let e = 0;
                        for (;
                            (a === t || "image" !== l[a].getAttribute("data-media-type")) && (a = d(a, r), ++e !== l.length););
                        _pf_changeProductMediaOnly2(l, t, a), s = a
                } else n.hoverAction === _pf_HOVER_ACTION.MAGNIFIER && _pf_handleMagnifierMedia2(e, n.disableSlideshow);
                o.onmouseleave = function() {
                    n.hoverAction === _pf_HOVER_ACTION.HOVER && (n.onHover === _pf_ON_HOVER.ALL_IMAGE ? _pf_changeProductMediaOnly2(l, s, t) : _pf_changeProductMediaOnly2(l, i, t), _pf_moved = !1)
                }
            }
        }
    }
}

function _pf_handleNavigationButtons(a, r, s, d = !1, o) {
    var e = (d ? o : a) ? .container,
        t = e.querySelector(".pf-slider-prev"),
        e = e.querySelector(".pf-slider-next");
    let n = (_pf_getFrontEndSettings(a.container ? .closest('[data-pf-type*="MediaMain"]')) || {}).disableSlideshow;
    "none" !== r ? .navStyle && _pf_updateNavigationButtonsState(d ? o : a, r, s), e ? .addEventListener("click", e => {
        if (e.stopPropagation(), !e.detail || 1 === e.detail)
            if (n && d && o) {
                var t = o.slides,
                    i = t.length;
                let e = t.findIndex(e => e.getAttribute("data-active")) + r ? .slidesToScroll[s];
                e >= i && (e = i - 1), _pf_updateMainMediaWhenTurnOffSlideshow2(a, o, e, !0)
            } else {
                t = a.slides.length;
                if (a.current < t || !e.detail || 1 === e.detail) {
                    let e = a.current + r ? .slidesToScroll[s];
                    e > t && (e = t), "none" !== r ? .paginationStyle && _pf_updatePaginationButtonsState(a, r, s, e), a.goto(e)
                }
            }
    }), t ? .addEventListener("click", t => {
        if (t.stopPropagation(), !t.detail || 1 === t.detail)
            if (n && d && o) {
                t = o.slides;
                let e = t.findIndex(e => e.getAttribute("data-active")) - r ? .slidesToScroll[s];
                e < 0 && (e = 0), _pf_updateMainMediaWhenTurnOffSlideshow2(a, o, e, !0)
            } else if (1 < a.current) {
            let e = a.current - r ? .slidesToScroll[s];
            e < 1 && (e = 1), "none" !== r ? .paginationStyle && _pf_updatePaginationButtonsState(a, r, s, e), a.goto(e)
        }
    })
}

function _pf_updateActiveSlide2(e, i) {
    e = e.slides;
    let a = (i || {}).slides;
    e ? .forEach((e, t) => {
        e.classList.contains("is-current") ? (e.setAttribute("data-active", !0), a && (a[t].setAttribute("data-active", !0), a[t].classList.contains("is-visible") || i.goto(t + 1))) : (e.removeAttribute("data-active"), a && a[t].removeAttribute("data-active"))
    })
}

function _pf_handleOriginalRatioMainMediaStyleWhenTurnOffSlideshow2(e, t) {
    var i;
    "original" === _pf_getCurrentRatio(t.ratio) && (e = (t = e.container).querySelector(".variant-image"), i = t.querySelector(".pf-media-wrapper"), t = t ? .closest(_pf_productMediaQueryString) ? .getAttribute("data-product-id"), t = (_pf_pageflyProducts[t] ? .media) ? .[0]) && (e.style.aspectRatio = t.preview_image.aspect_ratio, e.style.objectFit = "contain", e.style.objectPosition = "center top", i.style.paddingBottom = 100 / t.preview_image.aspect_ratio + "%")
}

function _pf_updateMainMediaWhenTurnOffSlideshow2(e, t, a, i = !1) {
    i && t && t ? .slides && (t.slides.forEach((e, t) => {
        var i = "true" === e.getAttribute("data-active");
        t !== a || i ? t !== a && i && e.removeAttribute("data-active") : e.setAttribute("data-active", !0)
    }), t.goto(a + 1));
    var i = e.container,
        t = i.querySelector(".variant-image"),
        r = i.querySelector(".pf-media-wrapper"),
        e = i.querySelector(".pf-slide-main-media"),
        i = i ? .closest(_pf_productMediaQueryString) ? .getAttribute("data-product-id"),
        s = _pf_pageflyProducts[i].media[a];
    if (e.setAttribute("data-media-id", s.id), e.setAttribute("data-media-type", s.media_type), "image" === s.media_type) t.src.includes(s.src) || (i = t.src ? .includes("https") ? t.src ? .split("https:")[1] : t.src, t.alt = s.alt, t.width = s.width, t.height = s.height, t.srcset = t.srcset ? .replaceAll(i ? .split("width") ? .[0], s.src), t.src = s.src), r.style.display = "none", t.style.display = "block";
    else switch (t.style.display = "none", r.style.display = "block", r.innerHTML = "", s.media_type) {
        case "model":
            var d = (s.sources ? .find(e => "glb" === e.format)) ? .url,
                o = s.preview_image.src;
            d && _pf_loadModelViewer(r, d, o, s.alt);
            break;
        case "video":
            d = s.sources[0].url;
            d && _pf_loadVideo(r, d);
            break;
        case "external_video":
            var {
                host: o,
                external_id: d
            } = s;
            o && d && _pf_loadExternalVideo(r, o, d)
    }
}

function _pf_getProductMediaId(e) {
    e = e ? .closest('[data-pf-type="ProductMedia"]');
    return _pf_getElemIdByClassname(e ? .className) + e.getAttribute("data-product-id") + "_" + e.getAttribute("data-media-id")
}

function _pf_isElementInsideHiddenTabs(t) {
    if (t.closest('[data-pf-type="Tabs"]')) {
        let e = t.parentElement;
        for (; e;) {
            var i = getComputedStyle(e).display;
            if ("none" === i) return !0;
            if ("Tabs" === e.dataset.pfType) return !1;
            e = e.parentElement
        }
        return !1
    }
}
async function _pf_handleShopifyProductMedia(e) {
    let t;
    for (let s of t = (e || document).querySelectorAll('[data-pf-type="ProductMedia"]')) {
        let r = _pf_getProductMediaId(s);
        _pf_isElementInsideHiddenTabs(s) || await _pf_initSlider(s, (e, t, i, a) => {
            i && _pf_handleUpdateImageHeight(s, i), _pf_handleChangeMainMedia(s, e, t, i), _pf_handleClickMediaItem(s, t, i, a).catch(e => console.log(e)), _pf_handleHoverMedia(s, e, t), _pf_handleOpenMediaGallery(s, t), window.mainSlider[r] = t, window.subSlider[r] = i, _pf_handleDefaultSource(s), i && _pf_handleShowArrow(s)
        })
    }
    _pf_shouldLoadShopifyXR() && _pf_loadShopifyXr()
}

function _pf_shouldLoadShopifyXR() {
    var e = ["tablet", "mobile"].includes(_pf_getDevice()),
        t = document.querySelectorAll(".pf-ar-btn-wrapper");
    return !(!e || !t.length || !_pf_checkARCompatible(_pf_getMobileOS()) || (t.forEach(e => {
        e.classList.add("pf-ar-compatible")
    }), 0))
}

function _pf_loadShopifyXr() {
    window.Shopify.loadFeatures([{
        name: "shopify-xr",
        version: "1.0",
        onLoad: function e() {
            if (window.ShopifyXR) {
                let t = [];
                document.querySelectorAll('.pf-ar-btn-wrapper.pf-ar-compatible [id^="ModelJSON-"]').forEach(e => {
                    t.push(JSON.parse(e.textContent)), e.remove()
                }), window.ShopifyXR.addModels(t), window.ShopifyXR.setupXRElements()
            } else document.addEventListener("shopify_xr_initialized", function() {
                e()
            })
        }
    }])
}

function _pf_handleShowArrow(e) {
    var t = _pf_getFrontEndSettings(e) ? .limit || {
            all: 5,
            laptop: 5,
            tablet: 5,
            mobile: 5
        },
        i = _pf_getDevice(),
        e = e.querySelector('[data-pf-type="ProductMediaList"]'),
        a = e.querySelector(".splide__arrows");
    e.querySelectorAll(".splide__track .splide__list .splide__slide").length <= t[i] && a.classList.add("pf-hidden")
}

function _pf_handleUpdateImageHeight(e, t) {
    var i, e = _pf_getFrontEndSettings(e) ? .spacing || {
            all: "10px",
            laptop: "10px",
            tablet: "10px",
            mobile: "10px"
        },
        a = _pf_getDevice();
    t.Components.Elements.getSlides().length && (i = t.options.perPage, e = parseInt(t.Components.Elements.getSlide(0).slide.style.width) - parseInt(e[a]) * (i - 1) / i, t.options = { ...t.options,
        fixedWidth: e,
        fixedHeight: e
    }, e) && t.emit("updated")
}

function _pf_handleDefaultSource(e) {
    var t = e.getAttribute("data-product-id");
    let i = _pf_pageflyProducts[t].variants[0];
    var t = _pf_getFrontEndSettings(e) ? .imageSource || "featured",
        e = _pf_getProductMediaId(e),
        a = _pf_mainSlider[e],
        e = _pf_subSlider[e];
    "variant" === t && i && i ? .featured_media ? (t = (a ? .Components.Elements.getSlides()).find(e => e.slide.getAttribute("data-media-id") === i.featured_media.id.toString()), t = isNaN(t ? .index) ? 0 : t.index, a.go(t), e && e.go(t)) : (a.go(0), e && e.go(0))
}
async function _pf_initSlider(t, i) {
    if (window.Splide || (a = document.createElement("style"), document.head.appendChild(a), a.appendChild(document.createTextNode(_pf_dataCss)), await _pf_loadJS("https://cdn.jsdelivr.net/npm/@splidejs/splide@2.4.21/dist/js/splide.min.js", document.body, !1, !0)), window.Splide) {
        var a = t.querySelector('[data-pf-type="MainMedia"] .splide'),
            r = a.querySelector(".splide__pagination");
        r && r.remove();
        let e = t.querySelector('[data-pf-type="ProductMediaList"] > div');
        r = new window.Splide(a, {
            type: "fade",
            arrows: !1,
            drag: !1,
            keyboard: !1
        });
        _pf_onMounted(a, r), _pf_onPaginationMounted(r), r.mount(), e ? e.getAttribute("data-splide") ? ((t = new window.Splide(e, {
            type: "slide",
            perMove: 1,
            pagination: !1,
            drag: !1
        })).on("arrows:mounted", function() {
            e && e.parentNode.classList.remove("pf-splide-loading")
        }), t.mount(), i(a, r, t, e)) : (e.parentNode.classList.remove("pf-splide-loading"), i(a, r, null, e)) : i(a, r)
    }
}

function _pf_handleOpenMediaGallery(a, e) {
    (_pf_getFrontEndSettings(a) || {}).clickAction === _pf_CLICK_ACTION.SHOW_FULLSCREEN && e.on("click", e => {
        var t, i;
        "image" === e.slide.getAttribute("data-media-type") && (t = a.getAttribute("data-product-id"), i = _pf_pageflyProducts[t].media, window.mediaGallery[t] || (window.mediaGallery[t] = new _pf_MediaGallery(i, document.body)), window.mediaGallery[t].show(e.index))
    })
}

function _pf_updateSplideSettings(e, t) {
    _pf_isTouchDevice && (e.options = { ...e.options,
        ...t
    }, e.emit("updated"), console.log("splide update", e.options))
}

function _pf_togglePlayExternalVideo(e, t, i) {
    "vimeo" === i ? t.contentWindow.postMessage({
        method: e
    }, _pf_VIMEO_ORIGIN) : "play" === e ? t.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', _pf_YOUTUBE_ORIGIN) : t.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', _pf_YOUTUBE_ORIGIN)
}

function _pf_handleChangeMainMedia(a, r, s, i) {
    s.on("move", e => {
        var t;
        isNaN(e) && (e = 0), _pf_isTouchDevice ? i && i.go(e) : (t = r ? .parentNode.querySelector('[data-pf-type="ProductMediaList"]')) && (t = Array.from(t ? .querySelectorAll('[data-pf-type="MediaItem"]')), _pf_setActiveItemOnGridMode(e, t))
    }), s.on("moved", e => {
        isNaN(e) && (e = 0);
        var t = s.Components.Elements.getSlide(e),
            i = t ? .slide.getAttribute("data-media-type"),
            e = (s && r && _pf_firstLoading && _pf_setDynamicHeight(s, r, e), _pf_firstLoading = !0, a ? .className ? .includes(_pf_ACCEPT_UPDATE_VARIANT_BY_IMAGE));
        e && (s.root.getAttribute("data-no-move-again") || _pf_updateVariantByImage(a, t), s.root.removeAttribute("data-no-move-again")), ("model" === i ? (e = t.slide.getAttribute("data-media-id"), _pf_updateARButton(a, e), _pf_showARButton) : _pf_hideARButton)(a), "model" !== i || _pf_isTouchDevice ? "external_video" === i ? _pf_activeVideo = t.slide : (_pf_activeVideo && _pf_togglePlayExternalVideo("pause", (e = _pf_activeVideo.querySelector(".pf-media-wrapper")).querySelector("iframe"), e.getAttribute("data-video-host")), s.options.drag || _pf_updateSplideSettings(s, {
            drag: !0
        })) : t.slide.querySelector(".pf-mask").classList.add("pf-hidden")
    }), s.on("click", e => {
        var t, i = e.slide.getAttribute("data-media-type");
        "model" === i && _pf_isTouchDevice ? (t = e.slide.querySelector(".pf-mask"), s.options.drag ? t.classList.add("pf-hidden") : t.classList.remove("pf-hidden"), _pf_updateSplideSettings(s, {
            drag: !s.options.drag
        })) : "external_video" === i ? (i = (t = e.slide.querySelector(".pf-media-wrapper")).querySelector("iframe"), e = t.querySelector(".pf-mask-iframe"), t = t.getAttribute("data-video-host"), "false" === e.getAttribute("data-play") ? (e.setAttribute("data-play", "true"), _pf_togglePlayExternalVideo("play", i, t)) : (e.setAttribute("data-play", "false"), _pf_togglePlayExternalVideo("pause", i, t))) : s.options.drag || _pf_updateSplideSettings(s, {
            drag: !0
        })
    })
}

function _pf_setDynamicHeight(e, t, i) {
    var i = e.Components.Elements.getSlide(i) ? .slide || t.querySelector(".splide__slide.is-active"),
        a = _pf_getDevice();
    t.closest('[data-pf-type="MainMedia"]').classList.contains({
        all: "pf-lg-media-fixed-height",
        laptop: "pf-md-media-fixed-height",
        tablet: "pf-sm-media-fixed-height",
        mobile: "pf-media-fixed-height"
    }[a]) || (t = i.getBoundingClientRect().height, (a = e.Components.Elements.list).style.height = t + "px", a.style.transition = "height 0.5s ease")
}

function _pf_onMounted(t, i) {
    i.on("mounted", () => {
        var e = i.Components.Elements.getSlide(i.index);
        _pf_isTouchDevice ? _pf_updateSplideSettings(i, {
            drag: !0
        }) : "model" === e.slide.getAttribute("data-media-type") && e.slide.querySelector(".pf-mask").classList.add("pf-hidden"), t.parentNode.style.removeProperty("--ratio"), t.parentNode.classList.remove("pf-splide-loading")
    })
}

function _pf_onPaginationMounted(e) {
    e.on("pagination:mounted", e => {
        1 === e.items.length && (e.list.style.visibility = "hidden"), (e.list.querySelectorAll("li") || []).forEach(e => {
            e.addEventListener("click", function(e) {
                e.stopPropagation()
            })
        })
    })
}
async function _pf_handleClickMediaItem(e, i, a, t) {
    !a && t ? Array.from(t ? .querySelectorAll('[data-pf-type="MediaItem"]')).forEach((e, t) => {
        e.addEventListener("click", () => {
            i.go(t)
        })
    }) : a && (a.on("inactive", e => {
        e.slide.removeAttribute("data-active")
    }), a.on("click", e => {
        var t = i ? .index;
        a ? .Components ? .Elements ? .slides[t] ? .removeAttribute("data-active"), e.slide.setAttribute("data-active", "true"), i.go(e.index), a.go(e.index)
    }), a.on("move", e => {
        i.go(e), a.go(e), a.Components.Elements.getSlide(e) ? .slide.setAttribute("data-active", "true")
    }))
}

function _pf_handleFindModelOrVideo(e) {
    return e.Components.Elements.track.querySelector(".is-active").querySelector(".pf-media-wrapper")
}

function _pf_handleMagnifierMedia(e, t) {
    (_pf_getFrontEndSettings(e) || {}).hoverAction === _pf_HOVER_ACTION.MAGNIFIER && t.Components.Elements.slides.forEach(e => {
        "image" === e.getAttribute("data-media-type") && _pf_initZoomImage2(e)
    })
}

function _pf_changeProductMediaOnly(e, t, i) {
    e[t].classList.remove("is-active", "is-visible"), e[i].classList.add("is-active", "is-visible")
}

function _pf_handleHoverMedia(s, d, o) {
    let n = _pf_getFrontEndSettings(s) || {},
        l = [];
    if (d.querySelectorAll(".splide__slide").forEach((e, t) => {
            "image" === e.getAttribute("data-media-type") && l.push(t)
        }), !_pf_isTouchDevice && n.hoverAction !== _pf_HOVER_ACTION.NONE) {
        let a = o.index,
            r = (e, t) => e === t ? 0 : e + 1;
        d.onmouseenter = function() {
            let e = d.querySelectorAll(".splide__slide"),
                t = _pf_defaultIndexActive = o.index,
                i = l.length - 1;
            if (n.hoverAction === _pf_HOVER_ACTION.HOVER && 1 < l.length) {
                if (_pf_handleFindModelOrVideo(o)) return;
                n.onHover === _pf_ON_HOVER.NEXT_IMAGE ? (t = l.indexOf(_pf_defaultIndexActive) + 1 <= i ? l.indexOf(_pf_defaultIndexActive) + 1 : 0, _pf_changeProductMediaOnly(e, _pf_defaultIndexActive, l[t])) : n.onHover === _pf_ON_HOVER.LAST_IMAGE ? l.includes(_pf_defaultIndexActive) && (t = l.indexOf(_pf_defaultIndexActive), _pf_changeProductMediaOnly(e, a, l[0 === t ? i : t - 1])) : n.onHover === _pf_ON_HOVER.RANDOM_IMAGE ? (t = Math.floor(Math.random() * l.length), _pf_changeProductMediaOnly(e, a, l[t])) : ((t = r(a, i)) === _pf_defaultIndexActive && (t = r(t, i)), _pf_changeProductMediaOnly(e, o.index, l[t]), a = t)
            } else _pf_handleMagnifierMedia(s, o);
            d.onmouseleave = function() {
                n.hoverAction === _pf_HOVER_ACTION.HOVER && (n.onHover === _pf_ON_HOVER.LAST_IMAGE ? _pf_changeProductMediaOnly(e, l[0 === t ? i : t - 1], a) : _pf_changeProductMediaOnly(e, l[t], o.index))
            }
        }
    }
}

function _pf_hideARButton(e) {
    e = e ? .querySelector(".pf-ar-btn-wrapper");
    e && e.classList.add("pf-ar-btn-hidden")
}
_pf_handleShopifyProductMedia().catch(console.warn);