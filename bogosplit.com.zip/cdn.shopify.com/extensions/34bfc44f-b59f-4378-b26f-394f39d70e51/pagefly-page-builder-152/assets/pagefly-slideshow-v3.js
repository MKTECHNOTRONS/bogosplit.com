let _pf_OBSERVATIONAL_ERROR_VALUE = 30,
    _pf_numberOfVisiblePaginationItemInNewLayout = 5,
    _pf_getCurrentIndex = (e, t, i) => t.displayPartialItems && t.displayPartialItems[i] ? (t = e.slides.findIndex(e => e.classList.contains("is-visible")), Math.max(t + 1, 1)) : Number(e.current || 1),
    _pf_getNextSlideIndex = (e, t, i) => {
        var {
            slidesToShow: t,
            slidesToScroll: n
        } = t, a = e.slides.length;
        let o = Number(e.current) + Number(n[i]);
        return o = (o = (o = o > a ? a : o) == a ? a - (Number(n[i]) - 1) : o) < a && o > a - Number(t[i]) ? a - Number(t[i]) + 1 : o
    },
    _pf_resizeSlideObserverV3 = (e, t, i) => {
        let n = new ResizeObserver(() => {
            t ? .maxHeight || _pf_updateSliderHeight(e, t, i)
        });
        e.querySelectorAll('div[data-pf-type="Row"]') ? .forEach(e => n.observe(e))
    };
async function _pf_handleSlideshowVersion3() {
    let s = _pf_getDevice();
    var e = document.querySelectorAll('[data-pf-type="Slideshow"]');
    window.SnapSlider && e.forEach(r => {
        let l = _pf_getFrontEndSettings(r);
        if (l) {
            let {
                loop: e,
                autoPlay: t,
                maxHeight: i,
                navStyle: n,
                paginationStyle: a
            } = l, o = r.querySelector(".pf-slider");
            i || _pf_updateSliderHeight(o, l, s, !0), new window.SnapSlider(o, {
                id: o.getAttribute("data-id"),
                slides: ".pf-slide",
                loop: e,
                on: {
                    load: e => {
                        _pf_initVisibleObservers(e), _pf_resizeSlideObserverV3(o, l, s), _pf_renderPaginationButtonsLiveView(e, l, s), _pf_handleSlideshowNavigationButtons(e, l, s), _pf_handlePaginationButtons(e, l, s), _pf_handleSlidesScrollStop(e, l, s), t && _pf_handleAutoPlay(e, l, s)
                    },
                    "scroll.end": e => {
                        i || _pf_updateSliderHeight(o, l, s), "none" !== n && _pf_updateNavigationButtonsState(e, l, s), "none" !== a && _pf_updatePaginationButtonsState(e, l, s)
                    }
                }
            })
        }
    })
}

function _pf_renderPaginationButtonsLiveView(t, i, n) {
    var a = i.paginationStyle;
    if ("none" !== a) {
        var o = t.container.querySelector(":scope > .pf-slider-nav"),
            a = (o.replaceChildren(), _pf_getTotalPaginationButtons(t, i, n));
        let e = a;
        for (; 0 < e;) {
            var r = document.createElement("button");
            r.setAttribute("type", "button"), o.appendChild(r), e--
        }
    }
}

function _pf_getTotalHeightOfActiveSlides(e, i = !1) {
    try {
        let t = 0;
        var n = e.querySelectorAll('[data-pf-type="SlideshowSlide"] > *');
        for (let e = 0; e < n.length; e++) {
            var a = n[e],
                o = (a.style.height = "auto", i ? parseInt(getComputedStyle(a).height) : a.getBoundingClientRect().height);
            t += Number(o || 0)
        }
        return t
    } catch (e) {
        return console.error(e), 0
    }
}

function _pf_getMaxHeightOfActiveSlides(e) {
    e = Array.from(e.querySelectorAll(".pf-slide.is-visible")).map(e => _pf_getTotalHeightOfActiveSlides(e, !0));
    return Math.max(...e)
}

function _pf_updateSliderHeight(e, t, i, n = !1) {
    n ? (n = Array.from(e.querySelectorAll(".pf-slide")).map(e => _pf_getTotalHeightOfActiveSlides(e)).slice(0, t ? .slidesToShow[i]), t = Math.max(...n), e.style.height = t + "px") : _pf_shouldUpdateHeight(e) && (i = _pf_getMaxHeightOfActiveSlides(e), e.style.height = i + "px")
}

function _pf_shouldUpdateHeight(e) {
    var t = e.querySelectorAll(".pf-slide"),
        i = e.scrollWidth / t.length,
        n = e.scrollLeft;
    for (let e = 0; e < t ? .length; e++)
        if (i * e + _pf_OBSERVATIONAL_ERROR_VALUE >= n && n >= i * e - _pf_OBSERVATIONAL_ERROR_VALUE) return !0;
    return !1
}

function _pf_handleSlidesScrollStop(e, t, i) {
    var n = e.slides;
    for (let e = 0; e < n.length; e += Number(t ? .slidesToScroll[i])) n[e].style.scrollSnapStop = "always"
}

function _pf_getTotalPaginationButtons(e, t, i) {
    var {
        slidesToShow: t,
        slidesToScroll: n
    } = t;
    return Math.ceil((e.slides.length - t[i]) / n[i]) + 1
}

function _pf_getActivePagination(e, t, i, n) {
    n = n || _pf_getCurrentIndex(e, t, i);
    return Math.ceil((n - 1) / t.slidesToScroll[i])
}

function _pf_handleSlideshowNavigationButtons(t, i, n) {
    let {
        slidesToShow: a,
        slidesToScroll: o,
        loop: r,
        paginationStyle: l
    } = i;
    var e = t.container.querySelector(":scope > .pf-slider-prev"),
        s = t.container.querySelector(":scope > .pf-slider-next");
    let c = t.slides.length;
    "none" !== i ? .navStyle && _pf_updateNavigationButtonsState(t, i, n), s && s.addEventListener("click", function(e) {
        e.stopPropagation(), e.detail && 1 !== e.detail || (t.current === c || Number(t.current) + Number(a[n]) - 1 === c ? (r && "none" !== l && _pf_updatePaginationButtonsState(t, i, n, 1), r && t.goto(1)) : (e = _pf_getNextSlideIndex(t, i, n), "none" !== l && _pf_updatePaginationButtonsState(t, i, n, e), t.goto(e)))
    }), e && e.addEventListener("click", function(e) {
        if (e.stopPropagation(), !e.detail || 1 === e.detail)
            if (1 === t.current) r && (e = c - a[n] + 1, "none" !== l && _pf_updatePaginationButtonsState(t, i, n, e), t.goto(e));
            else {
                let e = t.current - o[n];
                e < 1 && (e = 1), "none" !== l && _pf_updatePaginationButtonsState(t, i, n, e), t.goto(e)
            }
    })
}

function _pf_updatePaginationButtonsState(e, t, i, n) {
    t = _pf_getActivePagination(e, t, i, n), i = e.container.querySelectorAll(":scope > .pf-slider-nav button");
    let a = Math.min(t, i.length - 1);
    i.forEach((e, t) => {
        t === a ? e.classList.add("active") : e.classList.remove("active")
    })
}

function _pf_handlePaginationButtons(n, a, o) {
    let r = n.container.querySelector(":scope > .pf-slider-nav") ? .querySelectorAll("button");
    "none" !== a ? .paginationStyle && _pf_updatePaginationButtonsState(n, a, o), r ? .forEach((t, i) => {
        t.onclick = function(e) {
            e.stopPropagation(), n.goto(i * a ? .slidesToScroll[o] + 1), r.forEach(e => e.classList.remove("active")), t.classList.add("active")
        }
    })
}

function _pf_updatePaginationButtonsWithNumberOfVariantsRemainingState(t) {
    var a = t ? .slides ? .length,
        o = t.container.querySelector(":scope > .pf-slider-nav-with-number-left");
    if (o) {
        let e = o ? .querySelectorAll(".pagination-button"),
            i = o ? .querySelector(".prev-button"),
            n = o ? .querySelector(".next-button");
        var r = o ? .querySelector(".first-media-pagination-button"),
            o = o ? .querySelector(".last-media-pagination-button"),
            l = +i.querySelector(".number-media-prev").innerHTML,
            s = 1 === t.current ? -1 : t.current === a ? _pf_numberOfVisiblePaginationItemInNewLayout : Array.from(e).findIndex(e => e.classList.contains("active")),
            l = t.current - (l + s) - 1 + s,
            s = i => {
                e.forEach((e, t) => {
                    e.classList.toggle("active", t === i)
                })
            },
            c = (e, t) => {
                i.querySelector(".number-media-prev").innerHTML = e, n.querySelector(".number-media-next").innerHTML = t
            },
            u = (e, t, i) => {
                e.classList.toggle(t, i)
            };
        l > _pf_numberOfVisiblePaginationItemInNewLayout - 1 ? (s(_pf_numberOfVisiblePaginationItemInNewLayout - 1), t.current !== a ? c(t.current - _pf_numberOfVisiblePaginationItemInNewLayout, a - t.current) : c(a - _pf_numberOfVisiblePaginationItemInNewLayout - 1, 1)) : l < 0 ? (s(0), 1 !== t.current ? c(t.current - 1, a - t.current - _pf_numberOfVisiblePaginationItemInNewLayout + 1) : c(1, a - _pf_numberOfVisiblePaginationItemInNewLayout - 1)) : s(l), 1 !== t.current && t.current !== a ? (i.classList.remove("disabled"), n.classList.remove("disabled"), r.classList.add("disabled"), o.classList.add("disabled")) : (e.forEach(e => e.classList.remove("active")), u(i, "disabled", 1 === t.current), u(n, "disabled", t.current === a), u(r, "disabled", t.current === a), u(o, "disabled", 1 === t.current), u(r, "active", 1 === t.current), u(o, "active", t.current === a))
    }
}

function _pf_handlePaginationButtonsWithNumberOfVariantsRemaining(a, e, t) {
    let o = a ? .slides ? .length;
    var r = a.container.querySelector(":scope > .pf-slider-nav-with-number-left");
    if (r) {
        let i = r ? .querySelectorAll(".pagination-button");
        var l = r ? .querySelector(".prev-button"),
            s = r ? .querySelector(".next-button"),
            c = r ? .querySelector(".first-media-pagination-button"),
            r = r ? .querySelector(".last-media-pagination-button");
        let n = _pf_getActivePagination(a, e, t);
        0 === n && (l.classList.add("disabled"), l.querySelector(".number-media-prev").innerHTML = 1, c.classList.remove("disabled"), c.classList.add("active")), n === o - 1 && (s.classList.add("disabled"), s.querySelector(".number-media-next").innerHTML = 1, r.classList.remove("disabled"), r.classList.add("active")), l.onclick = function(e) {
            e.stopPropagation(), a.goto(a.current - 1)
        }, s.onclick = function(e) {
            e.stopPropagation(), a.goto(a.current + 1)
        }, i ? .forEach((e, t) => {
            [1, 2].includes(n) && t === n - 1 || 3 <= n && n <= o - 4 && 2 === t || n === o - 3 && 3 === t || n === o - 2 && 4 === t ? e.classList.add("active") : e.classList.remove("active"), e.onclick = function(e) {
                e.stopPropagation();
                e = 1 === a.current ? -1 : a.current === o ? _pf_numberOfVisiblePaginationItemInNewLayout : Array.from(i).findIndex(e => e.classList.contains("active"));
                a.goto(a.current + t - e)
            }
        })
    }
}

function _pf_updateNavigationButtonsState(e, t, i) {
    try {
        var n = _pf_getTotalPaginationButtons(e, t, i),
            a = _pf_getActivePagination(e, t, i),
            o = e.container.querySelector(":scope > .pf-slider-prev"),
            r = e.container.querySelector(":scope > .pf-slider-next");
        o && r && (t ? .loop || (e ? .slides ? .length <= t ? .slidesToShow ? .[i] ? (r.style.visibility = "hidden", o.style.visibility = "hidden") : n - 1 <= a ? (r.style.visibility = "hidden", o.style.visibility = "") : 0 === a ? (r.style.visibility = "", o.style.visibility = "hidden") : (r.style.visibility = "", o.style.visibility = "")))
    } catch (e) {
        console.error("updateNavigationButtonsState:", e)
    }
}

function _pf_initVisibleObservers(e) {
    var {
        container: e,
        slides: t
    } = e;
    let i = new IntersectionObserver((e, t) => {
        e.forEach(e => {
            _pf_updateVisibleClasses(e), _pf_handleAutoPauseVideo(e)
        })
    }, {
        root: e,
        threshold: .9
    });
    t.forEach(e => i.observe(e))
}

function _pf_handleAutoPauseVideo(e) {
    var t = e.target;
    e.isIntersecting || (e = t.querySelector("video"), t = t.querySelector("iframe"), e && e.pause(), t && t.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', _pf_YOUTUBE_ORIGIN))
}

function _pf_updateVisibleClasses(e) {
    var t = e.target;
    e.isIntersecting ? t.classList.add("is-visible") : t.classList.remove("is-visible")
}

function _pf_handleAutoPlay(n, a, o) {
    let e, r = n.slides,
        l = r.length,
        {
            autoPlayDelay: t,
            pauseOnHover: i,
            slidesToScroll: s,
            slidesToShow: c,
            loop: u
        } = a,
        d = () => {
            e = setInterval(() => {
                var e = _pf_getCurrentIndex(n, a, o);
                let t = e - 1 + Number(s[o]);
                u && (e === l || e + Number(c[o]) > l) && (t = 0);
                var {
                    top: e,
                    left: i
                } = n.getScrollOffset(r[t]);
                n.container.scroll({
                    top: e,
                    left: i,
                    behavior: "smooth"
                })
            }, t)
        };
    d(), i && (n.container.addEventListener("mouseover", function() {
        e && (clearInterval(e), e = null)
    }), n.container.addEventListener("mouseleave", function() {
        d()
    }))
}
_pf_handleSlideshowVersion3().catch(console.error);