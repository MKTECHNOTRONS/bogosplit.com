let _pf_pageflyHelperContentLoaded = new CustomEvent("PageFlyHelperContentLoaded", {
        detail: {
            message: "Pagefly Helper is ready to execute..."
        }
    }),
    _pf_initZoomImage = t => {
        let _ = t.querySelector("img");
        var i = _.src;
        if (i) {
            let e = {
                    width: _.width,
                    height: _.height
                },
                n = document.createElement("div");
            n.className = "zoom-image", n.style.cssText = `
		background: url('${i}') no-repeat center/contain;
		z-index: 1;
		width: ${_.width}px;
		height: ${_.height}px;
		position: absolute;
		top: 0;
	`, !!t.querySelector("div.zoom-image") || t.insertBefore(n, t.firstElementChild.nextSibling), t.addEventListener("mouseenter", function() {
                _.style.display = "none", n.style.backgroundSize = "150%", n.style.width = "100%", n.style.height = "100%"
            }), t.addEventListener("mousemove", function(e) {
                var t = this.getBoundingClientRect(),
                    _ = e.clientX - t.left,
                    e = e.clientY - t.top,
                    _ = Math.round(100 / (t.width / _)),
                    t = Math.round(100 / (t.height / e));
                n.style.backgroundPosition = _ + `% ${t}%`
            }), t.addEventListener("mouseleave", function() {
                "none" !== t.querySelector("div.zoom-image").style.display && (_.style.display = "inline"), n.style.backgroundSize = "contain", n.style.backgroundPosition = "center", n.style.width = e.width + "px", n.style.height = e.height + "px"
            })
        }
    },
    _pf_initZoomImage2 = r => {
        if (r) {
            let o = r.querySelector(":scope > img");
            if (o) {
                let i = o.parentElement;
                if (i) {
                    let n = () => "image" === r.getAttribute("data-media-type"),
                        e = () => {
                            n() && (o.style.opacity = "0", i.style.backgroundImage = `url("${o.currentSrc}")`, i.style.backgroundRepeat = "no-repeat", i.style.backgroundSize = "200%")
                        },
                        t = e => {
                            var t, _;
                            n() && (t = e.currentTarget, _ = e.offsetX || e.touches ? .[0].pageX || 0, e = e.offsetY || e.touches ? .[0].pageY || 0, _ = _ / t.offsetWidth * 100, t.style.backgroundPosition = _ + `% ${e/t.offsetHeight*100}%`)
                        },
                        _ = () => {
                            n() && (o.style.opacity = "1", i.style.backgroundImage = "")
                        };
                    return i.addEventListener("mouseenter", e), i.addEventListener("mousemove", t), i.addEventListener("mouseleave", _), () => {
                        i.removeEventListener("mouseenter", e), i.removeEventListener("mousemove", t), i.removeEventListener("mouseleave", _)
                    }
                }
            }
        }
    },
    _pf_getMobileOS = () => {
        var e = navigator.userAgent;
        return /android/i.test(e) ? "Android" : /iPad|iPhone|iPod/.test(e) || "MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints ? "iOS" : "Other"
    },
    _pf_checkARCompatible = t => {
        if ("Android" === t) return "xr" in window.navigator;
        if ("iOS" !== t) return !1; {
            let e = !1;
            t = document.createElement("a");
            return e = t.relList.supports("ar") ? !0 : e
        }
    },
    _pf_TIMER_OUT = 1500,
    _pf_timeoutPromise = (t = _pf_TIMER_OUT) => new Promise(e => {
        setTimeout(e, t)
    }),
    _pf_isTrackingActive = () => (window.__pagefly_analytics_settings__ ? .acceptNewTracking || window.__pagefly_analytics_settings__ ? .acceptTracking) && !window.location.href.includes("preview?id=") && ("function" != typeof window.Shopify.customerPrivacy ? .userCanBeTracked || window.Shopify.customerPrivacy.userCanBeTracked()),
    _pf_truncateText = (t, o, r) => {
        if (o) {
            var l = "[　-〿]|[぀-ゟ]|[゠-ヿ]|[＀-￯]|[一-龯]|[★-☆]|[←-↕]|※",
                a = new RegExp(l),
                p = !!t.match(a);
            let e = t,
                n = t.replace(/<[^>]*>/g, " ").trim(),
                i = (p && (d = new RegExp(`(${l})`, "g"), e = e.replace(d, " $1"), n = n.replace(d, " $1")), n = n.match(/\S+/g), []);
            if (n && n.length > o) {
                var s = e.replace(/</g, " <").replace(/>/g, "> ").split(/\s/);
                let _ = 0;
                for (let t = 0; t < s.length && (_ !== o && n.length); t++) {
                    let e = s[t];
                    var f, c = e.replace(/<[^>]*>/g, "").replace(/^[^>]*>/g, "").replace(/<[^>]*$/g, "");
                    n[0] === c && (f = n.splice(0, 1)[0], c.match(/^&[a-z0-9]+;$/i) || !(1 < c.length || c.match(/[a-z0-9]/i) || c.match(a)) || ["", " ", "`", "-", "=", "~", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", "[", "]", "\\", ";", "'", ",", ".", "/", "{", "}", "|", ":", '"', "<", ">", "?"].includes(c) || (_++, r && _ === o && (e = e.replace(f, f + "&hellip;")))), i.push(e)
                }
                i = i.join(" ").replace(/ </g, "<").replace(/> /g, ">");
                var d = (i = p ? i.replace(new RegExp(` (${l})`, "g"), "$1") : i).match(/<[^>]*>/g);
                if (d) {
                    let _ = [];
                    d.forEach(t => {
                        if (!t.match(/\/>$/) && !t.match(/<br\s*(((\w|[.-])+="[^"]*"\s*|\s+(\w)*))*\/?>/)) {
                            let e = t.match(/^<([a-z0-9\-_]+)/i);
                            return e ? _.push(e[1].toLowerCase()) : (e = t.match(/^<\/([a-z0-9\-_]+)>/i)) && e[1].toLowerCase() === _[_.length - 1] ? _.pop() : void 0
                        }
                    }), _.length && _.reverse().forEach(e => {
                        i += `</${e}>`
                    })
                }
                return i
            }
        }
        return t
    },
    _pf_textToJsonUseVal = inputText => {
        try {
            let jsonString = `{"data": ${inputText}}`,
                jsonObject = eval(`(${jsonString})`);
            return jsonObject.data
        } catch (e) {
            return console.error("===> Error textToJsonUseVal:", e), null
        }
    },
    _pf_validationRegex = /^[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-4[A-Za-z0-9]{3}-[A-Za-z0-9]{4}-[A-Za-z0-9]{12}$/,
    _pf_validateUUID = e => "string" == typeof e && _pf_validationRegex.test(e),
    _pf_easeOutCubic = e => --e * e * e + 1,
    _pf_smoothScroll = (e, _ = 600) => {
        let n = window.scrollY,
            i = e - n,
            o = Date.now(),
            r = () => {
                var e = (Date.now() - o) / _,
                    t = _pf_easeOutCubic(e);
                window.scrollTo({
                    top: n + t * i
                }), e < 1 && window.requestAnimationFrame(r)
            };
        r()
    },
    _pf_LIST_LAYOUT = {
        GRID: 0,
        SLIDE: 1
    },
    _pf_HOVER_ACTION = {
        NONE: 0,
        MAGNIFIER: 1,
        HOVER: 2
    },
    _pf_ON_HOVER = {
        NEXT_IMAGE: 0,
        LAST_IMAGE: 1,
        RANDOM_IMAGE: 2,
        ALL_IMAGE: 3
    },
    _pf_CLICK_ACTION = {
        NONE: 0,
        LINK_TO_PRODUCT: 1,
        SHOW_FULLSCREEN: 2
    },
    _pf_LIST_POSITION = {
        TOP: 0,
        RIGHT: 1,
        BOTTOM: 2,
        LEFT: 3
    },
    _pf_DEVICES_MAP = {
        laptop: {
            from: 1025,
            to: 1200
        },
        tablet: {
            from: 768,
            to: 1024
        },
        mobile: {
            from: 0,
            to: 767
        }
    },
    _pf_REGEX_CHECK_LAST_WORD_BEFORE_UNDERSCORE = /_(\d+)(?!.*_)/,
    _pf_DATE_FORMATS_METAFIELD = {
        "%m-%d-%Y": "MM-dd-yyyy",
        "%d-%m-%Y": "dd-MM-yyyy",
        "%Y-%m-%d": "yyyy-MM-dd",
        "%m/%d/%Y": "MM/dd/yyyy",
        "%d/%m/%Y": "dd/MM/yyyy",
        "%Y/%m/%d": "yyyy/MM/dd",
        "%B %e, %Y": "MMMM d, yyyy",
        "%e %B, %Y": "d MMMM, yyyy",
        "%d %b, %Y": "dd MMM, yyyy"
    },
    _pf_TIME_FORMATS_METAFIELD = {
        "%I:%M %p": "KK:mm a",
        "%H:%M": "HH:mm"
    },
    _pf_TYPE_METAFIELD = {
        COLOR_FIELD: "color",
        DATE_FIELD: "date",
        DATE_TIME_FIELD: "date_time",
        SINGLE_LINE_TEXT_FIELD: "single_line_text_field",
        MULTI_LINE_TEXT_FIELD: "multi_line_text_field",
        NUMBER_INTEGER_FIELD: "number_integer",
        NUMBER_DECIMAL_FIELD: "number_decimal",
        URL_FIELD: "url",
        DIMENSION_FIELD: "dimension",
        VOLUME_FIELD: "volume",
        WEIGHT_FIELD: "weight",
        RATING_FIELD: "rating",
        FILE_REFERENCE_FIELD: "file_reference",
        IMAGE_REFERENCE_FIELD: "image_reference",
        PAGE_REFERENCE_FIELD: "page_reference",
        PRODUCT_REFERENCE_FIELD: "product_reference",
        VARIANT_REFERENCE_FIELD: "variant_reference",
        LIST_COLOR_FIELD: "list.color",
        LIST_DATE_TIME_FIELD: "list.date_time",
        LIST_DATE_FIELD: "list.date",
        LIST_NUMBER_INTEGER_FIELD: "list.number_integer",
        LIST_NUMBER_DECIMAL_FIELD: "list.number_decimal",
        LIST_VARIANT_REFERENCE_FIELD: "list.variant_reference",
        LIST_PRODUCT_REFERENCE_FIELD: "list.product_reference",
        LIST_FILE_REFERENCE_FIELD: "list.file_reference",
        LIST_PAGE_REFERENCE_FIELD: "list.page_reference",
        LIST_IMAGE_REFERENCE_FIELD: "list.image_reference",
        LIST_META_OBJECT_FIELD: "list.metaobject_reference",
        LIST_WEIGHT_FIELD: "list.weight",
        LIST_VOLUME_FIELD: "list.volume",
        LIST_RATING_FIELD: "list.rating",
        LIST_DIMENSION_FIELD: "list.dimension",
        LIST_SINGLE_LINE_TEXT_FIELD: "list.single_line_text_field",
        LIST_URL_FIELD: "list.url",
        BOOLEAN_FIELD: "boolean",
        RICH_TEXT_FIELD: "rich_text_field",
        JSON_FIELD: "json",
        META_OBJECT_FIELD: "metaobject_reference",
        MONEY_FIELD: "money"
    },
    _pf_UNIT_MAPPING_METAFIELD = {
        MILLIMETERS: "mm",
        CENTIMETERS: "cm",
        METERS: "m",
        INCHES: "in",
        FEET: "ft",
        YARDS: "yd",
        MILLILITERS: "ml",
        CENTILITERS: "cl",
        LITERS: "l",
        CUBIC_METERS: "m³",
        FLUID_OUNCES: "fl oz",
        PINTS: "pt",
        QUARTS: "qt",
        GALLONS: "gal",
        IMPERIAL_FLUID_OUNCES: "fl oz imp",
        IMPERIAL_PINTS: "pt imp",
        IMPERIAL_QUARTS: "qt imp",
        IMPERIAL_GALLONS: "gal imp",
        KILOGRAMS: "kg",
        GRAMS: "g",
        POUNDS: "lb",
        OUNCES: "oz",
        m3: "m³",
        us_fl_oz: "fl oz",
        us_pt: "pt",
        us_qt: "qt",
        us_gal: "gal",
        imp_fl_oz: "fl oz imp",
        imp_pt: "pt imp",
        imp_qt: "qt imp",
        imp_gal: "gal imp"
    },
    _pf_VALUE_NOT_SATISFY_METAFIELD = [void 0, null],
    _pf_leftIcon = `
    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50" fill="none">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M29.4508 13.6742C30.1831 14.4064 30.1831 15.5936 29.4508 16.3258L20.7766 25L29.4508 33.6742C30.1831 34.4064 30.1831 35.5936 29.4508 36.3258C28.7186 37.0581 27.5314 37.0581 26.7992 36.3258L16.7992 26.3258C16.0669 25.5936 16.0669 24.4064 16.7992 23.6742L26.7992 13.6742C27.5314 12.9419 28.7186 12.9419 29.4508 13.6742Z" fill="black"/>
    </svg>
  `,
    _pf_rightIcon = `
    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50" fill="none">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M19.2992 36.3258C18.5669 35.5936 18.5669 34.4064 19.2992 33.6742L27.9733 25L19.2992 16.3258C18.5669 15.5936 18.5669 14.4064 19.2992 13.6742C20.0314 12.9419 21.2186 12.9419 21.9508 13.6742L31.9508 23.6742C32.6831 24.4064 32.6831 25.5936 31.9508 26.3258L21.9508 36.3258C21.2186 37.0581 20.0314 37.0581 19.2992 36.3258Z" fill="black"/>
    </svg>
  `,
    _pf_videoIcon = `
    <svg width='11' height='14' viewBox='0 0 11 14' fill='none' xmlns='http://www.w3.org/2000/svg'>
      <path 
          opacity='0.6' 
          d='M1.71795 0.719814C1.56631 0.627985 1.39299 0.578117 1.21573 0.57532C1.03847 0.572523 0.863662 0.616896 0.7092 0.703896C0.554738 0.790895 0.42618 0.917392 0.336696 1.07043C0.247212 1.22346 0.200019 1.39754 0.199951 1.57481V12.3108C0.199976 12.4926 0.249526 12.6708 0.343274 12.8265C0.437022 12.9822 0.571425 13.1094 0.732038 13.1945C0.89265 13.2795 1.0734 13.3191 1.25486 13.3092C1.43632 13.2992 1.61163 13.24 1.76195 13.1378L10.112 7.46081C10.2504 7.36662 10.363 7.23915 10.4394 7.09011C10.5158 6.94107 10.5536 6.77523 10.5492 6.6078C10.5448 6.44038 10.4985 6.27673 10.4144 6.13189C10.3303 5.98704 10.2112 5.86564 10.068 5.77881L1.71795 0.718814V0.719814Z'
          fill='black'
        />
    </svg>
  `,
    _pf_modelIcon = `
      <svg width='16' height='17' viewBox='0 0 16 17' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <path
          opacity='0.6'
          d='M14.1301 3.27971L9.00008 0.319707C8.69604 0.144171 8.35115 0.0517578 8.00008 0.0517578C7.649 0.0517578 7.30411 0.144171 7.00008 0.319707L1.88008 3.31971C1.5719 3.49759 1.31675 3.75447 1.14097 4.06385C0.965185 4.37323 0.875124 4.72391 0.880077 5.07971V10.9997C0.875124 11.3555 0.965185 11.7062 1.14097 12.0156C1.31675 12.3249 1.5719 12.5818 1.88008 12.7597L7.00008 15.7597C7.30411 15.9352 7.649 16.0277 8.00008 16.0277C8.35115 16.0277 8.69604 15.9352 9.00008 15.7597L14.1201 12.7597C14.4283 12.5818 14.6834 12.3249 14.8592 12.0156C15.035 11.7062 15.125 11.3555 15.1201 10.9997V4.99971C15.119 4.65165 15.0271 4.30991 14.8535 4.00825C14.6798 3.7066 14.4305 3.45547 14.1301 3.27971ZM7.73008 14.3797L2.61008 11.3797C2.54095 11.34 2.48167 11.2852 2.43666 11.2194C2.39164 11.1536 2.36205 11.0785 2.35008 10.9997V4.99971C2.3504 4.90601 2.37556 4.81407 2.42299 4.73327C2.47042 4.65246 2.53843 4.58567 2.62008 4.53971L7.74008 1.53971C7.82065 1.49319 7.91204 1.4687 8.00508 1.4687C8.09811 1.4687 8.18951 1.49319 8.27008 1.53971L13.3901 4.53971L8.67008 7.21971C8.45972 7.33976 8.28614 7.51498 8.16806 7.72646C8.04999 7.93793 7.9919 8.17764 8.00008 8.41971V14.4197C7.91475 14.4413 7.8254 14.4413 7.74008 14.4197L7.73008 14.3797Z'
          fill='black'
        />
      </svg>
      `,
    _pf_ATC_BUTTON_ID = "__pf_orderitem_id",
    _pf_ATC_PF_ANALYTICS_ID = "__pf_analytics_orderitem_id",
    _pf_pageflyProducts = window.__pageflyProducts || {},
    _pf_pageflyProductCollections = window.__pagefly_product_collections || {},
    _pf_OUTSIDE_BOX_KEY = "outside",
    _pf_modalDataCss = ".pf-m{display:none;top:50%;left:50%;transform:translate(-50%,-50%);max-height:min(calc(9/16*100vw), calc(100% - 6px - 2em));-webkit-overflow-scrolling:touch;overflow:hidden;background:0 0;border:none;margin:0;padding:0;flex-direction:column;align-items:flex-end}.pf-m::backdrop{background:rgba(0,0,0,.9);opacity:1}.pf-m iframe{border:0;}.pf-m>img{max-width:90vw;max-height:90vh;vertical-align:middle}.pf-close-btn{height:16px;background:none;border:none;margin-bottom:8px;padding:0;cursor:pointer}.pf-close-btn:focus-visible{box-shadow:none;}svg{pointer-events:none}",
    _pf_STARTED_VERSION_USING_THEME_APP_EXTENSION = "3.0.0",
    _pf_isTouchDevice = window.innerWidth < 1025,
    _pf_PAGEFLY_ANIMATION_CSS = "pagefly-animation",
    _pf_defaultOptionObserver = {
        threshold: 0
    },
    _pf_pfSetting = window.__pagefly_setting__ || {
        baseURL: "https://apps.pagefly.io",
        cdnURL: "https://cdn.pagefly.io"
    },
    _pf_pfPageSetting = window.__pagefly_page_setting__ || {},
    _pf_pfSectionSetting = window.__pagefly_section_setting__ || {},
    _pf_elementDataFromSetting = _pf_pfSetting.elementData || {},
    _pf_pfAnalyticSetting = window.__pagefly_analytics_settings__ || {},
    _pf_pfGlobalSetting = window.__pagefly_global_settings__ || {},
    _pf_APP_PROXY_URL = "/apps/pagefly",
    _pf_YOUTUBE_ORIGIN = "https://www.youtube.com",
    _pf_VIMEO_ORIGIN = "https://player.vimeo.com",
    _pf_PARALLAX_SELECTORS = ['div[data-parallax="true"]', 'section[data-parallax="true"]'],
    _pf_PARALLAX_SELECTOR = _pf_PARALLAX_SELECTORS.join(", "),
    _pf_productMediaQueryString = '[data-pf-type="ProductMedia2"], [data-pf-type="ProductMedia3"]',
    _pf_IDX = (document.dispatchEvent(_pf_pageflyHelperContentLoaded), 36),
    _pf_HEX = "";
for (; _pf_IDX--;) _pf_HEX += _pf_IDX.toString(36);
let _pf_SIZE = 4096,
    _pf_HEX2 = [],
    _pf_IDX2 = 0,
    _pf_BUFFER;
for (; _pf_IDX2 < 256; _pf_IDX2++) _pf_HEX2["" + _pf_IDX2] = (_pf_IDX2 + 256).toString(16).substring(1);

function _pf_getDevice() {
    let _ = window.innerWidth;
    return Object.keys(_pf_DEVICES_MAP).find(e => {
        var {
            from: e,
            to: t
        } = _pf_DEVICES_MAP[e];
        return _ >= e && _ <= t
    }) || "all"
}

function _pf_asyncWait(t = 1e3) {
    return new Promise(e => setTimeout(e, t))
}

function _pf_mergeDeep(e, t) {
    var _, n = { ...e || {}
    };
    for (_ of Object.keys(t)) t[_] instanceof Object && !Array.isArray(t[_]) && Object.assign(t[_], _pf_mergeDeep(n[_], t[_]));
    return Object.assign(n, t), n
}

function _pf_getElemIdByClassname(e) {
    return e ? e.split(" ").find(e => e.match(/pf-(\d)+_|pf-(\w+)-(\d)+_/)) : null
}

function _pf_debounce(n, i, o = !1) {
    let r;
    return function() {
        let e = this,
            t = arguments;
        var _ = o && !r;
        clearTimeout(r), r = setTimeout(function() {
            r = null, o || n.apply(e, t)
        }, i), _ && n.apply(e, t)
    }
}
async function _pf_getHttpRequest(n) {
    return new Promise((e, t) => {
        let _ = new XMLHttpRequest;
        _.open("GET", n, !0), _.onload = () => 200 === _.status ? e(_.response) : t(Error(_.statusText)), _.onerror = e => t(Error("Network Error: " + e)), _.send()
    })
}

function _pf_getPageTypeFromPFPageSetting() {
    return _pf_pfPageSetting.pageType || window.__pagefly_setting__ ? .pageType
}

function _pf_hideElementIfNotFound(t, _) {
    var n = t.length,
        i = _.length;
    if (i < n)
        for (let e = i; e < n; e++) t[e].style.visibility = "hidden", t[e].style.height = "0", t[e].style.overflow = "hidden";
    if (i === n)
        for (let e = 0; e < n; e++) t[e].style.visibility = t[e].style.visibility || "visible", t[e].style.height = _[e].style.height || "unset", t[e].style.overflow = t[e].style.overflow || "auto"
}

function _pf_collectionHas(t, _) {
    for (let e = 0; e < t.length; e++)
        if (t[e] === _) return !0;
    return !1
}

function _pf_findParentBySelector(e, t) {
    var _ = document.querySelectorAll(t);
    let n = e.parentNode;
    for (; n && !_pf_collectionHas(_, n);) n = n.parentNode;
    return n
}

function _pf_getOriginalSrc(e) {
    return e.includes("https://cdn.shopify.com") && e.includes("&resized") ? e.slice(0, e.lastIndexOf("_")) + "." + e.split(".")[e.split(".").length - 1] : e
}

function _pf_loadJS(n, i = document.body, o = !0, r = !1) {
    return new Promise((e, t) => {
        var _ = i.ownerDocument;
        if (_.querySelector(`script[src="${n}"]`)) return e(!0);
        _ = _.createElement("script");
        _.src = n, _.async = o, _.defer = r, _.onload = e, _.onerror = t, i.appendChild(_)
    })
}

function _pf_uid(e) {
    let t = "",
        _ = e || 11;
    for (; _--;) t += _pf_HEX[36 * Math.random() | 0];
    return t
}

function _pf_uuid() {
    (!_pf_BUFFER || _pf_IDX2 + 16 > _pf_SIZE) && (_pf_BUFFER = crypto.getRandomValues(new Uint8Array(_pf_SIZE)), _pf_IDX2 = 0);
    let e = 0,
        t, _ = "";
    for (; e < 16; e++) t = _pf_BUFFER[e + _pf_IDX2], 6 == e ? _ += _pf_HEX2[15 & t | 64] : 8 == e ? _ += _pf_HEX2[63 & t | 128] : _ += _pf_HEX2[t], 1 & e && 1 < e && e < 11 && (_ += "-");
    return _pf_IDX2++, _
}
async function _pf_loadScript({
    src: _,
    iframeDoc: e = document,
    ...t
}) {
    let n = e.createElement("script");
    Object.assign(n, {
        src: _,
        ...t
    }), n.defer && n.setAttribute("defer", "defer");
    t = new Promise((e, t) => {
        n.onload = () => {
            console.log("Script loaded successfully:", n), e(n)
        }, n.onerror = e => t(new Error(`Failed to load script: ${_}: ` + e))
    });
    e.body.appendChild(n), await t
}

function _pf_isScriptLoaded(e) {
    return null !== document.querySelector(`script[src="${e}"]`)
}

function _pf_processChunk(e) {
    var {
        start: t,
        list: _,
        callback: n,
        chunkSize: i,
        method: o
    } = e, r = (r = t + i) > _.length ? _.length : r;
    for (let e = t; e < r; e++) n(_[e], e);
    r < _.length && (e.start = r, o(() => _pf_processChunk(e)))
}

function _pf_executeChunk(e, t, _ = 10) {
    let n = e => setTimeout(e);
    window.requestAnimationFrame && (n = e => requestAnimationFrame(e)), _pf_processChunk({
        start: 0,
        list: e,
        callback: t,
        chunkSize: _,
        method: n = window.requestIdleCallback ? e => requestIdleCallback(e) : n
    })
}

function _pf_isEmpty(e) {
    return null == e || ("string" == typeof e || Array.isArray(e) || "object" == typeof e && "number" == typeof e.length ? 0 === e.length : e instanceof Map || e instanceof Set ? 0 === e.size : "object" == typeof e && 0 === Object.keys(e).length)
}

function _pf_getFrontEndSettings(e) {
    return e ? (e = _pf_getElemIdByClassname(e.className), (window.__pagefly_setting__ ? .elementData || {})[e]) : {}
}

function _pf_setAttributes(e, t) {
    for (var _ in t) Object.hasOwn(t, _) && e.setAttribute(_, t[_])
}
window.__pagefly__ = window.__pagefly__ || {};